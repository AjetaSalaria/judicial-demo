@extends('layouts.guest_navigation')

@section('title', 'Home - Trellis Legal Intelligence')

@section('content')
<section class="py-8 py-md-11 border-bottom section-2">
                  <div class="container">
                  </div>   
               </section> 
@endsection