<footer id="footer" class="page-footer hide-on-print">
        <div class="container footer-container">
            <div class="row justify-content-center justify-content-md-start text-center text-md-left">
                <div class="col-lg-3 ml-lg-auto mb-8 mb-lg-0 text-left"> <img class="brand" src="{{ asset('images/logo.png') }}" alt="Logo" style="height:100px;width:100px;">
                    <ul class="list-inline mb-0 social-footer">
                        <li class="list-inline-item">
                            <a class="btn btn-xs btn-icon btn-soft-secondary rounded" href="https://www.linkedin.com/company/trellis-law" aria-label="Linkedin"> <i class="fab fa-linkedin fa-2x"></i> </a>
                        </li>
                        <li class="list-inline-item">
                            <a class="btn btn-xs btn-icon btn-soft-secondary rounded" href="https://twitter.com/trellis_law" aria-label="Twitter"> <i class="fab fa-twitter fa-2x"></i> </a>
                        </li>
                    </ul>
                </div>
                <div class="col-6 col-md-3 col-lg mb-5 mb-lg-0 text-left">
                    <h5 class="text-white">Features</h5>
                    <ul class="nav nav-sm nav-x-0 nav-white flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="/search"> 
                                <span class="media align-items-center">
                                    <span class="media-body">Smart Search</span> 
                                </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/judges"> 
                                <span class="media align-items-center">
                                    <span class="media-body">Judge Analytics</span>
                                </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/ca/motion-type"> 
                                <span class="media align-items-center">
                                    <span class="media-body">Motion & Issues</span> 
                                </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/coverage"> 
                            <span class="media align-items-center">
                                <span class="media-body">State Coverage</span> 
                            </span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-6 col-md-3 col-lg mb-5 mb-lg-0 text-left">
                    <h5 class="text-white">Company</h5>
                    <ul class="nav nav-sm nav-x-0 nav-white flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="/"> 
                                <span class="media align-items-center">
                                    <span class="media-body">Home</span> 
                                </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/about"> 
                                <span class="media align-items-center">
                                    <span class="media-body">About</span> 
                                </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/contact"> 
                                <span class="media align-items-center">
                                    <span class="media-body">Contact us</span> 
                                </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/plans"> 
                                <span class="media align-items-center">
                                    <span class="media-body">Pricing</span> 
                                </span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-6 col-md-3 col-lg text-left">
                    <h5 class="text-white">Resources</h5>
                    <ul class="nav nav-sm nav-x-0 nav-white flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="https://blog.trellis.law/">
                             <span class="media align-items-center">
                                <span class="media-body">
                                    Blog
                                </span> </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="https://support.trellis.law"> 
                                <span class="media align-items-center">
                                    <span class="media-body">
                                    Support & FAQ
                                    </span>
                                 </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/faq/credits"> 
                                <span class="media align-items-center">
                                    <span class="media-body">
                                    Credit System FAQ
                                    </span> 
                                </span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-12 mt-3">
                    <hr class="opacity-xs my-0">
                    <div class="container space-1">
                        <div class="row align-items-md-center mb-7">
                            <div class="col-md-6 mb-4 mb-md-0 pl-0">
                                <ul class="nav nav-sm nav-white nav-x-sm align-items-center">
                                    <li class="nav-item"> <a class="nav-link" href="/privacy-policy">Privacy &amp; Policy</a> </li>
                                    <li class="nav-item opacity mx-3">/</li>
                                    <li class="nav-item"> <a class="nav-link" href="/terms-of-service">Term of Service</a> </li>
                                    <li class="nav-item opacity mx-3">/</li>
                                    <li class="nav-item"> <a class="nav-link" href="/public-records">Public Records</a> </li>
                                </ul>
                            </div>
                            <div class="col-sm-6 w-md-75 text-lg-right mx-lg-auto">
                                <p class="text-white opacity-sm  mt-3">© 2021 All Rights Reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>