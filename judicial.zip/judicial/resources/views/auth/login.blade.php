{{-- <x-guest-layout>
    <x-auth-card>
        <x-slot name="logo">
            <a href="/">
                <x-application-logo class="w-20 h-20 fill-current text-gray-500" />
            </a>
        </x-slot>

        <!-- Session Status -->
        <x-auth-session-status class="mb-4" :status="session('status')" />

        <!-- Validation Errors -->
        <x-auth-validation-errors class="mb-4" :errors="$errors" />

        <form method="POST" action="{{ route('login') }}">
            @csrf

            <!-- Email Address -->
            <div>
                <x-label for="email" :value="__('Email')" />

                <x-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required autofocus />
            </div>

            <!-- Password -->
            <div class="mt-4">
                <x-label for="password" :value="__('Password')" />

                <x-input id="password" class="block mt-1 w-full"
                                type="password"
                                name="password"
                                required autocomplete="current-password" />
            </div>

            <!-- Remember Me -->
            <div class="block mt-4">
                <label for="remember_me" class="inline-flex items-center">
                    <input id="remember_me" type="checkbox" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" name="remember">
                    <span class="ml-2 text-sm text-gray-600">{{ __('Remember me') }}</span>
                </label>
            </div>

            <div class="flex items-center justify-end mt-4">
                @if (Route::has('password.request'))
                    <a class="underline text-sm text-gray-600 hover:text-gray-900" href="{{ route('password.request') }}">
                        {{ __('Forgot your password?') }}
                    </a>
                @endif

                <x-button class="ml-3">
                    {{ __('Log in') }}
                </x-button>
            </div>
        </form>
    </x-auth-card>
</x-guest-layout>
 --}}


 @extends('layouts.guest_navigation')
@section('content')
<div id="__next" style="position: relative;">
   <div class="container-fluid">
      <div class="row">
         <div class="col">
            
            <section class="section1___tJelh">
               <div class="sectionContent___Dyu4K lightTheme___3q3QE section1Content___1CI1- section1ContentBackground___1sILP">
                  <div class="loginFormHolder___36fEo loginFormHolderBackground___3svTq">
                     <form id="loginForm" class="loginForm___CkkGt loginForm___3jRhB" action="{{ route('login') }}" method="POST">
                      @csrf
                        <div class="container-fluid">
                           <div class="row">
                              <div class="col-12">
                                 <h1 class="d-none d-md-block title___2Px1E">Log in</h1>
                                 <div class="row orDivider"></div>
                                 <div class="col-12 submitErrorMessage___l4g_6">&nbsp;</div>
                                 <div class="textFieldHolder___1kC-8">
                                    <label for="email" class="label___1YNLK textFieldLabel___lEyF6">Email
                                    address</label>
                                    <div class="w-100 textInputHolder___2JutI">
                                      <input type="email" id="email" class="form-control" name="email" placeholder="johnsmith@email.com" maxlength="50" autocomplete="email" class="w-100 textField___2SAzN" required autofocus>
                                      @if ($errors->has('email'))
                                          <span class="text-danger">{{ $errors->first('email') }}</span>
                                      @endif
                                    </div>
                                 </div>
                                 <div class="textFieldHolder___1kC-8">
                                    <label for="password" class="label___1YNLK textFieldLabel___lEyF6">Password</label>
                                    <div class="w-100 textInputHolder___2JutI">
                                       <input type="password" id="password" class="form-control" name="password" value="" maxlength="40" class="w-100 textField___2SAzN passwordHidden___1xcff" required autofocus>
                                      @if ($errors->has('password'))
                                          <span class="text-danger">{{ $errors->first('password') }}</span>
                                      @endif
                                    </div>
                                 </div>
                                 <div class="d-flex justify-content-between justify-content-md-start align-items-center submitHolder___1i_fL">
                                    <div class="container-fluid">
                                       <div class="row align-items-center">
                                          <div class="col-12 d-flex justify-content-md-center">
                                             <div class="ml-auto">
                                                <button type="submit" class="navbar-btn btn btn-sm btn-primary-soft lif">
                                                  Login
                                              </button>
                                             </div>
                                             <div class="spinner-border spinner-border-sm text-light" role="status">
                                                <span class="sr-only">Loading...</span>
                                             </div>
                                             </button>
                                          </div>
                                          <div class="col-12 d-flex justify-content-center forgotPasswordHolder___28dXg">
                                             <a href="/password-reset" class="forgotPassword___1CmgP">
                                             Forgot password?
                                             </a>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </section>
         </div>
      </div>
   </div>
</div>
@endsection