<?php $__env->startSection('title', 'Home - Trellis Legal Intelligence'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-8 py-md-11 border-bottom section-2">
                  <div class="container">
                  </div>   
               </section> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Library/WebServer/Documents/judicial/resources/views/pages/pricing.blade.php ENDPATH**/ ?>