<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="initial-scale=1.0, width=device-width, viewport-fit=cover">
<meta name="format-detection" content="telephone=no">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png?v=5">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png?v=5">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png?v=5">
<link rel="manifest" href="/site.webmanifest?v=5">
<link rel="mask-icon" href="/safari-pinned-tab.svg?v=5" color="#333333">
<link rel="shortcut icon" href="/favicon.ico?v=5">
<meta name="apple-mobile-web-app-title" content="Trellis">
<meta name="application-name" content="Trellis">
<meta name="msapplication-TileColor" content="#888888">
<meta name="theme-color" content="#ffffff">
<title>Rulings Related to judge:anderle AND &quot;wrongful termination&quot; | Trellis</title>
<meta name="title" content="judge:anderle AND &quot;wrongful termination&quot; | Trellis">
<meta name="description" content="Rulings related to judge:anderle AND &quot;wrongful termination&quot; in Superior Court cases - Page 1">
<meta name="keywords" content="legal, litigation, judicial, judge, intelligence, machine learning, artificial intelligence, law, data, superior courts, court house, firm, law suit, file">
<meta name="pid" content="judge:anderle AND &quot;wrongful termination&quot;">
<meta property="og:title" content="Rulings related to judge:anderle AND &quot;wrongful termination&quot; | Trellis">
<meta property="og:type" content="website">
<meta property="og:url" content="http://trellis.law/rulings/judge:anderle%20AND%20%22wrongful%20termination%22">
<meta property="og:description" content="Rulings related to judge:anderle AND &quot;wrongful termination&quot; in Superior Court cases - Page 1">
<meta property="og:page" content="1">
<meta property="og:site_name" content="Trellis">
<meta property="twitter:card" content="summary">
<meta property="twitter:site" content="@trellisrocks">
<meta property="twitter:title" content="Trellis search">
<meta property="twitter:description" content="judge:anderle AND &quot;wrongful termination&quot;">



<link rel="stylesheet" href="css/output.beb94680b546.css" type="text/css" />

<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
<link href="/static/global/fontawesome-5.0.13/web-fonts-with-css/css/fontawesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/lib/email.css" />
<link rel="stylesheet" href="css/trellis_modal.css" />
<style>
        
/***** FONTS *****/
@font-face {
    font-family: 'fontawesome';
    src: url('/static/global/fontawesome-5.0.13/fa-regular-400.woff2') format('woff2'), url('/static/global/fontawesome-5.0.13/fa-regular-400.woff') format('woff');
}

@font-face {
    font-family: 'NotoSans';
    src: url(" /static/global/fonts/NotoSans/NotoSans-Regular.ttf") format('truetype');
}

@font-face {
    font-family: 'NotoSans';
    src: url(" /static/global/fonts/NotoSans/NotoSans-BoldItalic.ttf") format('truetype');
    font-weight: bold;
    font-style: italic;
}

@font-face {
    font-family: 'NotoSans';
    src: url(" /static/global/fonts/NotoSans/NotoSans-Italic.ttf") format('truetype');
    font-style: italic;
}

@font-face {
    font-family: 'NotoSans';
    src: url(" /static/global/fonts/NotoSans/NotoSans-Bold.ttf") format('truetype');
    font-weight: bold;
}

@font-face {
    font-family: 'NotoSerif';
    src: url(" /static/global/NotoSerif-Regular.ttf") format('truetype');
}

@font-face {
    font-family: 'NotoSerif';
    src: url(" /static/global/NotoSerif-BoldItalic.ttf") format('truetype');
    font-weight: bold;
    font-style: italic;
}

@font-face {
    font-family: 'NotoSerif';
    src: url(" /static/global/NotoSerif-Italic.ttf") format('truetype');
    font-style: italic;
}

@font-face {
    font-family: 'NotoSerif';
    src: url(" /static/global/NotoSerif-Bold.ttf") format('truetype');
    font-weight: bold;
}

@font-face {
    font-family: 'OpenSans';
    src: url(" /static/global/fonts/OpenSans/OpenSans-Bold.ttf") format('truetype');
    font-weight: bold;
}

@font-face {
    font-family: 'OpenSans';
    src: url(" /static/global/fonts/OpenSans/OpenSans-BoldItalic.ttf") format('truetype');
    font-weight: bold;
    font-style: italic;
}

@font-face {
    font-family: 'OpenSans';
    src: url(" /static/global/fonts/OpenSans/OpenSans-Italic.ttf") format('truetype');
    font-style: italic;
}

@font-face {
    font-family: 'OpenSans';
    src: url(" /static/global/fonts/OpenSans/OpenSans-Regular.ttf") format('truetype');
}

/***** THEMES *****/
.btn {
    text-transform: capitalize;
}
.main-header-theme {
    background-color: #fafafa;
}

.main-logo-theme {
    background: url('/static/global/trellis-word-logo.svg') no-repeat;
}

.main-logo-motto-theme {
    background: url(/static/global/trellis-word-motto.svg) no-repeat;
}

.main-logo-motto-theme-white {
    background: url(/static/global/trellis-word-motto-white.svg) no-repeat;
}

.logo-green {
    background: url('/static/global/trellis-word-green-300.png') no-repeat;
}

.text-theme {
    color: #0fbe98;
}
span.low-highlight {
    font-weight: 500;
    color: #000;
    background-color: #f5f586;
    font-style: normal;
    padding: 1px 2px;
}
span.highlight {
    background-color: #ffff66;
    padding: 0.2em 0 0.1em 0;
}
span.query-highlight, .search-result em {
    font-weight: 500;
    color: #000000;
    background-color: #f5f586;
    font-style: normal;
    padding: 1px 2px;
}

/***** GLOBAL STYLES *****/
body {
    font-family: Roboto, Open Sans, sans-serif;
    margin: 0;
    padding: 0;
    width: 100%;
    min-height: 100vh;
    font-size: 16px;
    color: #000;
    text-align: left;
    -webkit-tap-highlight-color: rgba(255, 255, 255, 0);
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-overflow-scrolling: touch;
    background: #fafafa !important;
}
a {
    text-decoration: none;
    background-color: transparent;
    color: #0d4fd5;
}
a:hover {
    text-decoration: underline;
    background-color: transparent;
    color: #0d4fd5;
}
button a:hover {
    text-decoration: none!important;
}

h1.title {
    font-size: 2em;
    line-height: 32px;
    color: #000;
    font-weight: normal;
    margin: 0;
    width: 100%;
}

/* tooltip */
.tooltip-inner {
    max-width: 200px;
    font-size: 12px;
    font-family: Helvetica;
    padding: .25rem .5rem;
    color: #FFFFFF;
    text-align: center;
    background-color: #4C4C4C;
    border-radius: .25rem;
}

.bs-tooltip-auto[x-placement^=bottom] .arrow::before, .bs-tooltip-bottom .arrow::before {
    bottom: 0;
    border-width: 0 .4rem .4rem;
    border-bottom-color: #d9d9d9;
}
/*  end tooltip */

fade {
    position: absolute;
    bottom: 0px;

    display: block;

    width: 100%;
    height: 75px;

    background-image: linear-gradient(to bottom,
        rgba(255, 255, 255, 0),
        rgba(255, 255, 255, 0.9)
    100%);
}

/*** CONTAINERS ***/
.container-fluid {
    min-height: 50vw;

}
.search-container{
    margin: 3em auto 7em;
}
.container.footer-container {
    max-width: 1200px;
}

/* PAGE LOOK CONTAINER **/
.page-container {
    position: relative;
    font-style: normal;
    padding: 25px 10px;
    min-height: 50vh;
    font-style: normal;
    font-weight: normal;
    font-size: 12px;
    line-height: 14px;
    color: #000;
}

/* docket container*/
.page-container.docket-container, .page-container.judge-container, .white-container {
    background: #fff;
    padding: 10px 20px;
    border: 1px solid #e1e1e182;
}

.page-container, .container, .container-fluid {
    font-style: normal;
    font-weight: normal;
    font-size: 13px;
    line-height: 14px;
    color: #000;
    max-width: 1600px;
}

@media (min-width:768px) {
    .page-container {
        margin: 3em 2em 7em;
        max-width: 1100px;
        padding: 25px 25px;
    }

}
@media (min-width:1100px) {
    .page-container {
        margin: 3em auto 7em;
        max-width: 1600px;
    }
}

#home-header {
    position: relative;
    display: flex;
    flex-wrap: wrap;
    -webkit-flex-direction: row;
    -webkit-box-direction: row;
    -ms-flex-direction: row;
    flex-direction: row;
    width: 100%;
    height: 5em;
    padding: 0 20px;
    align-items: center;
    z-index: 200;
    box-shadow: 0 2px 4px 0 var(--teflon-20pc);
    color: var(--teflon);
    justify-content: space-between;
    flex-direction: row;
    /* animation magic */
    transition: all 0.3s ease-in;
    -webkit-transition: all 0.3s ease-in;
    -moz-transition: all 0.3s ease-in;
    border-bottom: 1px solid rgb(235, 235, 235);
}

#home-header.shrink-header {
    height: 3.5em;
}

#home-header .headerLeft {
    display: flex;
    height: 100%;
    justify-content: center;
    align-items: center;
    flex: 1;
    justify-content: flex-start;
}

#home-header .headerCenter {
    display: flex;
    height: 100%;
    justify-content: center;
    align-items: center;
    position: relative;
    flex: 2;
}

#header-logo {
    height: 55px;
    width: 140px;
    background-size: contain;
    object-fit: contain;
}

.headerLeft a {
    display: flex;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
}
.header-3 {
    font-family: Open Sans;
    font-weight: 700;
    font-size: 15px;
    color: black;
}
#home-logo {
    height: 35px;
    width: 125px;
    background-size: contain;
    object-fit: contain;
}

/** TRELLIS NAV ORIGINAL **/
.navbar-brand {
    padding: 0.15em 0.55em;
}
.navbar-toggler {
    margin-left: auto;
}
.nav-item {
    display: flex;
    white-space: nowrap;
    align-items: center;
}
.mobile-hide .nav-item {
    margin-left: 20px;
}
.printHeader{
    text-align: center;
    border-bottom: 1.5px solid #ADBDB7;
    padding-bottom: 1.5em;
    margin-bottom: 3em;
    display: none;
}
.printFooter {
    text-align: center;
    border-top: 1.5px solid #ADBDB7;
    padding-top: 1.5em;
    margin-top: 3em;
    display: none;
}
div.printFooter img {
    width: 100px;
}

/** TRELLIS NAV NEW **/
.searchPopulate {
    background: #F5F6F3;
}
.search-snippet {
    font-style: normal;
    font-weight: normal;
    font-size: 13px;
    line-height: 17px;
    color: #000;
    font-family: Open Sans;
}
.nav-container {
    background: #F5F6F3;
}
.nav-container-internal {
    box-shadow: 0 4px 12px 0 rgba(0, 0, 0, 0.05);
    border: none;
    background: #ffffff !important;
}
.trellisNav {
    width: 100%;
    margin-right: auto;
    margin-left: auto;
}
.collapse___2JgcA {
    -webkit-transition: none;
    transition: none;
    padding: 21px;
}
nav[role="navigation"] {
    z-index: 1000;
    background-color: #1a4742;
}
nav.nav-internal[role="navigation"] {
    z-index: 1000;
    background: #FFF;
}
nav[role="navigation"] a, a.trellisLink {
    text-decoration: none;
    border-bottom: 3px solid transparent;
}
@media (min-width: 768px) {
    nav[role="navigation"] {
        position: relative;
        z-index: auto;
    }
}
.nav-search-icon .svg-inline--fa.fa-w-16 {
    width: 11px;
    font-size: 83%;
}

.trellisMenuInternal {
    width: 100%;
}
@media (min-width: 768px) {
    .trellisMenuInternal {
        width: 85%;
    }
}
@media (min-width: 1200px) {
    .trellisMenuInternal {
        width: 80%;
    }
}
.trellisLogo {
    margin-top: 1.0625rem;
    margin-bottom: 1rem;
    margin-left: 1.25rem;
    flex: 1;
    display: inline-block;
    direction: ltr;
}
@media (min-width: 768px) {
    .trellisLogo {
        margin-top: 1.1875rem;
        margin-bottom: 1.1875rem;
        flex: unset;
    }
}
@media (min-width: 992px) {
    .trellisLogo {
        margin-top: 1.5625rem;
        margin-bottom: 1.5625rem;
        margin-left: 1.75rem;
    }

}

.trellisLogoImage {
    max-width: 123px;
    max-height: 54px;
}
.toggle {
    padding: 1rem;
    border: none;
    margin-right: .25rem;
    background-color: transparent;
}
@media (min-width: 768px) {
    .toggle {
        display: none;
    }
}
.trellisIcon {
    width: 24px;
    width: 1.5rem;
    height: 24px;
    height: 1.5rem;
    fill: #174742;
}
.trellisIcon>svg {
    width: 23px;
    width: 1.4375rem;
    height: auto;
}
.menuNavLink {
    width: 100%;
    height: 50px;
    height: 3.125rem;
}
@media (min-width: 768px) {
    .menuNavLink {
        width: auto;
        height: auto;
        border-bottom: 1px solid transparent;
        box-shadow: none;
    }
    .menuNavLink:hover {
        color: #d1d76d;
    }
}
.trellisLink {
    padding-top: .4375rem;
    padding-bottom: .4375rem;
    padding-left: 1.125rem;
    margin: .125rem;
    font-weight: 400;
    font-size: .6rem;
    letter-spacing: 0;
    color: #000;
    text-transform: none;
    margin-right: 2.5em;
}

.trellisLink {
    font-weight: 500;
    letter-spacing: 1px;
    line-height: .8125rem;
    padding-left: 0;
}
.trellisLink {
    font-size: 0.9rem;
}
a.signUpButton {
position: absolute;
top: 22px;
right: 65px;
font-size: 14px;
height: 36px;
letter-spacing: 0.25px;
line-height: 16px;
border-radius: 4px;
}
a.signUpButton:hover {
border-color: #d1d76d;
color: #FFF;
background-color: #d1d76d;
}
a.signUpButton {
    position: static;
    margin-right: 1.25rem;
}
.popover {
    min-width: 300px;
    border: 1px solid #DFDFDF;
    border-radius: 0;
    box-shadow: 0 0.5rem 1.5rem rgb(22 28 45 / 10%);
}
.popover p.btn-account-text{
    font-family: Open Sans;
    font-weight: 400;
    font-size: 15px;
    color: #040404;
}
.popover-body {
    padding: 15px 14px 12px;
    color: #212529;
}
.popover-footer {
    display: none;
    padding: 7px 14px 12px;
    border-top: 1px solid #DFDFDF;
}
.navbar-collapse .nav-item-name {
    font-family: Open Sans;
    font-size: 15px;
    font-weight: 600;
    color: #040404;
    padding: 1.5rem;
}
@media (max-width: 768px) {
    .popover {
        max-width: unset!important;
        top: 72px!important;
        transform: none!important;
        width: 100%!important;
    }
    .navbar-collapse .popover {
        top: 0!important;
        position: relative!important;
        z-index: 0!important;
        border-left: 0;
        border-right: 0;
        box-shadow: 0px 12px 18px -16px #ccc;
        background: #F7F7F7;
    }
    .popover .arrow {
        display: none;
    }

}
@media (min-width: 992px) {
    a.signUpButton {
        margin-right: 3.75rem;
    }
}
.search-sort-button {
    padding: 0.25rem .5rem;
}
@media (min-width: 768px) {
    .search-sort-button {
        width: 100px;
    }
}
.search-sort-button.active, .search-sort-button:hover {
    font-weight: bold;
}
.search-order-icon {
    width: 30px;
    height: 30px;
    background-color: #F5F6F3;
    border-radius: 4px;
}
.search-order-icon.asc {
    background: url('/static/global/search-order-icon-asc.svg') no-repeat center;
}
.search-order-icon.desc {
    background: url('/static/global/search-order-icon-desc.svg') no-repeat center;

}
.plus-icon {
    background: url('/static/global/icon-plus.svg') no-repeat center;
    display: inline-block;

}
.minus-icon {
    background: url('/static/global/icon-minus.svg') no-repeat center;
}
.checkmark-icon {
    background: url('/static/global/icon-checkmark.svg') no-repeat center;
    background-size: contain;
    display: inline-block;
}
.info-icon {
    background: url('/static/global/icon-info.svg') no-repeat center;
    width: 14px;
    height: 14px;
}
.advanced-search-icon {
    width: 11px;
    height: 11px;
    margin-right: 6px;
}

.loaderContainer {
    display: none;
    position: fixed;
    text-align: center;
    top: 0;
    left: 0;
    z-index: 1040;
    width: 100vw;
    height: 100vh;
    margin-top: 104px;
    margin: 0 1em;
}
.loadingScreen {
    position: fixed;
    top: 50%;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translateX(-50%)
}
.loadingScreen .mainLoadingIcon {
    width: 69px;
    margin-bottom: 2em;
}

/******* ## Search Bar Styles ******* ## */
.coreSearchInput {
    width: 100%;
    position: relative;
    border: 1.2px solid #dfe1e5;
    border-top-left-radius: 14px;
    border-bottom-left-radius: 14px;
}
#search-form-wrapper {
    position: relative;
    width: 95%;
    margin: 0 auto;
    margin-bottom: 0em;
    z-index: 1;
}
#search-form-wrapper.rulingSearchBar {
    width: 100%;
    padding-right: 30px;
    padding-left: 30px;
    margin-top: 2em;
    margin-right: auto;
    margin-left: auto;
}
.header-center-wrapper {
    width: 100%;
    background: #fff;
    display: flex;
    box-shadow: none;
    border-radius: 14px;
    z-index: 3;
    height: 44px;
    margin: 0 auto;
}
.header-center-wrapper:hover .coreSearchInput,
.header-center-wrapper.active .coreSearchInput {
    border: 1.2px solid rgb(0, 135, 90) !important;
    border-top-left-radius: 14px;
    border-bottom-left-radius: 14px;
}
#search-form-wrapper .header-center-wrapper:hover .input-group-append > *:first-child,
#search-form-wrapper .header-center-wrapper.active .input-group-append > *:first-child {
    border-top: 1.2px solid rgb(0, 135, 90) !important;
    border-right: 0;
    border-bottom: 1.2px solid rgb(0, 135, 90) !important;
}

@media (min-width: 768px) {
    #search-form-wrapper {
        width: 100%;
        margin-bottom: 0;
    }
}

.SDkEP {
    flex: 1;
    display: flex;
    padding: 5px;
    padding-left: 25px;
}
.a4bIc {
    display: flex;
    flex: 1;
    flex-wrap: wrap;
}
.vdLsw {
    color: transparent;
    flex: 100%;
    white-space: pre;
}

.gLFyf {
    background-color: transparent;
    border: none;
    margin: 0;
    padding: 0;
    color: rgba(0, 0, 0, .87);
    word-wrap: break-word;
    outline: none;
    display: flex;
    flex: 100%;
    -webkit-tap-highlight-color: transparent;
    margin-top: -35px;
}
.gsfi,
.lst {
    font: 16px arial, sans-serif;
    line-height: 34px;
    height: 34px !important;
}
.dRYYxd {
    display: flex;
    flex: 0 0 auto;
    margin-top: -5px;
    align-items: stretch;
    flex-direction: row;
}
.Tg7LZd {
    border-radius: 0 8px 8px 0;
    outline: none;
    flex: 0 0 auto;
    padding-right: 13px;
}

.Tg7LZd {
    border-radius: 0;
    -webkit-border-top-right-radius: 8px;
    width: 44px;
    background: transparent;
    border: none;
    cursor: pointer;
    flex: 0 0 auto;
    padding: 0;
}
.rINcab {
    background: none;
    color: #FFFFFF;
    height: 24px;
    width: 24px;
    margin: auto;
}
.z1asCe {
    display: inline-block;
    fill: currentColor;
    height: 24px;
    line-height: 24px;
    position: relative;
    width: 24px;
}
[type=button]:not(:disabled), [type=reset]:not(:disabled), [type=submit]:not(:disabled), button:not(:disabled) {
    cursor: pointer;
}
.input-group {
    align-items: center;
}
input:focus, textarea:focus {
    outline: none;
}
.form-control {
    font-size: 14px;
}
.form-control::placeholder, .form-control::-webkit-input-placeholder {
    font-size: 16px;
    line-height: 19px;
    color: #ADBDB7;
}
.greenButton{
    border-color: #c4cc3e;
    color: #1a4742;
    background-color: #c4cc3e;
}
.button___2r4xk {
    height: fit-content;
    min-height: 40px;
    padding-right: 1.3125rem;
    padding-left: 1.3125rem;
    border: none;
    font-weight: 500;
    font-size: 17px;
    font-size: 1.0625rem;
    letter-spacing: 0;
}
button:focus {
    outline: 0;
}


.btn-primary:focus, .btn-primary:active, .btn-primary.active, .btn-primary:active:focus, .btn-primary:not([disabled]):not(.disabled):active, .btn-primary:not([disabled]):not(.disabled).active, .show>.btn-primary.dropdown-toggle {
    background-color: rgb(0, 135, 90) !important;
    text-decoration: none!important;
}
.btn-primary {
    color: #fff!important;
    background-color:  rgb(0, 135, 90) !important;
    border-color:  rgb(0, 135, 90) !important;
    box-shadow: none;
    min-width: 100px;
    border-radius: 4px;
}
.btn-primary a {
    color: #fff !important;

}
.btn-primary:hover {
    color: #fff;
    background-color: rgb(0, 102, 68) !important;
}
.btn-primary.focus,
.btn-primary:focus {
    color: #fff;
    background-color: rgb(0, 102, 68) !important;
    border-color: rgb(0, 102, 68) !important;
    box-shadow: 0 0 0 0 rgba(82, 118, 237, 0.5);
}
.navbar {
    -webkit-box-shadow: 0 2px 5px 0 rgba(0, 0, 0, .16), 0 2px 10px 0 rgba(0, 0, 0, .12);
    box-shadow: 0 2px 5px 0 rgba(0, 0, 0, .16), 0 2px 10px 0 rgba(0, 0, 0, .12);
    font-weight: 300;
    min-height: 80px;
    z-index: 5;
}
.btn-primary.inverse {
    background-color: #fff!important;
    color:  rgb(0, 135, 90) !important;
    border-color:  rgb(0, 135, 90) !important;
    box-shadow: none;
    min-width: 100px;
    border-radius: 4px;
}
.btn-primary.inverse:hover {
    color: #fff!important;
    background-color: rgb(0, 102, 68) !important;
}

#id_q {
    width: 100%;
    padding-left: 1em;
    padding-right: 2em;
    line-height: normal;
    transition: all .3s ease-in-out;
    -webkit-transition: all .3s ease-in-out;
    -moz-transition: all .3s ease-in-out;
    background: #F5F6F3;
    /* display: flex; */
    border-radius: 60px;
    border: none;
    z-index: 3;
    height: 44px;
    margin: 0 auto;
    -webkit-appearance: none;
}
#id_q:focus {
    box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.16), 0 0 0 1px rgba(0, 0, 0, 0.08);
}
#id_q.shrink-search-bar {
    height: auto;
}

#id_q.search-header {
    height: 34px;
}

#id_q_results::-webkit-input-placeholder {
    font-style: normal;
    font-weight: normal;
    font-size: 14px;
    align-items: center;
    color: transparent;
}
#id_q::-webkit-input-placeholder,
#id_q::-moz-placeholder,
#id_q::-moz-placeholder,
#id_q::-ms-input-placeholder {
    font-style: normal;
    font-weight: normal;
    font-size: 14px;
    line-height: 12px;
    align-items: center;
    color: transparent;
}
.mobilePlaceHolderText {
    color: #466C68;
    font-size: 10.5px;
    width: 97%;
    margin: 1em auto;
    margin-left: 19px;
}
@media (min-width: 768px) {
    #id_q_results::-webkit-input-placeholder {
        color: #ADBDB7;
    }
}
.avatarIcon {
    position: relative;
    height: 40px;
    width: 40px;
    object-fit: contain;
    z-index: 17;
    background-color: #c2c2c2;
    color: #fff;
    border-radius: 50%;
    cursor: default;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

.avatarIcon span {
    position: absolute;
    top: 50%;
    transform: translateY(-50%) translateX(-50%);
    left: 50%;
    cursor: pointer;
}

/* All */
.home-section {
    margin: 2em 0em;
}

.home-action {
    color: #0fbe98;
    cursor: pointer;
}

a.home-action:visited {
    color: #0fbe98;
}

a.home-action:hover {
    color: #0fbe98;
}

/* Recent Searches */
.recent-search-list {
    padding: 0;
    margin: 0;
}
.recent-search-list a, .recent-search-list a:hover {
    text-decoration: none;
}
.recent-search-list-item {
    display: inline-block;
    font-size: 0.8rem;
    padding: 10px 14px;
    margin: 3px;
    margin-left: 0;
    margin-bottom: 8px;
    background-color: #f4f4f4;
    color: #000000;
    cursor: pointer;
    border-radius: 16px;
}

/* Count Up */
#search-count {
    margin-bottom: 4em;
}
#search-count h2 {
    color: #000000;
    font-weight: 400;
    font-size: 20px;
}

.disable {
    cursor: not-allowed!important;
    opacity: 0.5;
}

span.query-highlight {
    font-weight: bold;
}

.result-count {
    font-style: italic;
}

.recent-search-list-item:hover {
    color: #212529;
    background-color: #e2e6ea;
    border-color: #dae0e5;
}

ul.recent-search-list li.recent-search-list-item a {
    color: #000000;
    text-decoration: none;
}

ul.recent-search-list li.recent-search-list-item a:visited {
    color: #000000;
}

.hidden-print {
    position: fixed;
    bottom: 1em;
    left: 1em;
    z-index: 1000;
}

.btn-circle {
    width: 50px;
    height: 50px;
    padding: 10px 16px;
    font-size: 18px;
    line-height: 1.33;
    border-radius: 25px;
}

/* Browse Topics/ Icons */

.autocomplete {
    /*the container must be positioned relative:*/
    position: relative;
    display: inline-block;
    max-width: 100%;
}

.autocomplete-items {
    position: absolute;
    border: 1px solid #d4d4d4;
    border-bottom: none;
    border-top: none;
    z-index: 99;
    text-align: left;
    max-width: 95%;
    /*position the autocomplete items to be the same width as the container:*/
    left: 0;
    right: 0;
    margin: 0 auto;
}

.autocomplete-items div {
    padding: 0.3em;
    cursor: pointer;
    background-color: #fff;
    border-bottom: 1px solid #d4d4d4;
}

.autocomplete-items div:hover {
    /*when hovering an item:*/
    background-color: #e9e9e9;
}

.autocomplete-active {
    /*when navigating through the items using the arrow keys:*/
    background-color: #e9e9e9 !important;
}

.attached-filter-button {
    border: 1px solid #ced4da;
    border-right: none;
    display: none;
}

.home-index.attached-search-button {
    border-left: 0;
}

.attached-search-button {
    position: absolute;
    top: 63%!important;
    left: 1.5em;
    transform: translateY(-50%);
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    z-index: 100;
    background-color: transparent;
    cursor: pointer;
}

.btn-transparent {
    background-color: transparent!important;
    max-width: 50px;
    line-height: normal;
    border: none;
    padding: 0;
}

.btn-purchase {
    background-color: #0fbe98;
    border-color: #0fbe98;
    color: white;
}
.cta-block {
    margin-top: 0.5em;
    margin-bottom: 1em;
}
.trellisCallToAction.continue-reading-link {
    text-align: center;
    display: block;
}
.trellis-action-btn {
    background-color: #2C4FBA;
    border-color: #2C4FBA;
    border-radius: 4px;
    text-align: center;
    margin: 0;
    font-size: 16px;
    line-height: 17px;
    text-align: center;
    color: #FFFFFF;
    padding: 10px 1.75rem;
    width: fit-content;
    width: -moz-fit-content;
    border: 1px solid transparent;
    margin-bottom: 1em;
}
button.trellis-action-btn a {
    font-size: 16px;
    line-height: 17px;
    text-align: center;
    color: #FFFFFF;
    text-decoration: none;
}
button.trellis-action-btn a:hover {
    text-decoration: none;
}
.text-trellis-green {
    color: #006744 !important;
    font-weight: 500;
    font-family: Roboto;
    font-size: 12px;
}
.trellis-action-btn.trellis-green, .trellis-action-btn.trellis-green2 {
    color: rgb(255, 255, 255) !important;
    background: rgb(0, 135, 90) !important;
}

.trellis-action-btn.trellis-green:not(.inverse):hover, .trellis-action-btn.trellis-green2:hover {
    color: rgb(255, 255, 255) !important;
    background: rgb(0, 102, 68) !important;
    text-decoration: none;
    /*
    Check billing update credit card button before restoring these
    box-shadow: none !important;
    border:none !important;
    */
}
.trellis-green-inverse {
    background: rgb(255, 255, 255) !important;
    color: rgb(0, 135, 90) !important;
    border: 1px solid rgb(0, 135, 90) !important;
}
.trellis-green-inverse:hover {
    background: rgb(255, 255, 255) !important;
    color: rgb(0, 102, 68) !important;
    text-decoration: none;
    border: 1px solid rgb(0, 135, 90) !important;
}
.trellis-green-border{
    background: rgb(255, 255, 255) !important;
    color: rgb(0, 135, 90) !important;
    border-color: rgb(0, 135, 90) !important;
}
.alert-action-btn, .green-action-btn {
    background: rgb(255, 255, 255) !important;
    color: #006744 !important;
    border: 1px solid #0D6E4C!important;
    border-radius: 2.8px;
    font-family: Roboto;
    font-style: normal;
    font-weight: 700;
    font-size: 13px;
    line-height: 1;
    padding: 0.3em 1.5em;
    cursor: pointer;
    float: right;
    display: flex;
    align-items: center;
}

.alert-action-btn:hover:not(.active), .green-action-btn:hover:not(.active) {
    background-color: #006744 !important;
    border-color: #006744 !important;
    color: rgb(255, 255, 255) !important;

}
.alert-action-btn.active, .green-action-btn.active {
    color: rgb(255, 255, 255) !important;
    background: #006744 !important;
    box-shadow: none !important;
    border:none !important;
    cursor: default;

}
.trellis-action-btn.danger, .trellis-action-btn.danger:hover {
    background-color: #ff3547 !important;
    border: 1px solid transparent;

}
.trellis-action-btn.inverse {
    color: #0d4fd5;
    border: 1px solid #0d4fd5;
    background: white;
}
.trellis-action-btn:hover, .trellis-action-btn:active, .trellis-action-btn:focus {
    -webkit-box-shadow: 0 5px 11px 0 rgba(0,0,0,.18), 0 4px 15px 0 rgba(0,0,0,.15);
    box-shadow: 0 5px 11px 0 rgba(0,0,0,.18), 0 4px 15px 0 rgba(0,0,0,.15);
    outline: 0;
}
.trellis-action-btn:not(.inverse):not(.trellis-green2):hover {
    background: #5773C8;

}

.trellis-banner {
    display: flex;
    flex-direction: row;
    background-color: rgb(249, 237, 240);
    padding: 5px 21px;
    justify-content: center;
    align-items: center;
    font-family: Open Sans;
    font-weight: 600;
    font-size: 15px;
    color: rgb(0, 0, 0);
}
.trellis-banner .trellis-badge {
    margin-right: 1em;
}
.trellis-banner p {
    font-family: Open Sans;
    font-weight: 600;
    font-size: 14px;
    color: rgb(0, 0, 0);
    margin: 0;
}
.trellis-banner a {
    text-decoration: underline;
    font-weight: 700;
}
.trellis-banner.banner-danger {
    background-color: rgb(249, 237, 240);
}
.trellis-badge {
    display: inline-block;
    padding: .25em 1em;
    font-weight: 700;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: .25rem;
    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}
.alert-success {
    background-color: RGB(248, 255, 250);
    border-color: RGB(242, 242, 242);
    color: RGB(3, 175, 117);
    font-family: Open Sans;
    font-size: 15px;
    border-left: 7px solid RGB(3, 175, 117);
    border-radius: 0;
    font-weight: 500;
    line-height: 1.2;
}
.alert-danger {
    background-color: rgba(255, 183, 183, 0.09);
    border-color: rgb(242, 242, 242);
    color: rgb(224, 63, 63);
    font-family: Open Sans;
    font-size: 15px;
    border-left: 7px solid rgb(229, 99, 99);
    border-radius: 0;
    font-weight: 600;
}
@media (min-width: 990px) {
    .trellis-action-btn {
        white-space: nowrap;
        margin-bottom: 0;
    }
}
a.see-more-link {
    background: #F5F6F3;
    width: 100%;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
    color: #174742;
    text-transform: none;
    text-align: center;
    padding: 0.55rem;
}
a.see-more-link:hover {
    outline: 0;
    box-shadow: 0 5px 11px 0 rgba(0,0,0,.1), 0 4px 15px 0 rgba(0,0,0,0);
    background: #174742;
    color: #FFF;
    text-decoration: none;
}
.trellis-btn {
    border: 0;
    padding: 10px 15px;
    margin: 10px;
    -webkit-box-shadow: 0 4px 6px rgba(50, 50, 93, .11), 0 1px 3px rgba(0, 0, 0, .08);
    box-shadow: 0 4px 6px rgba(50, 50, 93, .11), 0 1px 3px rgba(0, 0, 0, .08);
    font-weight: 500;
    letter-spacing: .025em;
    -webkit-transition: all .15s ease;
    -o-transition: all .15s ease;
    transition: all .15s ease;
    cursor: pointer;
    display: inline-block;
    background-color: #0d4fd5;
    border-radius: 4px;
    color: white;
    font-size: 16px;
}
.trellis-btn.disabled {
    cursor: default;
    opacity: 0.4;
}
a.trellis-btn:hover {
    text-decoration: none;
}
.trellis-btn.btn-danger {
    color: #fff;
    background-color: #dc3545;
    border-color: #dc3545;
}

.trellis-text-marketing {
    color: #2E7FA8;
    font-size: 1em;
    font-weight: 300;
}

.trellis-btn.btn-sm {
    padding: .5rem 1rem .5rem 1rem;
    border-radius: 0!important;
}

.trellis-btn.trellis-round {
    border-radius: 50px!important;
}

.trellis-btn:hover {
    -webkit-transform: translateY(-2px);
    -ms-transform: translateY(-2px);
    transform: translateY(-2px);
    -webkit-box-shadow: 0 7px 14px rgba(50, 50, 93, .1), 0 3px 6px rgba(0, 0, 0, .08);
    box-shadow: 0 7px 14px rgba(50, 50, 93, .1), 0 3px 6px rgba(0, 0, 0, .08);
}

.trellis-btn.white:hover {
    background-color: #d9d9d9;
}
.trellis-green-anchor {
    font-size: 14px;
    font-weight: 400;
    color: rgb(0, 102, 68);
    border: 1px solid rgb(0, 102, 68);
    padding: 1px 10px;
}
.trellis-banner a:hover {
    text-decoration: none;
    font-weight: 700;
    background-color: rgb(0, 102, 68);
    color: #fff;
}
/* .dropdown-item:focus, .dropdown-item:hover {
    color: rgb(0, 102, 68) !important;
    text-decoration: none;
    border-left: 3px solid #174742;
    background: #F5F6F4;
}

.dropdown-item:active, .dropdown-item:active {
    color: #fff;
    text-decoration: none;
    background-color: #cdd;
} */

/* QUILL CUSTOM CSS */
.inactive .ql-editor {
    line-height:inherit;
    padding: inherit;
}

.inactive .ql-toolbar {
    display:none;
}

.inactive .ql-container.ql-snow {
    border:none;
}
.ql-snow.ql-toolbar button.ql-save, .ql-snow.ql-toolbar button.ql-cancel {
      width: 100%;
      border-width: 1px;
      border-style: solid;
      border-color: rgb(186, 186, 186);
      border-radius: 4px;
      border-image: initial;
}

/******  PAGINATION STYLES ******/
p.trellis-pagination {
    padding-left: 2em;
    padding-right: 2em;
    margin-bottom: 0;
    padding-bottom: 0;
    text-align: center;
    margin-top: 2em;
}
p.trellis-pagination a {
    font-size: 16px;
    line-height: 20px;
    color: #0d4fd5;
    padding: 0 0.125rem;
    border: none;
}
p.trellis-pagination a.deactivate {
    text-decoration: none;
    cursor: default;
    font-weight: bolder;
    color: black;
    pointer-events: none;
}

/******  Breadcrumbs ******/
#breadcrumbs {
    position: relative;
    width: 100%;
    height: 32px;
    font-size: 16px !important;
    line-height: 1.5 !important;
    z-index: 15;
    /* animation magic */
    transition: all 0.3s ease-in;
    -webkit-transition: all 0.3s ease-in;
    -moz-transition: all 0.3s ease-in;
}

#breadcrumbs.shrink-breadcrumbs {}

#breadcrumbs ul {
    padding: 4px 0 0 20px !important;
}

#breadcrumbs li {
    color: rgb(23, 71, 66);
    display: inline;
    font-size: 12px;
    font-weight: 300;
    line-height: 20px;
}

#breadcrumbs li a {
    text-decoration: underline !important;
    color: inherit;
}

#breadcrumbs li a:visited {
    text-decoration: underline !important;
    color: inherit;
}

#breadcrumbs li a:hover {
    text-decoration: underline !important;
    color: black;
}

#breadcrumbs li::after {
    content: ">";
    padding-left: 8px;
    padding-right: 4px;
}

#breadcrumbs li:last-child::after {
    content: "";
    padding: 0;
}

#breadcrumbs span.breadcrumb-query {}

#breadcrumbs span.breadcrumb-query::before {
    content: "“";
}

#breadcrumbs span.breadcrumb-query::after {
    content: "”";
}
.breadcrumb-container {
    width: 100%;
    position: absolute;
}
.breadcrumbs {
    display: flex;
    width: 100%;
    font-family: Open Sans;
    font-weight: 400;
    font-size: 14px;
    line-height: 1.786;
    overflow-x: hidden;
    max-width: 1600px;
    margin: 0 auto;
    padding: 4px 0px;
}
.breadcrumbs .trail {
    position: relative;
    margin-right: 19px;
}
.breadcrumbs .trail.arrow:after {
    content: '';
    position: absolute;
    right: -7px;
    top: calc(50% + 1px);
    display: block;
    border-left: 1px solid black;
    border-top: 1px solid black;
    width: 7px;
    height: 7px;
    float: right;
    transform: translate(50%, -50%) rotate(135deg);
}
.breadcrumbs a, .breadcrumbs .trail {
    text-decoration: none;
    white-space: nowrap;
}
.breadcrumbs a {
    color: RGB(0, 103, 68);
}
.breadcrumbs a:hover {
    cursor: pointer;
    text-decoration: underline;
}
@media (max-width: 768px) {
    .breadcrumbs {
        overflow-x: unset;
        overflow: unset;
        flex-wrap: wrap;
    }
}
.trellis-page-title {
    color: #4A90E2;
    font-size: 20px;
    line-height: 1.5;
    font-weight: 450;
    text-align: center;
}

/* Advanced Search Drop Down */
.search-bar-container {
    margin: 1.75em auto 1.75em;
    width: 100%;
    max-width: 1100px;
    padding-right: 10px;
    padding-left: 10px;
}
.rulingSearchBarContainer {
    margin-bottom: 10px;
    width: 100%;
    max-width: 1100px;
    padding-right: 30px;
    padding-left: 30px;
    margin-right: auto;
    margin-left: auto;
}
.advancedSearchContainer {
    position: relative;
    margin: 5px 5px 0px;
    display: flex;
    flex-direction: row;
    font-weight: normal;
    font-size: 14px;
    line-height: 16px;
    color: #444444;
}
.advancedSearchForm.dropdown-menu {
    background: #F8F8F8;
    box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 8px;
    -webkit-box-pack: center;
    justify-content: center;
    z-index: 99999;
    width: 100%;
    max-width: 1200px;
    padding: 1em 1em 1em;
    margin: 5px 0px 48px;
    /* transform: translate3d(5px, 35px, 0px)!important; */
}
.advancedSearchFormLeft {
    padding-right: 0;
    padding-left: 0;
}
.advancedSearchFormRight {
    padding-left: 0;
    margin-bottom: 10px;
}
.advancedSearchFormRight h3 {
    margin-bottom: 1em;
}
.advancedSearchForm.dropdown-menu.show {
    display: flex;
}
@media (min-width: 768px) {
    .advancedSearchFormLeft {
        padding-right: 3em;
        padding-left: 2em;
        border-right: 1px solid #D8D8D8;
    }
    .advancedSearchFormRight {
        padding-left: 3em;
    }
}
.advancedInputGroup {
    margin-bottom: 1em;
}
.advanced-search-btn {
    font-size: 14px;
    color: #444444;
    padding: 0.5rem 0.75rem;
    background: transparent;
    border-style: none;
}
.advanced-search-btn:hover {
    background-color: rgb(245, 246, 243);
    color: #466C68;
}
.advancedArrowUp {
    display: none;
}
.advancedSearchContainer .dropdown-toggle::after {
    display: none;
}
.searchHintBox {
    display: none;
}
.advanced-search-tips-btn, .advancedSearchButton {
    font-size: 14px;
    line-height: 16px;
    color: #0d4fd5;
    padding: 0.25rem 0.55rem;
    border-style: none;
    font-weight: 500;
    background: transparent;
    text-transform: uppercase;
}
.searchTipsContainer, .searchTipsContainer2, .advancedSearchButtonContainer {
    position: absolute;
    background: #FFFFFF;
    width: 100%;
    position: absolute;
    bottom: -33px;
    left: 0px;
    padding: 5px;
}
.searchTipsContainer {
    border: 1px solid #44444429;
}
.searchTipsContainer2, .advancedSearchButtonContainer {
    outline: 1px solid #44444429;
}
.advancedSearchButtonContainer {
    background-color: rgb(245, 246, 243);
}
#searchTipsDropdownContainer2 {
    left: 0;
    margin-bottom: 48px;
    z-index: -1;
    position: absolute;
    width: 100%;
    top: 33px;
}
#searchTipsDropdownContainer2 .searchDropDownContainer {
    padding-top: 10px;
}
.dateRangeInputContainer {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
}
.customRadioContainer {
    display: flex;
    position: relative;
    padding-left: 25px;
    margin-bottom: 0;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    height: 18px;
    align-items: center;
  }
  @media (min-width: 768px) {
    .customRadioContainer {
        padding-left: 33px;
      }
  }
  /* Hide the browser's default checkbox */
  .customRadioContainer input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
    height: 0;
    width: 0;
  }

  /* Create a custom checkbox */
  .customRadioContainer .checkmark {
    position: absolute;
    top: 0;
    left: 0;
    height: 18px;
    width: 18px;
    background: #FFFFFF;
    border: 1px solid #979797;
    box-sizing: border-box;
    border-radius: 50%;
  }

  /* On mouse-over, add a grey background color */
  .customRadioContainer:hover input ~ .checkmark {
    background-color: #ccc;
  }

  /* When the checkbox is checked, add a blue background */
  .customRadioContainer input:checked ~ .checkmark {
    border: 4px solid #466C68;
  }

  /* Create the checkmark/indicator (hidden when not checked) */
  .customRadioContainer .checkmark:after {
    content: "";
    position: absolute;
    display: none;
  }

  /* Style the checkmark/indicator */
  .customRadioContainer .checkmark:after {
    left: 9px;
    top: 5px;
    width: 5px;
    height: 10px;
    border: solid white;
    border-width: 0 3px 3px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
  }
  .sectionLabel {
    font-style: normal;
    font-weight: 600;
    font-size: 15px;
    line-height: 18px;
    color: #444444;
    margin-bottom: 0.8em;
    display: inline-block;
    max-width: 100%;
  }
  .dateRangeInputContainer label {
    font-style: normal;
    font-weight: 500;
    margin-right: 10px;
    font-size: 13px;
    line-height: 15px;
    color: #444444;
    white-space: nowrap;
  }
  @media (min-width: 900px) {
    .dateRangeInputContainer {
        display: flex;
        flex-direction: row;
        justify-content: start;
    }
    .dateRangeInputContainer label {
        font-size: 15px;
        line-height: 18px;
        margin-right: 25px;
    }
  }

  .advancedSearchForm input.form-control {
    background: #FFFFFF;
    border: 1px solid #CED0DA;
    box-sizing: border-box;
    border-radius: 4px;
    padding: 1.375rem .75rem;
  }

@media (min-width: 768px) {
    .searchHintBox {
        display: flex;
        align-items: center;
    }
    .searchHintBox p {
        font-size: 12px;
        margin-bottom: 0;
    }
    .searchHintBox svg {
        height: 22px;
        width: 32px;
    }
}

/* Example of Searches */
.exampleSearchesContainer {
    margin: 6em 12px 0px;
}
.exampleSearchesContainer h3 {
    font-size: 15px;
    font-weight: 400;
    color: rgb(0, 102, 68) !important;
}
.examplesBox {
    padding: 1em 0em;
    border-top: 1px solid #D8D8D8;
    border-bottom: 1px solid #D8D8D8;
    margin: 0;
}
.searchContent {
    display: flex;
    flex-direction: column;
    margin-bottom:1em;
}
.searchContent h4 {
    font-weight: 500;
    font-size: 16px;
    line-height: 19px;
}
.searchContent a {
    font-size: 14px;
    font-weight: 400;
    line-height: 26px;
    color: #444444;
}
.searchContent span {
    display: flex;
    align-items: center;
}
.searchContent a:hover {
    font-weight: 400;
    text-decoration: underline;
    color: #0d4fd5;
}
.searchContent svg {
    width: 15px;
    min-width: 15px;
    margin-right: 1rem;
}

/* Seach Bar Dropdown*/
#searchTipsDropdownContainer, #searchTipsDropdownContainer2 {
    display: none;
}
.dropDownContainer {
    background-color: rgb(255, 255, 255);
    box-shadow: rgba(0, 0, 0, 0.12) 0px 2px 8px;
    border-image: initial;
    border-radius: 0px 0px 4px 4px;
    border: 1px solid rgb(221, 229, 234);
}
#searchTipsDropdownContainer2 .dropDownContainer {
/* outline: 1px solid rgb(221, 229, 234); */
}
.searchDropDownContainer {
    background-color: rgb(255, 255, 255);
    padding: 16px;
    padding-top: 26px;
    margin-left: 2px;
}
.tipsTitle {
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    font-style: normal;
    font-weight: 500;
    font-size: 12px;
    line-height: 16px;
    color: #466C68;
    margin-bottom: 0.5rem;
}
.tipContent:not(:last-child) {
    margin-bottom: 0px;
}
.tipContent {
    -webkit-box-align: center;
    align-items: center;
    color: rgb(0, 0, 0);
    display: flex;
    font-size: 0.875rem;
    font-size: 14px;
    line-height: 22px;
    color: #5e5e5e;
}
.tipContent span:nth-of-type(1) {
    width: 50%;
    font-weight: 600;
    font-size: 14px;
    line-height: 30px;
    color: #444444;
}
.tipContent span:nth-of-type(2) {
    width: 90%;
    line-height: normal;
}
.tipContent span:nth-of-type(3) {
    display: none;
}
@media (min-width:768px) {
    .tipContent span:nth-of-type(1) {
        width: 20%;
        font-size: 13px;
    }
    .tipContent span:nth-of-type(2) {
        width: 30%;
        margin-right: 27px;
    }
    .tipContent span:nth-of-type(3) {
        display: block;
    }
}
@media (min-width:1000px) {
    .tipContent span:nth-of-type(1) {
        width: 37%;
    }
}
.tipIcon {
    margin-top: 2px;
    margin-right: 12px;
}
.tipText {
    color: rgb(42, 34, 142);
    cursor: pointer;
    display: inline;
    font-weight: 500;
    text-decoration: none;
}
.headerDivider {
    border-left: 1px solid #38546d;
    border-right: 1px solid #16222c;
    height: auto;
}

/** MOBILE RESPONSIVE - SCREEN CUTOFFS **/

/* Custom, iPhone Retina */

@media  only screen and (min-width: 320px) and (max-width:479px) {
    #home-logo {
        height: 35px;
        width: 35px;
        background: url("/static/global/trellis-logo-simplified.svg") center/contain no-repeat;
    }
    #breadcrumbs {
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .home-left-column {
        flex: 100%;
        max-width: 100%;
    }
    .home-right-column {
        flex: 100%;
        max-width: 100%;
    }
    .icon-col {
        flex: 1;
    }


}

@media (max-width: 1178px) {
    .page-container.docket-container,#commentsContainer{
        max-width: 94%;
    }
    #commentsContainer {
        margin-bottom: 30px;
    }
}

@media (min-width: 1178px) {
    #marketing-block {
        padding: 0 13em;
    }
}
.headerRight {
    display: flex;
    margin-right: 1em;
    z-index: 5000;
    align-items: center;
}
.headerRight > *:not(:last-child) {
    margin-right: 0.5em;
    margin-top: 4px;
}

@media (min-width: 768px) {
    .headerRight {
        margin-left: auto;
        position: relative;
        top: unset;
        right: 0.25rem;
    }
}
@media (min-width: 835px) {
    .headerRight {
        margin-right: 1em;
    }
}
@media (min-width: 1100p) {
    .headerRight {
        margin-right: 3.75rem;
    }
}
#logo {
    text-align: left;
    font-size: 20px;
    position: fixed;
    top: 0.625em;
    left: 0.75em;
    font-weight: bold;
    z-index: 17;
}

#logo {
    border: 0; // font: 0/0 a;
    text-shadow: none;
    color: transparent;
    background: url(/static/global/trellis-word-black-128.png);
    background-size: 64px 17px;
    width: 64px;
    height: 17px;
    top: 15px;
    left: 8px;
}

#logo a {
    text-decoration: none;
    color: inherit;
}

#logolink {
    display: block;
}

#account-menu {
    width: 250px;
    background-color: #fff;
    border: 1px solid #ccc;
    border-color: rgba(0, 0, 0, .2);
    -webkit-box-shadow: 0 2px 10px rgba(0, 0, 0, .2);
    box-shadow: 0 2px 10px rgba(0, 0, 0, .2);
    font-size: 15px;
    line-height: 20px;
    font-weight: 300;
    overflow: hidden;
    max-height: calc(100vh - 148px);
}
.btn-account-menu {
    position: relative;
    font-size: 12px;
    line-height: 18px;
    color: #174742;
    text-transform: none;
    text-align: center;
    padding: 5px 10px;
    background: transparent;
    border: 1px solid transparent;
    letter-spacing: .025em;
    -webkit-transition: all .15s ease;
    -o-transition: all .15s ease;
    transition: all .15s ease;
    cursor: pointer;
    -webkit-box-shadow: none;
    box-shadow: none;
    display: flex;
    border-radius: 20px;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
.btn.btn-account-menu svg.profile-icon {
    margin-bottom: 4px;
}
p.btn-account-text {
    position: relative;
    margin-bottom: 0;
    color: #1E1E1E;
    font-size: 14px;
}
.btn.btn-account-menu svg.arrow-caret {
    position: absolute;
}
.btn.btn-account-menu .dropdown-toggle::after {
    position: absolute;
    top: 9px;
    right: -14px;
}
.trellisDropdown * {
    font-size: 14px;
    font-weight: 500;
    color: rgb(0, 102, 68) !important;
}
a.search-sort-button {
    color: #000;
}
.trellisDropdown .dropdown-menu {
    margin-top: 0.5rem;
}
.trellisDropdown a:hover {
    text-decoration: none;
}

.trellisDropdown ul li a {
    text-decoration: none;
    font-size: 14px;
    font-weight: 500;
    color:rgb(0, 102, 68);
}
.trellisDropdown ul li {
    padding: 11px;
    border-left: 2px solid transparent;
}
.trellisDropdown ul li:hover {
    border-left: 2px solid rgb(0, 102, 68) !important;
    background: #F5F6F4;
    color: #000 !important;
}
.trellisDropdown ul li.active {
    border-left: 2px solid #174742;
    background: #F5F6F4;
}
@media (min-width:835px) {
    .btn.btn-account-menu {
        font-size: 15px;
        padding: 10px 20px;
        line-height: 20px;
        color: #1E1E1E;
    }
}
.btn.btn-account-menu:hover {
}

#account-menu a {
    display: block;
    margin: 0;
    padding: 0.5em 3.5em 0.5em 1.5em;
    border-left: 3px solid transparent;
    background: transparent;
    color: #000 !important;
}

#account-menu a, #account-menu a:hover, #account-menu a:visited, #account-menu a:hover, #account-menu a:active {
    text-decoration: none;

}
 #account-menu a:hover, #account-menu a:visited, #account-menu a:hover, #account-menu a:active {
    text-decoration: none;
    border-left: 3px solid rgb(0, 102, 68) !important;
    background: #F5F6F4;
    color: rgb(0, 102, 68) !important;
}

#account-menu a.free-trial {
    color: blue;
}

#account-menu .line2 {
    font-size: 80%;
}
#container {
    position: relative;
    margin: 0;
    width: 100%;
}
#container.shrink-container {
    
    top: 3.25em;
    
}
input.search {
    padding: 0.3em;
    font-size: inherit;
}


/* Footer */
#footer {
    background: #1A4742;
    padding-top: 2.5em;
    padding-bottom: 1em;
}
#footer p {
    margin-bottom: 0.5em;
    white-space: nowrap;
}
#footer hr {
    border: 1px solid white;
}
#footer .footer-container {
    min-height: 0;
}
#footer .copyright-text {
    display: flex;
    flex-direction: column;
}
@media (min-width: 768px) {
    #footer .copyright-text {
        flex-direction: row;
    }
}
.trellis-popup-modal h5 {
    margin: 0;
    font-size: 25px;
    color: #000000;
    font-weight: 600;
    font-family: Montserrat;    
}
h5.text-white {
    font-size: 16px !important;
    margin: 0 0 10px;
    padding: 4px 0px;
    font-weight: 700;
}
#footer a, #footer a:visited {
    font-style: normal;
    font-weight: normal;
    font-size: 16px !important;
    color: #FFFFFF;
    text-decoration: none;
    padding: 0.55rem 0rem !important;
}

img.brand {
    margin-bottom: 20px;
}
.space-1 {
    color: #fff;
}
.nav-link {
    padding: 0.3rem 0rem !important;
}
@media (min-width: 990px) {
    #footer a, #footer a:visited {
        font-size: 100%;
    }
}
#footer .copyright-text, #footer .copyright-text a {
    font-style: normal;
    font-weight: normal;
    font-size: 14px;
    line-height: 17px;
    color: #fff;
    margin-right: 1.5em;
    margin-top: 0.5rem;
}
@media (min-width: 768px) {
    #footer .copyright-text, #footer .copyright-text a {
        margin-top: 0;
    }
}
#footer .copyright-text a:hover {
    color: white;
    text-decoration: underline;
}
#footer .social-icons a {
    margin: 0 1em;
    font-size: 80%;

}
#footer a:hover, #footer a:focus, #footer .social-icons>li>a:hover, #footer .social-icons>li>a:focus {
    color: #d1d76d;
}

#footer .social-icons a.tw-ic:hover, #footer .social-icons a.tw-ic:focus {
    color: #1da1f2
}

#footer .social-icons a.fb-ic:hover, #footer .social-icons a.fb-ic:focus {
    color: #3b5998;
}

#footer .social-icons a.li-ic:hover, #footer .social-icons a.li-ic:focus {
    color: #0077b5
}
.footer-icon {
    max-height: 54px;
    max-width: 138px;
}
.social-icons h3 {
    margin-top: 0;
    font-style: normal;
    font-weight: normal;
    font-size: 14px;
    line-height: 17px;
    color: #fff;
    text-align: center;
}

@media  only screen and (max-width: 600px), screen and (min-device-width: 320px) and (max-device-width: 1024px) {
    .attached-search-button {
        right: 0.5em;
    }
}

/* box that provides margins */

.box {
    position: relative;
    min-height: 50vw;
    margin: 2em 2em 0.5em 2em;
    padding-bottom: 4em;
}

/* tooltips */
.tooltip {
    position: relative; 
    display: inline-block;
}
.tooltip .tooltiptext {
    visibility: hidden;
    background-color: #444;
    color: #fff;
    text-align: center;
    padding: 5px 0;
    border-radius: 6px;
    position: absolute;
    z-index: 2;
    display: inline-block;
}
.tooltip a {
    color: white;
    text-decoration: underline;
}
.tooltip:hover .tooltiptext {
    visibility: visible;
}
.tooltip:hover .tooltiptext:hover {
    visibility: hidden;
}
.tooltip .tooltiptext {
    padding: 0.2em 0.6em 0.2em 0.6em;
    left: 50%;
    white-space: nowrap;
    top: calc(0.2em);
    transform: translate(-50%, 100%);
}
.tooltip .tooltiptext::after {
    z-index: 1;
    content: " ";
    position: absolute;
    bottom: 100%;
    left: 50%;
    margin-left: -6px;
    border-width: 6px;
    border-style: solid;
    border-color: transparent transparent #444 transparent;
}

/* global tag styles */
h1 {
    font-size: 22px;
    font-weight: bold;
    margin-top: 0.5em;
}

h2 {
    font-size: 20px;
    font-weight: bold;
    margin-top: 0.5em;
}

h3 {
    font-size: 18px;
    font-weight: bold;
    margin-top: 0.5em;
}

h4 {
    font-size: 16px;
    font-weight: bold;
    margin-top: 0.5em;
}

input {
    padding: 8px;
    font-size: 16px;
    line-height: initial;
}
.searchInput {
    margin-bottom: 13px;
    font-weight: normal;
    font-size: 14px;
    line-height: 17px;
}

a.trellis-link, a.trellis-link:visited {
    display: block;
    padding: 0.5rem 1.5rem;
    color: #f4f4f4;
    text-decoration: none;
    background-color: transparent;
    -webkit-text-decoration-skip: objects;
    font-weight: 300;
    font-size: 18px;
}
a.secondary-link {
    font-style: normal;
    font-weight: normal;
    font-size: 14px;
    line-height: 17px;
    text-transform: none;
    color: #0d4fd5;

}
a.trellis-link:hover {
    color: #0d4fd5;
    text-decoration: underline;
}

a.trellis-link.black-text {
    color: #000000;
    font-weight: 500;
}

a.viewed:not(.trellisLink):not(.signUpButton) {
    color: #609;
}

a.trellis-anchor {
    color: #0d4fd5;
    text-decoration: none;
}

a.trellis-anchor.text-white {
    color: white;
    text-decoration: none;
}

a.trellis-anchor:hover {
    color: #0056b3;
    text-decoration: none;
}

.btn-sm {
    padding: .5rem 1rem .5rem 1rem;
    border-radius: .3rem;
}

a.btn, a.btn:hover, a.viewed+btn, a.btn:visited {
    color: white;
}
.de-anchor, .de-anchor:hover, .de-anchor:visited {
    text-decoration: none;
}
a.deactivate:not(.btn):not([href]):not([tabindex]), a.deactivate:not(.btn):not([href]):not([tabindex]):focus, a.deactivate:not(.btn):not([href]):not([tabindex]):hover, a.deactivate {
    text-decoration: none;
    cursor: default;
    font-weight: bolder;
    color: black;
    pointer-events: none;
}
a.disabled.sealed, .search-result h2 a.disabled.sealed {
    color: #a7a7a7;
    cursor: not-allowed;
}

h3.photo-caption {
    font-weight: bold;
    font-size: 15px;
    line-height: 18px;
    color: #000 !important;
    padding: 8px 16px !important;
}

/* Buttons */
.btn-secondary {
    background-color: gray;
    border-color: gray;
}

.btn-outline-primary {
    color: steelblue !important;
}

.btn-outline-primary:hover {
    color: white !important;
}

.btn-outline-secondary {
    color: gray !important;
}

.btn-outline-secondary:hover {
    color: white !important;
}
.errorContainer {
    min-height: 30vw;
}
/* Django Debug Toolbar */
/*
#djDebug {
    display: none !important
}
#djDebugToolbarHandle.djdt-hidden {
    top: 60px !important;
}
.disabled:not(.paginate_button) {
    color: #000;
    background-color: #e0e0e0!important;
    border: 0;
}
*/

/* TABS */
#profileTabs a:hover {
    background: rgba(173, 189, 183, 0.704257);
    color: #1A4742;
}
#profileTabs a.active {
    background: #476C68;
    color: white;
}
#directoryTabs {
    width: 100%;
    position: absolute;
    top: -46px;
    left: 0px;
    display: flex;
    overflow: scroll;
}
#profileTabs {
    width: 250px;
    height: fit-content;
    display: flex;
    flex-direction: column;
    overflow: scroll;
    box-shadow: 0 0.5rem 1.5rem rgb(22 28 45 / 10%);
}
@media (max-width: 768px) {
    #profileTabs {
        display: none;
    }
}
#directoryTabs a, #profileTabs a {
    margin-right: .3em;
    white-space: nowrap;
    background: #f0f0f0;
    color: #456D68;
    padding: 0.75rem;
    font-size: 17px;
    font-weight: 500;
    display: inline-block;
    text-align: center;
    align-items: flex-start;
    border: 0;
    cursor: pointer;
    min-width: 175px;
    min-height: 45px;
}
#profileTabs a {
    width: 100%;
    background: #FFF;
    color: rgb(0, 103, 68);
    font-family: Roboto;
    font-size: 15px;
    font-weight: 500;
    text-align: left;
    border: 1px solid rgb(220, 231, 222);
    padding: 1em 2em;
}
#profileTabs a:not(:first-child) {
    border-top: 0;
}
#profileTabs .tabLink.tabHeader {
    cursor: default;
    border-bottom: 4px solid rgb(0, 102, 68) !important;
}
#directoryTabs a:hover, #profileTabs a:hover {
    background: #FFF !important;
    color: rgb(0, 102, 68) !important;
    text-decoration: none;
    border-bottom: 4px solid rgb(0, 102, 68) !important;
}
#directoryTabs a.active, #profileTabs a.active {
    background: #FFF !important;
    color: rgb(0, 102, 68) !important;
    text-decoration: none;
    border-bottom: 4px solid rgb(0, 102, 68) !important;
}
#profileTabs a.active:not(.tabHeader), #profileTabs a:hover:not(.tabHeader) {
    background: #FFF !important;
    border-bottom: 1px solid rgb(220, 231, 222) !important;
    background-color: rgb(245, 246, 244) !important;
}
#profileTabs a.active:not(.tabHeader) {
    border-left: 4px solid rgb(0, 102, 68) !important;
}
.label{
    font-weight: 500;
    font-size: 14px;
}
@media (max-width: 767px) {
    #profileTabs a {
        min-width: 33%;
    }
}

@media (min-width: 400px) {
    #directoryTabs, #profileTabs {
        overflow: unset;
    }
}


/* Trellis Dropdown */
.datalist-wrapper {
    position: relative;
    margin-right: 1em;
    margin-bottom: 1em;
}
.wrapper-dropdown {
    border: 1.2px solid #dfe1e5;
    height: 45px;
    margin-bottom: 1em;
}
.wrapper-dropdown {
    position: relative;
    width: 250px;
    margin: 0 auto;
    padding: 12px 15px;
    background: #fff;
    border-radius: 9px;
    cursor: pointer;
    outline: none;
    transition: all 0.3s ease-out;
}
.wrapper-dropdown:after { /* Little arrow */
    content: "";
    width: 0;
    height: 0;
    position: absolute;
    top: 50%;
    right: 15px;
    margin-top: -3px;
    border-width: 6px 6px 0 6px;
    border-style: solid;
    border-color: rgb(0, 102, 68) transparent;
}
.wrapper-dropdown .dropdown {
    position: absolute;
    top: 37px;
    left: -1px;
    right: 0;
    background: #fff;
    border-radius: 0;
    border: 1.2px solid #dfe1e5;
    border-top: none;
    border-bottom: none;
    list-style: none;
    transition: all 0.3s ease-out;
    max-height: 0;
    overflow: hidden;
    overflow-y: auto;
    padding: 0;
    width: 250px;
    padding-top: 8px;
    display: none;
    border-bottom-right-radius: 9px;
    border-bottom-left-radius: 9px;
    z-index: 1000;
}
.wrapper-dropdown .dropdown li {
    padding: 0 10px ;
}

.wrapper-dropdown .dropdown li a {
    display: block;
    padding: 10px 0;
    border-bottom: 1px solid #e6e8ea;
    font-size: 15px;
    font-weight: 400;
    font-family: 'Roboto';
    color: #333;
    text-decoration: none;
}

.wrapper-dropdown .dropdown li:last-of-type a {
    border: none;
}

.wrapper-dropdown .dropdown li i {
    margin-right: 5px;
    color: inherit;
    vertical-align: middle;
}
/* Hover state */
.wrapper-dropdown .dropdown li:hover a {
    color: #006744;
    font-weight: 500;
}
/* Active State */
.wrapper-dropdown.active {
    border-radius: 9px;
    color: #006744;
    font-weight: 500;
    font-family: Roboto;
}
.wrapper-dropdown.active .dropdown {
    border-bottom: 1.2px solid #dfe1e5;
    max-height: 400px;
    display: block;
}
.datalist-wrapper h3 {
    position: absolute;
    top: 0;
    left: 10px;
    z-index: 5;
    font-family: Roboto;
    font-size: 12px;
    font-weight: 400;
    color: #616161;
}
.datalist-wrapper .dropdown-value {
    position: absolute;
    top: 19px;
    left: 10px;
    font-size: 14px;
    font-weight: 500;
    color: #006744;
    font-family: Roboto;
}

@media (min-width: 768px) {
    .datalist-wrapper {
        margin-bottom: 0;
    }
}
/*** END Trellis Dropdown ***/

/** Alert Popup **/
.track-popup {
    display: none;
    position: fixed;
    top: 93px;
    right: 9px;
    border: 4px solid #0D6E4C;
    background: #FFFFFF;
    z-index: 500;
    width: 364px;
    border-radius: 6px;
    box-shadow: 0px 1px 5px 2px silver;
}
.track-popup .close {
    position: absolute;
    right: 4px;
}
.track-popup .popup-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 10px 23px 18px;
}
.track-popup .popup-content h3 {
    font-family: Roboto;
    font-size: 14px;
    color: #000000;
    text-transform: none;
    line-height: initial;
    letter-spacing: normal;
    text-align: center;
    margin-top: 1em;
    margin-bottom: 1em;
    white-space: nowrap;
}
.track-popup .popup-content p {
    background: #F5F586;
    font-weight: 600;
    font-family: Roboto;
    font-size: 14px;
    padding: 7px;
    width: 100%;
    text-align: left;
}
.track-popup .alert-action-btn {
    background: #0D6E4C!important;
    color: white!important;
    font-size: 13px;
    font-family: Roboto;
    font-weight: 700;    
    padding: 10px 5em;
    margin-top: 1.5em;
}
/** End Alert Popup **/

/** Alert Overlay **/
.track-overlay {
    display: none;
    position: fixed;
    bottom: 0;
    background-color: #DCE7DE;
    left: 0;
    width: 100%;
    padding: 25px 15px;
    width: 100%;
    z-index: 100;
}
.track-overlay .overlay-text {
    display: flex;
    align-items: center;
    margin-right: 1.5em;
}
.track-overlay .overlay-content {
    display: flex;
    flex-direction: row;
    align-items: center;
    font-family: Roboto;
    font-weight: 500;
    font-size: 14px;
    color: #000000;
    margin: 0 auto;
    width: fit-content;
}
.track-overlay .overlay-checkbox {
    display: flex;
    align-items: center;
    margin-left: 6em;
}
.track-overlay .form-check {
    position: relative;
    display: flex;
    padding-left: 1.25rem;
    align-items: center;
}
.track-overlay .form-check .form-check-input {
    margin-top: 0;
    margin-left: -0.85rem;
    height: 18px;
    width: 18px;
    background-color: #eee;    
}
.alert-overlay-btn.alert-action-btn img {
    width: 14px;
    margin-right: 0.15em;
}
.alert-action-btn.active.alert-overlay-btn img {
    filter: invert(1) sepia(1) saturate(0) hue-rotate(175deg);
}
.alert-overlay-btn.alert-action-btn {
    padding: 5px 11px;
}
@media (max-width: 768px) { 
    .track-overlay {
        display: none!important;
    }
}
@media (min-width: 992px) {
    .alert-overlay-btn.alert-action-btn img {
        margin-right: 7px;
    }    
    .track-overlay {
        padding: 13px 0px;
    }
}
/** End Alert Overlay **/

/** Custom Switch **/
.custom-control {
    position: relative;
    display: block;
    min-height: 1.7rem;
    padding-left: 1.5rem;
}
.custom-control-inline {
    display: -webkit-inline-box;
    display: inline-flex;
    margin-right: 1rem;
}
.custom-control-input {
    position: absolute;
    left: 0;
    z-index: -1;
    width: 1rem;
    height: 1.35rem;
    opacity: 0;
}
.custom-control-input:checked ~ .custom-control-label::before {
    color: #fff;
    border-color:  rgb(0, 102, 68);
    background-color:  rgb(0, 102, 68);
    box-shadow: none;
}
.custom-control-input:focus ~ .custom-control-label::before {
    box-shadow: none, none;
}
.custom-control-input:focus:not(:checked) ~ .custom-control-label::before {
    border-color: #a7b9f6;
}
.custom-control-input:not(:disabled):active ~ .custom-control-label::before {
    color: #fff;
    background-color: #d5defb;
    border-color: #d5defb;
    box-shadow: none;
}
.custom-control-input:disabled ~ .custom-control-label,
.custom-control-input[disabled] ~ .custom-control-label {
    color: #869ab8;
}
.custom-control-input:disabled ~ .custom-control-label::before,
.custom-control-input[disabled] ~ .custom-control-label::before {
    background-color: #f1f4f8;
}
.custom-control-label {
    position: relative;
    margin-bottom: 0;
    vertical-align: top;
}
.custom-control-label::before {
    position: absolute;
    top: 0.35rem;
    left: -1.5rem;
    display: block;
    width: 1rem;
    height: 1rem;
    pointer-events: none;
    content: "";
    box-shadow: none;
}
.custom-control-label::after {
    position: absolute;
    top: 0.35rem;
    left: -1.5rem;
    display: block;
    width: 1rem;
    height: 1rem;
    content: "";
    background: no-repeat 50%/50% 50%;
}
.custom-checkbox .custom-control-label::before {
    border-radius: 0.375rem;
}
.custom-checkbox .custom-control-input:checked ~ .custom-control-label::after {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8' viewBox='0 0 8 8'%3e%3cpath fill='%23FFFFFF' d='M6.564.75l-3.59 3.612-1.538-1.55L0 4.26l2.974 2.99L8 2.193z'/%3e%3c/svg%3e");
}
.custom-checkbox .custom-control-input:indeterminate ~ .custom-control-label::before {
    border-color:  rgb(0, 102, 68);
    background-color:  rgb(0, 102, 68);
    box-shadow: none;
}
.custom-checkbox .custom-control-input:indeterminate ~ .custom-control-label::after {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='4' height='4' viewBox='0 0 4 4'%3e%3cpath stroke='%23FFFFFF' d='M0 2h4'/%3e%3c/svg%3e");
}
.custom-checkbox .custom-control-input:disabled:checked ~ .custom-control-label::before {
    background-color: rgba(51, 94, 234, 0.5);
}
.custom-checkbox .custom-control-input:disabled:indeterminate ~ .custom-control-label::before {
    background-color: rgba(51, 94, 234, 0.5);
}
.custom-radio .custom-control-label::before {
    border-radius: 50%;
}
.custom-radio .custom-control-input:checked ~ .custom-control-label::after {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='%23FFFFFF'/%3e%3c/svg%3e");
}
.custom-radio .custom-control-input:disabled:checked ~ .custom-control-label::before {
    background-color: rgba(51, 94, 234, 0.5);
}
.custom-switch {
    padding-left: 3rem;
}
.custom-switch .custom-control-label::before {
    left: -3rem;
    width: 2.5rem;
    pointer-events: all;
    border-radius: 0.5rem;
}
.custom-switch .custom-control-label::after {
    top: calc(0.35rem + 0px);
    left: calc(-3rem + 0px);
    width: 1rem;
    height: 1rem;
    background-color: #abbcd5;
    border-radius: 0.5rem;
    -webkit-transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, -webkit-transform 0.15s ease-in-out;
    transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, -webkit-transform 0.15s ease-in-out;
    transition: transform 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    transition: transform 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, -webkit-transform 0.15s ease-in-out;
}
@media (prefers-reduced-motion: reduce) {
    .custom-switch .custom-control-label::after {
        -webkit-transition: none;
        transition: none;
    }
}
.custom-switch .custom-control-input:checked ~ .custom-control-label::after {
    background-color: #d9e2ef;
    -webkit-transform: translateX(1.5rem);
    transform: translateX(1.5rem);
}
.custom-switch .custom-control-input:disabled:checked ~ .custom-control-label::before {
    background-color: rgba(51, 94, 234, 0.5);
}
.custom-select {
    display: inline-block;
    width: 100%;
    height: calc(1.6em + 1.625rem + 2px);
    padding: 0.8125rem 3.25rem 0.8125rem 1.25rem;
    font-size: 1.0625rem;
    font-weight: 400;
    line-height: 1.6;
    color: #161c2d;
    vertical-align: middle;
    background: #fff
        url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3e%3cpolyline fill='none' stroke='%23C6D3E6' stroke-width='2' stroke-linecap='round' points='6 9 12 15 18 9'/%3e%3c/svg%3e")
        no-repeat right 1.25rem center/auto 50%;
    border: 1px solid #f1f4f8;
    border-radius: 0.375rem;
    box-shadow: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
}
.custom-select:focus {
    border-color: #a7b9f6;
    outline: 0;
}
.custom-select:focus::-ms-value {
    color: #161c2d;
    background-color: #fff;
}
.custom-select[multiple],
.custom-select[size]:not([size="1"]) {
    height: auto;
    padding-right: 1.25rem;
    background-image: none;
}
.custom-select:disabled {
    color: #869ab8;
    background-color: #f1f4f8;
}
.custom-select::-ms-expand {
    display: none;
}
.custom-select:-moz-focusring {
    color: transparent;
    text-shadow: 0 0 0 #161c2d;
}
.custom-select-sm {
    height: calc(1.6em + 1.125rem + 2px);
    padding-top: 0.5625rem;
    padding-bottom: 0.5625rem;
    padding-left: 1rem;
    font-size: 1.0625rem;
}
.custom-switch .custom-control-label::before {
    top: 0.1625rem;
    height: 1.375rem;
    border-radius: 0.6875rem;
}
.custom-switch .custom-control-label::after {
    top: 0.35rem;
    left: -2.8125rem;
    background-color: rgb(0, 102, 68);
}
.custom-switch .custom-control-input:checked ~ .custom-control-label::after {
    background-color: #fff;
    -webkit-transform: translateX(1.125rem);
    transform: translateX(1.125rem);
}
.custom-switch-dark .custom-control-label::before {
    background-color: rgba(255, 255, 255, 0.2);
}
.custom-switch-dark .custom-control-label::after {
    background-color: #fff;
}
.custom-switch-dark .custom-control-input:checked ~ .custom-control-label::before {
    background-color: #fff;
}
.custom-switch-dark .custom-control-input:checked ~ .custom-control-label::after {
    background-color:  rgb(0, 102, 68);
}
.custom-select-sm {
    background: #fff
        url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3e%3cpolyline fill='none' stroke='%23C6D3E6' stroke-width='2' stroke-linecap='round' points='6 9 12 15 18 9'/%3e%3c/svg%3e")
        no-repeat right 1rem center/auto 50%;
}
.custom-select-xs {
    height: calc(0.5rem + 0.9375rem * 1.6 + 2px);
    padding: 0.25rem 1.875rem 0.25rem 0.625rem;
    background: #fff
        url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3e%3cpolyline fill='none' stroke='%23C6D3E6' stroke-width='2' stroke-linecap='round' points='6 9 12 15 18 9'/%3e%3c/svg%3e")
        no-repeat right 0.625rem center/auto 50%;
    line-height: 1.6;
    font-size: 0.9375rem;
}

.printable {
    display: none;
}

.modal-open .reactIframeSignupModal.modal {
    overflow: scroll;
}
.reactIframeSignupModal .modal-dialog {
    margin-top: 3em;
}
.reactIframeSignupModal .modal-content {
    -webkit-box-shadow: 0 5px 11px 0 rgba(0,0,0,0.18), 0 4px 15px 0 rgba(0,0,0,0.15);
    box-shadow: 0 5px 11px 0 rgba(0,0,0,0.18), 0 4px 15px 0 rgba(0,0,0,0.15);
    border-radius: 0.5rem;
}
.reactIframeSignupModal .close {
    position: fixed;
    top: 5px;
    right: 8px;
    display: block;
    z-index: 1000;
}
@media (min-width: 768px) {
    #react_signup_iframe {
        width: 900px;
        height: 610px;
    }
    .reactIframeSignupModal .close {
        top: 5px;
        right: 25px;
    }
    .reactIframeSignupModal .modal-dialog {
        max-width: fit-content;
    }
}
@media (max-width: 767px) {
    .trellisLogo {
        flex: 1;
        display: inline-block;
        margin: 1em auto;
        max-width: 100px;
        margin-left: 10px;
    }
    a.trellisLink.internalLinks.d-flex.align-items-center {
        font-size: 15px;
        margin-right: 14px;
        padding-top: 8px;
    }
    a.signUpButton {
        top: 21px !important;
        right: 70px !important;
    }
    trellisLogoImage {
        max-width: 109px;
    }
    .dataTables_filter input[type=search] {
        width: 100%;
    }
    .judge-search-button {
        margin-left: 0;
        margin-right: 0;
    }
}

@media  print {
    .trellis-base, .page-container, .container { display:none !important; }
    .page-container.printable { display:block !important; }
    .print-text {
        font-weight: bolder;
        font-size: 300%;
    }
}


/* TRELLIS MODAL */
.trellis-modal .modal-header, .trellis-modal .modal-footer {
    border: none;
}


.trellisEmailList {
    text-align: left;
}
    
/* overrides for the css email list */
.trellisEmailList .email-chip {
    border: 1px solid gray;
    background-color: white;
    padding-top: .2rem;
    padding-bottom: .2rem;
}

.trellisEmailList .email-chip .content, .emails.emails-input .email-chip {
    background-color: white;
}

.trellisEmailList .emails-input {
    border: none;
    border-bottom: 3px solid #01885A;
    background-color: whitesmoke;
}

.trellisEmailList input {
    background-color: whitesmoke;   
}

.trellisEmailList .emails.emails-input .email-chip .remove {
    font-size: 1.5rem;
    font-weight: 100;
    top: 50%;
    transform: translateY(-50%);
    line-height: 1;
    height: 100%;
    right: 6px;
}

.trellisEmailList .emails.emails-input .email-chip p.content {
    margin-right: 1rem;
    color: dimgray;
}
.trellis-popup-modal h2 {
    font-family: Montserrat;
    font-weight: 600;
    font-size: 25px;
    color: #000000;
}
.trellis-popup-modal .modal-header {
    border-bottom: none;
}
.trellis-popup-modal .modal-title {
    margin-bottom: 1em;
}
.trellis-popup-modal .close {
    font-weight: 100;
    font-size: 2rem;
    position: absolute;
    right: 10px;
    top: 0;    
}
.trellis-popup-modal .modal-header {
    padding: 1.75rem;
}
.trellis-popup-modal .form-check {
    display: flex;
    padding-left: 0;
}
.trellis-popup-modal .form-check input[type=checkbox] {
    margin-right: 0.5rem;
}
.trellis-popup-modal .trellisPopupContent {
    padding: 1.5rem 1.5rem 3rem;
    text-align: center;
    font-size: 15px;
    font-family: Roboto;
    color: #000000;
    font-weight: 500;
    line-height: 1;
}
.trellisPopupContent {
    padding: 0 1.5rem;
    text-align: center;
}
.trellis-popup-modal label {
    margin: 0;
    margin-left: 0;
    display: flex;
    align-items: center;
    height: 18px;
}
.cancelButton {
    color: #006744;
    font-weight: 400;
    font-size: 15px;
}
.trellis-popup-modal .cancelButton:hover {
    text-decoration: none;
    color: #174742;
}
.trellis-popup-modal button {
    border-radius: 3px!important;
}

.trellis-popup-modal #alert_modal_recipients_list {
    width: 100%;
}

.trellis-popup-modal .modal-icon {
    margin-right: 1rem;
    width: 30px;
}
.trellis-popup-modal .modal-icon-2 {
    width: 200px;
}
.trellis-popup-modal .modal-background {
    position: absolute;
    width: 100%;
    z-index: 500;
}
.trellis-popup-modal a {
    font-family: Roboto;
    font-weight: 400;
    font-size: 18px;
    color: rgb(1, 136, 90);
}
.trellis-popup-modal p.content {
    font-family: Roboto;
    font-weight: 500;
    font-size: 16px;
    color: #000000;
    text-align: left;
    margin-bottom: 1.5em;
    line-height: 1.5;
}
.trellis-popup-modal p.content-2 {
    font-family: Roboto;
    font-weight: 400;
    font-size: 18px;
    color: rgb(91, 91, 91);
    text-align: left;
    line-height: 1.389;
}
.trellis-popup-modal .modal-body {
    padding: 0 2.25em;
}

.trellis-popup-modal .linkToEnableShareWithOthersPanel {
    font-family: Open Sans;
    font-size: 14px;
    font-weight: 400;
    color: #01885A;
    text-decoration: none;
}

.trellis-popup-modal .shareWithOthersPanel {
    width: 100%;
    display: none;
}

.trellis-popup-modal .alertSettingsLink, .trellis-popup-modal .alertSettingsLink:hover {
    font-family: Open Sans;
    font-size: 14px;
    font-weight: 400;
    color: #01885A;
    text-decoration: none;
}

.trellis-popup-modal .done {
    border-radius: 7px;
}
.trellis-popup-modal .modal-btn {
    border: 2px solid transparent;
    background-color: rgb(0, 135, 90)!important;
    color: #fff !important;
    padding: 0.55rem 2.755rem;
}

/* Customize the label (the container) */
.trellisCheckboxContainer {
    display: flex;
    position: relative;
    padding-left: 30px;
    margin-bottom: 12px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    align-items: center;
    height: 18px;
}

/* Hide the browser's default checkbox */
.trellisCheckboxContainer input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.trellisCheckboxContainer .checkmark {
    position: absolute;
    top: 0;
    left: 0;
    height: 18px;
    width: 18px;
    background-color: #eee;
}
.track-overlay .trellisCheckboxContainer .checkmark {
    background-color: white;
}
/* On mouse-over, add a grey background color */
.trellisCheckboxContainer:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.trellisCheckboxContainer input:checked ~ .checkmark {
  background-color: #006744;
}

/* Create the checkmark/indicator (hidden when not checked) */
.trellisCheckboxContainer .checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.trellisCheckboxContainer input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.trellisCheckboxContainer .checkmark:after {
    left: 6px;
    top: 5px;
    width: 6px;
    height: 10px;
    border: solid white;
    border-width: 0 3px 3px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
    top: 45%;
    transform: translateY(-50%) rotate(45deg);
}

/* New themes */
.trellis-green-container {
    padding: 1.5em 22px;
    background: white;
}
.trellis-green-header {
    background: #DCE7DE;
    padding: 1px 22px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
}
.trellis-green-header h3, .trellis-green-header h1 {
    font-family: Montserrat;
    font-weight: 600;
    font-size: 18px;
    color: black;
}
.blue-border {
    border: 2px solid #12BDED;
}
.blue-border:hover {
    border: 2px solid #01885A;
    text-decoration: none;
}
        

.dropdown-menu a.list-group-item {
    text-decoration: none;
    background-color: transparent;
    color: rgba(0,0,0,.7);
    font-size: 14px;
    font-weight: 500;

}
.list-group-flush .list-group-item{
    border-left: 3px solid #fff;
}
.dropdown-menu a.list-group-item:hover, 
.dropdown-menu a.list-group-item.active,
.dropdown-menu .list-group-item:hover a, 
.dropdown-menu .list-group-item.active a {
    color: rgb(0, 102, 68) !important;
    text-decoration: none;
    border-left: 3px solid #174742;
    background: #F5F6F4;
}
.dropdown-toggle::after {
    display: inline-block;
    margin-left: .255em;
    vertical-align: .255em;
    content: "";
    border-top: .3em solid;
    border-right: .3em solid transparent;
    border-bottom: 0;
    border-left: .3em solid transparent;
}
.dropdown-toggle::after {
    font-family: fontawesome;
    vertical-align: middle;
    border: none!important;
    content: "";
}

.navbar > .container, .navbar > .container-fluid, .navbar > .container-lg, .navbar > .container-md, .navbar > .container-sm, .navbar > .container-xl {
    padding-left: 20px !important;
    padding-right: 20px !important;
}

.navbar .container, .navbar .container-fluid, .navbar .container-lg, .navbar .container-md, .navbar .container-sm, .navbar .container-xl {
    display: -webkit-box;
    display: flex;
    flex-wrap: wrap;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
}
.navbar {
    -webkit-transition: all 0.2s ease-in-out;
    transition: all 0.2s ease-in-out;
    -webkit-transition-property: background-color, color;
    transition-property: background-color, color;
    position: relative;
    display: -webkit-box;
    display: flex;
    flex-wrap: wrap;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
    padding: 1rem 2em;
}
.navbarAccount2 {
    margin-left: -5px!important;
    text-transform: capitalize;
}
.border-bottom {
    border-bottom: 1px solid #f1f4f8 !important;
}
.bg-white {
    background-color: #fff !important;
}

.navbar-light .navbar-brand {
    color: rgb(0, 102, 68);
}

.navbar-brand {
    font-weight: 600;
    display: inline-block;
    padding-top: 0.15rem;
    padding-bottom: 0.15rem;
    margin-right: 0;
    font-size: 1.5rem;
    line-height: inherit;
    white-space: nowrap;
}
.navbar .navbar-toggler {
    margin-left: 0;
    float: left;
}
.navbar-light .navbar-toggler {
    color: #506690;
    border-color: transparent;
}
[type="button"]:not(:disabled), [type="reset"]:not(:disabled), [type="submit"]:not(:disabled), button:not(:disabled) {
    cursor: pointer;
}
.navbar-brand-img {
    max-height: 2.4rem;
    width: auto;
}
.navbar-light .navbar-toggler-icon {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='30' height='30' viewBox='0 0 30 30'%3e%3cpath stroke='%23506690' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
}
.navbar-toggler-icon {
    display: inline-block;
    width: 1.5em;
    height: 1.5em;
    vertical-align: middle;
    content: "";
    background: no-repeat center center;
    background-size: 100% 100%;
}
.navbar-collapse .navbar-toggler {
    position: absolute;
    top: 1rem;
    right: 4px;
    z-index: 1;
    font-family: Open Sans;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 25px;
    letter-spacing: 0px;
    text-align: left;
    color: #006744;
}

[type="button"]:not(:disabled), [type="reset"]:not(:disabled), [type="submit"]:not(:disabled), button:not(:disabled) {
    cursor: pointer;
}


.ml-auto, .mx-auto {
    margin-left: auto !important;
}
.navbar-nav {
    display: -webkit-box;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    flex-direction: column;
    padding-left: 0;
    margin-bottom: 0;
    list-style: none;
}
.navbar-light .navbar-nav .nav-link {
    color: #000;
}

.navbar-nav .nav-link {
    font-weight: 600;
    padding-right: 0;
    padding-left: 0;
}

.btn:not(:disabled):not(.disabled) {
    cursor: pointer;
}
.btn-primary-soft {
    background-color: rgba(0, 135, 90, 0.1);
    color: rgb(0, 102, 68) !important;
}
.lift {
    -webkit-transition: box-shadow 0.25s ease, -webkit-transform 0.25s ease;
    transition: box-shadow 0.25s ease, -webkit-transform 0.25s ease;
    transition: box-shadow 0.25s ease, transform 0.25s ease;
    transition: box-shadow 0.25s ease, transform 0.25s ease, -webkit-transform 0.25s ease;
}
.ml-3, .mx-3 {
    margin-left: 0.75rem !important;
}
.navbar-collapse.show {
    opacity: 1;
    -webkit-transform: scale(1);
    transform: scale(1);
    z-index: 99999;
}

a.trellisLink.internalLinks:hover,.dropdown-item:focus{

    color: rgb(0, 102, 68) !important;
}
.dropdown-item:focus, .dropdown-item:hover {
    color: rgb(0, 102, 68) !important;
        text-decoration: none;
        border-bottom: none;
        background: none !important;
}
.dropright{
    position: relative;
    top: -3px;
    font-size: 15px;
}


:focus {
    outline: none;
}
.navbar-light .navbar-nav .nav-link:focus, .navbar-light .navbar-nav .nav-link:hover {
    color: rgb(0, 102, 68);
}
a.trellisLink.internalLinks:hover, .dropdown-item:focus, .trellisLinkTheme a.trellisLink.internalLinks {
    color: rgb(0, 102, 68) !important;
    /* background: #f6f7f6; */
    padding: 10px !important;
    border-bottom: 3px solid rgb(0, 102, 68) !important;
}
a.trellisLink.internalLinks, .dropdown-item {
    padding: 10px !important;
}
.navbar-nav .dropdown-menu {
    box-shadow: none;
    position: static;
    float: none;
    box-shadow: none;
}
.trellisLink{
    margin: 0 20px 0 20px !important;
}

.dropdown-menu {
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 1000;
    display: none;
    float: left;
    min-width: 14rem;
    padding: 0;
    margin: 0 0 0;
    font-size: 0.9375rem;
    color: #161c2d;
    text-align: left;
    list-style: none;
    background-color: #fff;
    background-clip: padding-box;
    border: 0 solid rgba(22, 28, 45, 0.15);
    border-radius: 0.375rem;
    box-shadow: 0 0.5rem 1.5rem rgba(22, 28, 45, 0.1);
}

.dropdown-item {
    display: block;
    width: 100%;
    padding: 0 1.75rem;
    clear: both;
    font-weight: 400;
    color: #000;
    text-align: inherit;
    white-space: nowrap;
    background-color: transparent;
    border: 0;
}


.navbar-nav .dropright>.dropdown-toggle {
    display: -webkit-box;
    display: flex;
}
.dropdown-link {
    color: inherit;
}
.dropdown-toggle {
    white-space: nowrap;
}

.dropdown, .dropleft, .dropright, .dropup {
    position: relative;
}

.navbar-nav .dropdown-menu {
    box-shadow: none;
    position: static;
    float: none;
}


.dropdown-menu.show {
    display: block;
}
.dropright .dropdown-menu {
    top: 0;
    right: auto;
    left: 100%;
    margin-top: 0;
    margin-left: 0;
}
a.navbar-btn {
    margin-right: 11px;
}
#contact-support-button {
    background-color: white !important;
    color: rgb(1, 136, 90);
    width: 170px;
    border: 2px solid rgb(1, 136, 90)!important;
}
#contact-support-button:hover {
    background-color: rgb(1, 136, 90) !important;
    color: white;
    width: 170px;
    border: 1px solid rgb(1, 136, 90)!important;
}
#unpause-link {
    background: none!important;
    border: none;
    padding: 0!important;
    font-size: 16px;
    font-weight: 600;
    color: rgb(3, 104, 70);
    text-decoration: underline;
    cursor: pointer;  
}
#first_name__container {
    font-family: Open Sans, sans-serif;
    font-size: 15px;
    margin-right: 15px;
    padding-bottom: 7px;

}
#profile-select__container {
    position: relative;
    display: flex;
    align-items: center;
}
@media (min-width: 992px){
    .navbar-nav .dropdown-menu {
        box-shadow: 0 1.5rem 4rem rgba(22, 28, 45, 0.15);
        -webkit-transition: all 0.2s ease-in-out;
        transition: all 0.2s ease-in-out;
        transition-property: opacity, transform, -webkit-transform;
        position: absolute;
    }

    .navbar-expand-lg .navbar-nav .dropdown-menu {
        position: absolute;
    }
    .navbar-nav .dropdown > .dropdown-menu {
        -webkit-transform: translate(-50%, 10px);
        transform: translate(-50%, 10px);
    }
    .navbar-nav .dropdown-menu.show {
        display: block;
        opacity: 1;
    }
    .navbar-nav .dropdown>.dropdown-menu.show {
        -webkit-transform: translate(-50%,0);
        transform: translate(-66%,0);
    }
    .dsk-none{
        display: none!important;
    }
    .navbar {
        padding: 10px 0 10px 0;
    }
    .navbar .container {
        max-width: 1600px;
        margin: auto;
    }
    a.navbar-btn {
        font-weight: 500;
        font-size: 15px;
    }
}

@media (max-width: 991.98px){

    .list-group-item {
        border: 1px solid rgb(0 0 0 / 5%);
    }
    .trellisLink {
        margin: 0 !important;
    }

    li.nav-item.dropdown.child-drop {
        color: rgb(0, 102, 68) !important;
        text-decoration: none;
        border-left: none;
        background: #ffffff;
        margin-left: 15px;
    }
    .navbar{
        margin: 0;
        padding: 10px 4px;
    }
    nav[role="navigation"] a:not(.btn), a.trellisLink:not(.btn) {
        text-decoration: none;
        border-bottom: none !important;
    }
    .mobile-hide{
        display: none;
    }
    a.trellisLink.internalLinks:hover, .dropdown-item:focus, .trellisLinkTheme a.trellisLink.internalLinks{
        color: none !important;
        padding: none !important;
        border-bottom: none !important;
    }
    .navbar li.nav-item, .navbar .list-group-item{
        border-left: 3px solid #fff
    }
    .navbar .list-group-flush .list-group-item {
        border-left: 3px solid #fff
    }

    .dropdown-item:focus, .dropdown-item:hover {
        color: rgb(0, 102, 68) !important;
        text-decoration: none;
        border-left: 3px solid #174742;
        background: #F5F6F4;
    }
    .navbar-collapse {
        position: fixed;
        top: 1rem;
        left: 1rem;
        height: auto;
        max-height: calc(100% - 2rem) !important;
        width: calc(100% - 2rem);
        background-color: #fff;
        border-radius: 0.375rem;
        box-shadow: 0 1.5rem 4rem rgba(22, 28, 45, 0.15);
        overflow-x: hidden;
        overflow-y: scroll;
    }
    .navbar-collapse.show {
        opacity: 1;
        -webkit-transform: scale(1);
        transform: scale(1);
        z-index: 99999;
    }

    .navbar-collapse.collapsing, .navbar-collapse.show {
        -webkit-transition: all 0.2s ease-in-out;
        transition: all 0.2s ease-in-out;
        transition-property: opacity, transform, -webkit-transform;
        -webkit-transform-origin: top right;
        transform-origin: top right;
        z-index: 99999;
        transition: .5s;
        overflow: hidden;
    }
    .navbar-collapse .navbar-nav .dropdown>.dropdown-menu {
        display: block!important;
    }
    .navbar-collapse .navbar-nav .dropdown-menu {
        min-width: 0;
        padding: 0;
    }
    .navbar-nav .nav-item {
        padding: 7px 0px;
        border-top: 1px #f1f1f1 solid;
        border-left: 3px solid #fff;
    }
    .navbar-nav .nav-link {
        padding-top: 0;
        padding-bottom: 0;
    }
    .navbar-nav .nav-item + .nav-item {
        border-top: 1px solid #f1f4f8;
    }
    .navbar-btn {
        width: 100%;
        padding: 0.8125rem 1.25rem;
        border-top-left-radius: 0;
        border-top-right-radius: 0;
        font-size: 1.0625rem;
    }
    .navbar-expand-lg > .container, .navbar-expand-lg > .container-fluid, .navbar-expand-lg > .container-lg, .navbar-expand-lg > .container-md, .navbar-expand-lg > .container-sm, .navbar-expand-lg > .container-xl {
        padding-right: 0;
        padding-left: 0;
    }
    .navbar-collapse .navbar-nav .dropdown-header, .navbar-collapse .navbar-nav .dropdown-item {
        margin-left: 0;
        margin-right: 0;
        padding-left: 0;
        padding-right: 0;
    }
    .navbar-collapse .navbar-nav .dropright>.dropdown-menu {
        padding-top: 1rem;
        padding-bottom: 1rem;
        padding-left: .5rem;
    }

    .navbar-collapse .navbar-nav .dropdown-menu {
        min-width: 0;
        padding: 0;
    }
    .navbar-collapse .navbar-nav .dropdown-header, .navbar-collapse .navbar-nav .dropdown-item {
        margin-left: 0;
        margin-right: 0;
        padding-left: 0;
        padding-right: 0;
    }

    .navbar li.nav-item:hover, .navbar .list-group-item:hover, .navbar .dropdown-item:focus {
        color: rgb(0, 102, 68) !important;
        text-decoration: none;
        border-left: 3px solid #174742;
        background: #F5F6F4;
    }
    .trellisLinkTheme a.trellisLink.internalLinks:hover {
        border: none !important;
        background: none !important;
    }

    a.trellisLink.internalLinks:hover, .dropdown-item:focus, .trellisLinkTheme a.trellisLink.internalLinks {
        color: none !important;
        background: none !important;
        padding: none !important;
        border-bottom: none !important;
    }


}

    </style>
<link rel="canonical" href="https://trellis.law/rulings/judge:anderle%20AND%20%22wrongful%20termination%22/1" />
<link rel="stylesheet" href="css/smart_search_results.css">

<link rel="stylesheet" href="css/output.d476468f597f.css" type="text/css" />


<script type="acfcc1acf16c1b3b565e9d8c-text/javascript" src="/static/CACHE/js/output.d6a46effb19d.js"></script>

<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">
        
        // If Authenticated, Set User Script Var
        var IS_AUTHENTICATED = true;
        var trellisUser = 'Stellas@ornicogroup.co.za';
        

        
        var IS_SUBSCRIBED = false;
        
    </script>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript" src="/static/CACHE/js/output.dd07c92984ca.js"></script>




<script async src="https://www.googletagmanager.com/gtag/js?id=AW-748797246" type="acfcc1acf16c1b3b565e9d8c-text/javascript"></script>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript"> window.dataLayer = window.dataLayer || []; function gtag() { dataLayer.push(arguments); } gtag('js', new Date()); gtag('config', 'AW-748797246'); </script>

<script type="acfcc1acf16c1b3b565e9d8c-text/javascript"> function gtag_report_conversion(url) { var callback = function () { if (typeof (url) != 'undefined') { window.location = url; } }; gtag('event', 'conversion', { 'send_to': 'AW-748797246/2UI8CN3f_Z8BEL76huUC', 'event_callback': callback }); return false; } </script>

<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl+ '&gtm_auth=yCoHSd1G3mpptCzyFR0HDw&gtm_preview=env-2&gtm_cookies_win=x';f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P8NF2ZD');</script>



<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">
    window['GoogleAnalyticsObject'] = 'ga';
    window['ga'] = window['ga'] || function() {
        (window['ga'].q = window['ga'].q || []).push(arguments)
    };
</script>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">

    window.dataLayer = window.dataLayer || [];

    
        // Set UserId for GA
        window.dataLayer.push({
            'userId': 'Stellas@ornicogroup.co.za'
        });
    

    
        
            var dimensionValue3 = 'User';
        
    

    // Set User Type dimension
    window.dataLayer.push({
        'userType': dimensionValue3 
    });

      
</script>
<script async id="profitwell-js" data-pw-auth="b18218f9ce212d5f1204e6722cd60f64" type="acfcc1acf16c1b3b565e9d8c-text/javascript">
        (function(i,s,o,g,r,a,m){i[o]=i[o]||function(){(i[o].q=i[o].q||[]).push(arguments)};
            a=s.createElement(g);m=s.getElementsByTagName(g)[0];a.async=1;a.src=r+'?auth='+
                s.getElementById(o+'-js').getAttribute('data-pw-auth');m.parentNode.insertBefore(a,m);
        })(window,document,'profitwell','script','https://public.profitwell.com/js/profitwell.js');
        
            profitwell('start', { 'user_email': 'Stellas@ornicogroup.co.za' });
            dataLayer.push({ 'event': 'start_pw', 'pw_user_email': 'Stellas@ornicogroup.co.za' });
        
    </script>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">
            (function(h,o,t,j,a,r){
                h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
                h._hjSettings={hjid:2494852,hjsv:6};
                a=o.getElementsByTagName('head')[0];
                r=o.createElement('script');r.async=1;
                r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
                a.appendChild(r);
            })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
        </script>

<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">
            var userId = "Stellas@ornicogroup.co.za" || null; // Replace your_user_id with your own if available.
            window.hj('identify', userId, {
                // Add your own custom attributes here. Some EXAMPLES:
                'Email': "Stellas@ornicogroup.co.za", 
                'Name': "Stella Sithole" || "Stella", 
                'Law firm': "False", 
                'Trial': "False", 
                'Paying': "False"
            });
        </script>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">
    (function(e,t){var n=e.amplitude||{_q:[],_iq:{}};var r=t.createElement("script")
    ;r.type="text/javascript"
    ;r.integrity="sha384-3bSR/uIgD42pCWBeq1//B3mI/hPuWdk0L1EUnQIWfGyMOjs0VEoFLhHMqObtv2BA"
    ;r.crossOrigin="anonymous";r.async=true
    ;r.src="https://cdn.amplitude.com/libs/amplitude-5.10.0-min.gz.js"
    ;r.onload=function(){if(!e.amplitude.runQueuedFunctions){
    console.log("[Amplitude] Error: could not load SDK")}}
    ;var i=t.getElementsByTagName("script")[0];i.parentNode.insertBefore(r,i)
    ;function s(e,t){e.prototype[t]=function(){
    this._q.push([t].concat(Array.prototype.slice.call(arguments,0)));return this}}
    var o=function(){this._q=[];return this}
    ;var a=["add","append","clearAll","prepend","set","setOnce","unset"]
    ;for(var u=0;u<a.length;u++){s(o,a[u])}n.Identify=o;var c=function(){this._q=[]
    ;return this}
    ;var l=["setProductId","setQuantity","setPrice","setRevenueType","setEventProperties"]
    ;for(var p=0;p<l.length;p++){s(c,l[p])}n.Revenue=c
    ;var d=["init","logEvent","logRevenue","setUserId","setUserProperties","setOptOut","setVersionName","setDomain","setDeviceId", "enableTracking", "setGlobalUserProperties","identify","clearUserProperties","setGroup","logRevenueV2","regenerateDeviceId","groupIdentify","onInit","logEventWithTimestamp","logEventWithGroups","setSessionId","resetSessionId"]
    ;function v(e){function t(t){e[t]=function(){
    e._q.push([t].concat(Array.prototype.slice.call(arguments,0)))}}
    for(var n=0;n<d.length;n++){t(d[n])}}v(n);n.getInstance=function(e){
    e=(!e||e.length===0?"$default_instance":e).toLowerCase()
    ;if(!n._iq.hasOwnProperty(e)){n._iq[e]={_q:[]};v(n._iq[e])}return n._iq[e]}
    ;e.amplitude=n})(window,document);

    if (typeof trellisUser !== 'undefined') {
        amplitude.getInstance().init("5d3e6ed10c963f7039f987570bed5b5f", trellisUser);
    }
    else {
        amplitude.getInstance().init("5d3e6ed10c963f7039f987570bed5b5f");
    }
  </script>
</head>
<body class="">
<div class="printHeader">
<img src="/static/global/trellis-word-motto-main.svg" alt="">
</div>
<div class="printFooter">
<img src="/static/global/trellis-word-motto-main.svg" alt="">
</div>

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P8NF2ZD&gtm_auth=yCoHSd1G3mpptCzyFR0HDw&gtm_preview=env-2&gtm_cookies_win=x"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<div id="nav-container-internal" class="nav-container-internal hide-on-print">
<header class="trellisNav">
<nav class="navbar navbar-expand-lg navbar-light bg-white">
<div class="container">
<a href="/search" style="margin-right: 5em;">
<img src="/static/global/trellis-word-dark-green.svg" alt="Trellis logo" class="trellisLogoImage">
</a>
<div class="d-flex dsk-none">


<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">
    $(document).ready(function(e) {
        var quota_usage_api_url = '/api/quota/all_rates';
        $.ajax({
            url: quota_usage_api_url,
            type: "GET",
            success: function(res) {
                var data = res.data;
                var formattedDate = false;
                if (data.credit.cycle_renew_date) {
                    formattedDate = moment(data.credit.cycle_renew_date).format('MMMM Do, YYYY');
                }
                $('.credits-remaining').text(data.credit.remaining);
                $('.credits-count').text(data.credit.count);
                $('.credits-limit').text(data.credit.limit);
                $('.credits-time-left').text(formattedDate);

                var popoverContent = `
                    <p class='d-flex mb-1'>
                        <b class='mr-auto'>Credits Used:</b> 
                        ${data.credit.count}/${data.credit.limit}
                    </p>
                    `;

                if (formattedDate) {
                    popoverContent += `<p class='d-flex mb-1'>
                            <b class='mr-auto'>Next Credits Refill:</b> 
                            ${formattedDate}
                        </p>
                    `;                    
                }
                $('.usagePopover').popover('dispose');
                $('.usagePopover').popover({
                    'content': popoverContent,
                    'trigger': 'click'
                });
                
            }
        });        
        
        $('.usagePopover').click(function(e) {
            amplitude.getInstance().logEvent('Credit Usage Popup - Viewed');            
        })
    });
</script>
<button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
</div>
<div class="navbar-collapse collapse" id="navbarCollapse">
<button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
<i class="far fa-times-circle"></i>
</button>
<div class="d-block d-md-none nav-item-name">
Stella
</div>
<ul class="navbar-nav">
<li class="nav-item  
                            trellisLinkTheme
                            ">
<a class="trellisLink internalLinks d-flex flex-grow-1 flex-grow-md-0 align-items-center nav-link" role="button" href="/search">
Smart Search
</a>
</li>
<li class="nav-item ">
<a class="trellisLink internalLinks d-flex flex-grow-1 flex-grow-md-0 align-items-center nav-link" role="button" href="/judges">
Judge Analytics
</a>
</li>
<li class="nav-item  ">
<a class="trellisLink internalLinks d-flex flex-grow-1 flex-grow-md-0 align-items-center nav-link" role="button" href="/ca/motion-type">
Motions & Issues
</a>
</li>
</ul>
<div class="ml-auto">
<div class="dsk-none">
<ul class="navbar-nav ml-auto">
<li class="nav-item">
<a class="trellisLink internalLinks d-flex flex-grow-1 flex-grow-md-0 align-items-center nav-link" role="button" href="/profile">
Profile
</a>
</li>
<li class="nav-item">
<a class="trellisLink internalLinks d-flex flex-grow-1 flex-grow-md-0 align-items-center nav-link" role="button" href="/account/overview">
Account Overview
</a>
</li>
<li class="nav-item">
<a class="trellisLink internalLinks d-flex flex-grow-1 flex-grow-md-0 align-items-center nav-link" role="button" href="/account/overview#ch">
Credit Summary
</a>
</li>
<li class="nav-item">
<a class="trellisLink internalLinks d-flex flex-grow-1 flex-grow-md-0 align-items-center nav-link" role="button" href="/billing">
Billing
</a>
</li>
<li class="nav-item">
<a class="trellisLink internalLinks d-flex flex-grow-1 flex-grow-md-0 align-items-center nav-link" role="button" href="/account/history">
Activity History
</a>
</li>
<li class="nav-item">
<a class="trellisLink internalLinks d-flex flex-grow-1 flex-grow-md-0 align-items-center nav-link" role="button" href="/alerts">
Alerts
</a>
</li>
<li class="nav-item">
<a class="trellisLink internalLinks d-flex flex-grow-1 flex-grow-md-0 align-items-center nav-link" role="button" href="/logout/">
Logout
</a>
</li>
</ul>
</div>

<div class="mobile-hide">
<ul class="navbar-nav ml-auto">
<li class="nav-item quota-usage-item">


<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">
    $(document).ready(function(e) {
        var quota_usage_api_url = '/api/quota/all_rates';
        $.ajax({
            url: quota_usage_api_url,
            type: "GET",
            success: function(res) {
                var data = res.data;
                var formattedDate = false;
                if (data.credit.cycle_renew_date) {
                    formattedDate = moment(data.credit.cycle_renew_date).format('MMMM Do, YYYY');
                }
                $('.credits-remaining').text(data.credit.remaining);
                $('.credits-count').text(data.credit.count);
                $('.credits-limit').text(data.credit.limit);
                $('.credits-time-left').text(formattedDate);

                var popoverContent = `
                    <p class='d-flex mb-1'>
                        <b class='mr-auto'>Credits Used:</b> 
                        ${data.credit.count}/${data.credit.limit}
                    </p>
                    `;

                if (formattedDate) {
                    popoverContent += `<p class='d-flex mb-1'>
                            <b class='mr-auto'>Next Credits Refill:</b> 
                            ${formattedDate}
                        </p>
                    `;                    
                }
                $('.usagePopover').popover('dispose');
                $('.usagePopover').popover({
                    'content': popoverContent,
                    'trigger': 'click'
                });
                
            }
        });        
        
        $('.usagePopover').click(function(e) {
            amplitude.getInstance().logEvent('Credit Usage Popup - Viewed');            
        })
    });
</script>
</li>
<li class="nav-item dropdown child-drop">
<div id="profile-select__container">
<span id="first_name__container">
Stella
</span>
</div>
<a href="#" class="btn-account-menu btn-alert-link nav-link dropdown-toggle" id="navbarAccount" data-toggle="dropdown" href="#" aria-haspopup="true" aria-expanded="false">
<svg class="profile-icon" width="25" height="31" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M12.5 25C19.4036 25 25 19.4036 25 12.5C25 5.59644 19.4036 0 12.5 0C5.59644 0 0 5.59644 0 12.5C0 19.4036 5.59644 25 12.5 25ZM4.11548 18.9484C2.74067 17.1635 1.92308 14.9272 1.92308 12.5C1.92308 6.65853 6.65853 1.92308 12.5 1.92308C18.3415 1.92308 23.0769 6.65853 23.0769 12.5C23.0769 14.9277 22.259 17.1643 20.8837 18.9494C20.2562 18.3804 19.4543 17.9688 18.3989 17.5889C18.2408 17.532 18.0788 17.4761 17.8765 17.4081L17.3839 17.2432C16.1861 16.839 15.7623 16.5823 15.6637 16.2574C15.6603 16.2465 15.655 16.2262 15.6475 16.1868C15.6049 15.9618 15.6146 15.7156 15.7022 15.5114C15.7539 15.3909 15.8326 15.2837 15.9507 15.185C17.2791 13.9858 17.9487 12.6343 17.9487 10.7909C17.9487 7.57912 15.4358 5.12821 12.5 5.12821C9.54403 5.12821 7.05128 7.53735 7.05128 10.7909C7.05128 12.6289 7.70353 13.9409 8.98453 15.1473C9.14935 15.2863 9.23212 15.3881 9.28841 15.4948C9.39736 15.7014 9.41131 15.9408 9.36358 16.1613C9.36017 16.1771 9.35733 16.189 9.35554 16.1964C9.35339 16.2054 9.35278 16.208 9.35455 16.2032C9.25966 16.5402 8.86664 16.7824 7.75907 17.1607L7.19167 17.3523C6.955 17.4326 6.76687 17.4985 6.58273 17.5665C5.54487 17.9495 4.7429 18.3726 4.11548 18.9484ZM5.42498 20.3624C7.29905 22.0499 9.77959 23.0769 12.5 23.0769C15.2198 23.0769 17.6998 22.0504 19.5737 20.3636C19.1541 19.9917 18.5725 19.6953 17.7476 19.3984C17.6041 19.3467 17.4539 19.2949 17.2634 19.2308L16.7692 19.0653C14.9802 18.4618 14.1749 17.9739 13.8284 16.8315C13.8065 16.7636 13.7812 16.6668 13.7581 16.5449C13.6503 15.9762 13.6747 15.36 13.9348 14.7534C14.104 14.3589 14.3641 14.0048 14.6894 13.7338C15.6058 12.9059 16.0256 12.0585 16.0256 10.7909C16.0256 8.65211 14.3843 7.05128 12.5 7.05128C10.5917 7.05128 8.97436 8.61439 8.97436 10.7909C8.97436 12.0573 9.38451 12.8824 10.257 13.7067C10.5707 13.9665 10.8148 14.2666 10.9894 14.5976C11.3386 15.2597 11.3784 15.9433 11.2431 16.5682C11.2154 16.6961 11.185 16.7979 11.1849 16.7867C10.8821 17.9111 10.0991 18.3936 8.38068 18.9806L7.80957 19.1734C7.58762 19.2487 7.41432 19.3094 7.24861 19.3706C6.43322 19.6715 5.84825 19.979 5.42498 20.3624Z" fill="#141124"></path>
</svg>
<p class="btn-account-text">
<i class="fas fa-chevron-down"></i>
</p>
</a>
<div class="dropdown-menu dropdown-menu-md" aria-labelledby="navbarDocumentation">
<div class="list-group list-group-flush">
<a class="list-group-item" href="/profile">Profile</a>
<a class="list-group-item" href="/account/overview">Account Overview</a>
<a class="list-group-item" href="/account/overview#ch">Credit History</a>
<a class="list-group-item" href="/billing">Billing</a>
<a class="list-group-item" href="/account/history">Activity History</a>
<a class="list-group-item" href="/alerts">Alerts</a>
<a class="list-group-item" href="/logout/">Logout</a>
</div>
</div>
</li>
</ul>
</div>

</div>
</div>
</div>
</nav>
</header>
</div>
<div id="bodyWrapper" class="bodyBackground">
<div class="results-header d-flex flex-column">

<div class="search-bar-container d-flex flex-row justify-content-center">
<style>
    #search-form-wrapper .form-control {
    border: transparent;
    background: transparent;
    padding: 0.375rem 1.75rem;
    padding-right: 0.25rem;
    height: 100%;
    color: #000;
}
#search-form-wrapper .form-control:focus {
    color: #495057;
    background-color: transparent;
    border-color: transparent;
    outline: 0;
    box-shadow: none;
}
#search-form-wrapper .btn.btn-search {
    width: 50px;
    background: rgb(0, 135, 90) !important;
    border-top-right-radius: 14px;
    border-bottom-right-radius: 14px;
    border-top-left-radius: 0px;
    border-bottom-left-radius: 0px;
}
#search-form-wrapper .input-group-append > *:first-child {
    border-radius: 0;
    border-top: 1.2px solid #dfe1e5;
    border-bottom: 1.2px solid #dfe1e5;
    border-right: 0;
}
#search-form-wrapper .input-group-append {
    margin-left: 0;
}
#search-form-wrapper .btn-group {
    height: 100%;
}
#search-form-wrapper .custom-select {
    display: none;
}
#search-form-wrapper .multiselect-selected-text, #search-form-wrapper .multiselect-container>li>a {
    font-size: 13px;
    color: #006744;
}
#search-form-wrapper .multiselect-container>li>a {
    display: flex;
    align-items: center;
}
#search-form-wrapper .multiselect-container>li>a:hover {
    text-decoration: none;
}
#search-form-wrapper .multiselect-container>li>a input[type=checkbox] {
    margin-right: 1em;
}
#search-form-wrapper .dropdown-menu.multiselect-container {
    border-radius: 0;
    background: #F5F6F4;
    box-shadow: 0px 10px 24px rgba(26, 71, 66, 0.2);
    left: -1px!important;
    padding: 7px 6px 0px;
}
#search-form-wrapper .dropdown-toggle::after {
    vertical-align: 0.15em;
}
#search-form-wrapper .multiselect-container>li {
    padding: 5px 12px 5px;
}
#search-form-wrapper .multiselect-container>li:last-of-type {
    padding-bottom: 15px;
}
#search-form-wrapper .multiselect-container>li>a>label {
    padding: 0;
}
:focus {
    outline: 0;
}
#search-form-wrapper .multiselect-container>li.disabled label {
    cursor: not-allowed;
    color: #CECFCC;
}
#search-form-wrapper .multiselect-container>li>a>label>input[type=checkbox]:disabled {
    background: #CECFCC;
}
#search-form-wrapper .multiselect-container>li>a>label>input[type=checkbox] {
    margin-bottom: 5px;
    margin-right: 8px;
}
#search-form-wrapper .multiselect-container input[type=radio] {
    display: none;
}
#search-form-wrapper .dropdown-menu.show {
    display: block;
}
#search-form-wrapper button.multiselect {
    background: #F5F6F4;
    border-radius: 0;
}
#search-form-wrapper button.multiselect[aria-expanded="true"] {
    background: #F5F6F4;
    border-radius: 0;
}
#search-form-wrapper .spinner-border {
    border-width: 1px;
    width: 1rem;
    height: 1rem;
}
.btn.focus, .btn:focus {
    box-shadow: none;
}
</style>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">
    
var states = [{'code': 'ca', 'name': 'California', 'active': 1}, {'code': 'de', 'name': 'Delaware', 'active': 1}, {'code': 'fl', 'name': 'Florida', 'active': 1}, {'code': 'il', 'name': 'Illinois', 'active': 1}, {'code': 'ma', 'name': 'Massachusetts', 'active': 1}, {'code': 'nv', 'name': 'Nevada', 'active': 1}, {'code': 'ny', 'name': 'New York', 'active': 1}, {'code': 'pa', 'name': 'Pennsylvania', 'active': 1}, {'code': 'tx', 'name': 'Texas', 'active': 1}, {'code': 'wa', 'name': 'Washington', 'active': 1}];
var states_selected = ['ca'];
var formUrl = "/rulings/";
var query = "judge%3Aanderle%20AND%20%22wrongful%20termination%22";
Cookies.set('raw_query', "judge%3Aanderle%20AND%20%22wrongful%20termination%22");

$(document).ready(function() {
    // Init State Multiselect
    $('#stateSelect').multiselect({
        nonSelectedText: 'Select State'
    });

    // State Change
    $('#stateSelect').change(function() {
        var stateList = $(this).val();
        // always remember the states the user selected
        if (stateList.length > 0) {
            Cookies.set('states_selected', stateList.join('|'));
        } else {
            // if no state selected, the backend will create a cookie with whatever state
            // the user is coming from
            Cookies.remove('states_selected');
        }
    });
    // Populate State Multiselect
    for (i = 0; i < states.length; i++) {
        var htm = '';
        var attributes = '';
        attributes += 'value="' + states[i]['code'] + '"';
        if (states[i]['active'] != 1) {
            attributes += ' disabled=disabled';
        }
        if (states_selected.indexOf(states[i]['code']) > -1) {
            attributes += ' selected';
        }
        htm += '<option ' + attributes + '>' + states[i]['code'].toUpperCase() + '</option>';
        $('#stateSelect').append(htm);
        $('#stateSelect').multiselect('rebuild');
    }
    // Select checkbox on li click
    $('.multiselect-container li').click(function(e) {
        var stateInput = $(this).find('input[type=checkbox]').first();
        stateInput.click();
    });
    // Prevent the nested a tag from triggering above event
    $('.multiselect-container li input').click(function(e) {
        e.stopPropagation();
    });

    // Advanced Search Drop Down
    // Manual Toggle Trigger
    $('.advanced-search-btn').on('click', function (event) {
        event.stopPropagation();
        $('.advancedSearchForm').toggleClass('show');
        if ($('.advancedSearchForm').css('display') == 'none') {
            $('.advancedArrowDown').show();
            $('.advancedArrowUp').hide();
        } else {
            $('.advancedArrowDown').hide();
            $('.advancedArrowUp').show();
        }

        // Amplitude - Signup View
        amplitude.getInstance().logEvent('Advanced Search - Clicked');
    });
    // Only close when clicking outside the block
    $('body').on('click', function (e) {
        if (!$('.advancedSearchForm').is(e.target)
            && $('.advancedSearchForm.dropdown-menu').has(e.target).length === 0
            && $('.show').has(e.target).length === 0
            && !$('.advanced-search-btn').is(e.target)
            && !$('.advancedSearchButton').is(e.target)
        ) {
            $('.advancedSearchForm').removeClass('show');
            $('.advancedArrowDown').show();
            $('.advancedArrowUp').hide();
            $('#searchTipsDropdownContainer2').hide();
        }
    });
    $('.advancedSearchButton').click(function() {
        $('.header-center-wrapper').removeClass('active');
        $('#searchTipsDropdownContainer').hide();
        $('.advanced-search-btn').click();
    })

    // Search Tips on Advanced Search
    $('.advanced-search-tips-btn').click(function(){
        $('#searchTipsDropdownContainer2').toggle();

        // Amplitude - Advanced Search Tips Toggled
        amplitude.getInstance().logEvent('Advanced Search Tips - Clicked');
    });


    // Toggle Search Tips
    $("#id_q_results").focus(function() {
        $('#searchTipsDropdownContainer').show();
        $('.header-center-wrapper').addClass('active');
    });
    $("#id_q_results").blur(function() {
        $('.header-center-wrapper').removeClass('active');
    });
    // Close on Click Outside of Box
    $(document).click(function(event) {
        $target = $(event.target);
        if(
            !$target.closest('#searchTipsDropdownContainer').length
            && $('#searchTipsDropdownContainer').is(":visible")
            && !$target.closest('#search-form-wrapper').length
        ) {
          $('#searchTipsDropdownContainer').hide();
        }
      });
    // Close on hit Escape
    $(document).keyup(function(e) {
        if (e.keyCode === 27) {
            // Hide Search Tips
            $('#searchTipsDropdownContainer').hide();

            // Hide Advanced Search
            $('.advancedSearchForm').removeClass('show');
            $('.advancedArrowDown').show();
            $('.advancedArrowUp').hide();
       }
    });
});
</script>
<form id="core-search-form" class="w-100">
<p class="mobilePlaceHolderText d-md-none">Search anything: judges, parties, opposing counsel, motion types, legal issues</p>
<div id="search-form-wrapper">
<div class="header-center-wrapper">
<div class="coreSearchInput" style="width: 100%; position: relative;">
<input id="id_q_results" name="q" type="text" class="form-control" aria-label="Search anything: judges, parties, opposing counsel, motion types, legal issues" placeholder="Search anything: judges, parties, opposing counsel, motion types, legal issues" autocomplete="off" value="judge:anderle AND " wrongful termination"">
</div>
<div id="searchTipsDropdownContainer" style="margin-bottom: 48px; z-index: -1; right: -1px; position: absolute; width: 100%; margin-top: -5px; top: 28px;">
<div class="dropDownContainer GayGW">
<div class="searchDropDownContainer bAcwUd">
<div class="tipsContainer">
<div class="tipsTitle">SEARCH TIPS</div>
<div class="tipContent">

<span><strong>judge:last-name</strong></span>
<span>judge:Abbot</span>
<span>Filter by a specific judge name.</span>
</div>
<div class="tipContent">

<span><strong>party:party-name</strong></span>
<span>party:&quot;Apple inc&quot;</span>
<span>Filter by a specific party name.</span>
</div>
<div class="tipContent">

<span><strong>county:name</strong></span>
<span>county:losangeles</span>
<span>Filter by a specific county without spaces.</span>
</div>
<div class="tipContent">

<span><strong>AND</strong></span>
<span>&quot;damages&quot; AND &quot;injuries&quot; AND &quot;relief&quot;</span>
<span>Both terms must appear in document</span>
</div>
<div class="tipContent">

<span><strong>OR</strong></span>
<span>&quot;modify&quot; OR &quot;ammend&quot;</span>
<span>Either terms can appear in document</span>
</div>
<div class="tipContent">

<span><strong>&quot;&quot;</strong></span>
<span>&quot;motion for summary judgment&quot;</span>
<span>Exact match of phrase</span>
</div>
<div class="tipContent">

<span><strong>*</strong></span>
<span>negligen*</span>
<span>Match anything after the *</span>
</div>
 <div class="tipContent">

<span><strong>( )</strong></span>
<span>&quot;motion&quot; AND (&quot;dismiss&quot; OR &quot;summary&quot;)</span>
<span>Grouping of terms</span>
</div>
</div>
</div>
</div>
<div class="advancedSearchButtonContainer">
<button class="advancedSearchButton" type="button">
Advanced Search
</button>
</div>
</div>
<div class="input-group-append">
<select id="stateSelect" class="custom-select multiselect dropdown-toggle btn btn-default" name="state" multiple="multiple" title="select state here"></select>
<button class="btn btn-search" type="submit" aria-label="search button">
<div class="rINcab searchButtonIcon">
<span class="z1asCe MZy1Rb">
<svg focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
<path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z">
</path>
</svg>
</span>
</div>
<div class="spinner-border text-primary searchButtonSubmitting d-none" role="status">
<span class="sr-only">Loading...</span>
</div>
</button>
</div>
</div>
</div>
<div id="advancedSearch" class="advancedSearchContainer">
<div class="overlay-button mr-auto">
<button type="button" class="alert-action-btn ml-xl-2 alert-overlay-btn" data-alert-name='judge:anderle AND &quot;wrongful termination&quot;' data-alert-state="[&#39;ca&#39;]" data-toggle="tooltip" data-placement="top" data-add-all=1 title="Alert me with new cases related to this topic">
<img src="/static/alerts/bell-icon-2.svg" alt="bell-icon">
Track This Topic
</button>
</div>
<button class="advanced-search-btn dropdown-toggle" type="button" aria-label="advanced search button dropdown-toggle">
Advanced Search &nbsp;
<svg class="advancedArrowDown" width="10" height="7" viewBox="0 0 10 7" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M1.17917 0L5 4.32839L8.82083 0L10 1.33581L5 7L0 1.33581L1.17917 0Z" fill="#333333" />
</svg>
<svg class="advancedArrowUp" width="10" height="7" viewBox="0 0 10 7" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8.82083 7L5 2.67161L1.17917 7L0 5.66419L5 1.19209e-07L10 5.66419L8.82083 7Z" fill="#333333" />
</svg>
</button>
<div class="advancedSearchForm dropdown-menu row">
<div class="advancedSearchFormLeft col-12 col-md-6">
<div class="advancedInputGroup">
<label class="sectionLabel" for="Judge_Name">Judge</label>
<input type="text" class="form-control" name="advanced_judge" placeholder="Judge Name" id="Judge_Name">
</div>
<div class="advancedInputGroup">
<label class="sectionLabel" for="Party_Name">Party</label>
<input type="text" class="form-control" name="advanced_party" placeholder="Party Name" id="Party_Name">
</div>
</div>
<div class="advancedSearchFormRight col-12 col-md-6">
<div>
<label class="sectionLabel">Date</label>
<div class="dateRangeInputContainer d-flex flex-row">
<label class="customRadioContainer">Last 6 Months
<input name="date_range" value="6" type="radio">
<span class="checkmark"></span>
</label>
<label class="customRadioContainer">Last Year
<input name="date_range" value="12" type="radio">
<span class="checkmark"></span>
</label>
<label class="customRadioContainer">All Time
<input name="date_range" value="all" type="radio">
<span class="checkmark"></span>
</label>
</div>
</div>
</div>
<div class="searchTipsContainer2">
<button class="advanced-search-tips-btn" type="button">
SEARCH TIPS
</button>
<div id="searchTipsDropdownContainer2">
<div class="dropDownContainer GayGW">
<div class="searchDropDownContainer bAcwUd">
<div class="tipsContainer">
<div class="tipContent">
<span><strong>judge:last-name</strong></span>
<span>judge:Abbot</span>
<span>Filter by a specific judge name.</span>
</div>
<div class="tipContent">
<span><strong>party:party-name</strong></span>
<span>party:&quot;Apple inc&quot;</span>
<span>Filter by a specific party name.</span>
</div>
<div class="tipContent">
<span><strong>county:name</strong></span>
<span>county:losangeles</span>
<span>Filter by a specific county without spaces.</span>
</div>
<div class="tipContent">
<span><strong>AND</strong></span>
<span>&quot;damages&quot; AND &quot;injuries&quot; AND &quot;relief&quot;</span>
<span>Both terms must appear in document</span>
</div>
<div class="tipContent">
<span><strong>OR</strong></span>
<span>&quot;modify&quot; OR &quot;ammend&quot;</span>
<span>Either terms can appear in document</span>
</div>
<div class="tipContent">
<span><strong>&quot;&quot;</strong></span>
<span>&quot;motion for summary judgment&quot;</span>
<span>Exact match of phrase</span>
</div>
<div class="tipContent">
<span><strong>*</strong></span>
<span>negligen*</span>
<span>Match anything after the *</span>
</div>
<div class="tipContent">
<span><strong>( )</strong></span>
<span>&quot;motion&quot; AND (&quot;dismiss&quot; OR &quot;summary&quot;)</span>
<span>Grouping of terms</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</form>
</div>
</div>

<div class="container-fluid search-container">

<div class="results-container d-flex flex-column justify-content-center align-items-center">

<div class="main-content-container d-flex flex-row w-100">

<style>
    
/* body*/
#bodyWrapper{
    background: #fafafa;
    max-width: 1600px;
    margin: auto;
}
.bodyBackground{
    background: #fafafa !important;
}
/* Sidebar */
#docketFilterContainer, #rulingFilterContainer {
    width: 290px;
}

/* Sidebar Modules */
label {
    margin: 0;
    margin-left: 0.5em;
}
#sidebar h4 {
    padding: 0.5rem 1em;
    font-style: normal;
    font-weight: 500;
    font-size: 16px;
    line-height: 20px;
    color: #174742;
    background: #f0f0f0;
    background-image: url("/static/global/icon-down-arrow.svg");
    background-repeat: no-repeat;
    background-position: right 10px center;
}
#sidebar h4:hover {
    cursor: pointer;
}
#sidebar .filter-module:not(:last-of-type) {
    margin-bottom: 0.7em;
}

.filter-module h4 {
    margin-top: 0;
    margin-bottom: 0;
}
.filter-group, .form-radio {
    padding-left: 0.5em;
    margin-bottom: .5rem;
    display: flex;
    align-items: center;
}
.form-radio:first-of-type {
    padding-top: 0.35rem;
}
#sidebar {
    position: relative;
}
#sidebar .filter-input, #sidebar .form-radio-input {
    margin: 0 0.25rem;
}
#sidebar .filter-radio-button-holder {
    height: auto;
    max-height: 300px;
    overflow: auto;
    padding-top: 0.75rem ;
    padding-bottom: 0.5rem;
    padding-left: 0.35rem;
    padding-right: 0.5rem;
    background: #fff;
}
#sidebar .filter-further .filter-radio-button-holder {
    padding: 1em 1.25em;
    overflow: visible;
    max-height: fit-content;
}
.btn-case-search {
    margin-top: 15px;
    margin-bottom: 15px;
}
#sidebar h3.sidebarHeader {
    position: absolute;
    color: #456D68;
    font-size: 16px;
    font-weight: 500;
    top: -43px;
    left: 3px;
}
.applyButtonFooter {
    display: none;
    padding: 8px;
    text-align: right;
}
.section-reset, .all-reset, .trellis-apply-button {
    font-size: 14px;
    font-weight: 500;
    color: rgb(255, 255, 255) !important;
    border: 1px solid rgb(0, 135, 90) !important;
    width: 100px;
    padding: 7px 5px;
    text-align: center;
    background: rgb(0, 135, 90) !important;
    text-decoration: none;
    border-radius: 4px;

}
a.all-reset.d-block.mt-2:hover {
    font-size: 14px;
    font-weight: 500;
    color: rgb(255, 255, 255) !important;
    border: 1px solid rgb(0, 102, 68) !important;
    width: 100px;
    padding: 7px 5px;
    text-align: center;
    text-decoration: none;
    background: rgb(0, 102, 68) !important;
    border-radius: 4px;
}

/* File Checkbox */
.checkbox label:after {
    content: '';
    display: table;
    clear: both;
  }
.checkbox .cr {
    position: relative;
    display: inline-block;
    border: 1px solid #a9a9a9;
    border-radius: .25em;
    width: 1.3em;
    height: 1.3em;
    float: left;
    margin-right: .5em;
    text-align: center;
}
.checkbox .cr .fa-check {
    font-size: .8em;
}
.checkbox label input[type="checkbox"] {
    display: none;
}
.checkbox label input[type="checkbox"]+.cr>.fa-check {
    opacity: 0;
}
.checkbox label input[type="checkbox"]:checked+.cr>.fa-check {
    opacity: 1;
}
.checkbox label input[type="checkbox"]:disabled+.cr {
    opacity: .5;
}

.filterBoxInput {
    width: 94%;
    margin: 0 auto;
    margin-bottom: -3px;
    height: 34px;
    color:#000 !important;
}
.form-control:focus {
    border-color: #466C68;
    border-width: 2px;
    box-shadow: none;
    color:#000 !important;
}
</style>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">
    $(document).ready(function () {

  // Submit Case Search Form + Validation
    $('.btn-case-search').click(function(e) {

        e.preventDefault();

        var $form = $('#refine-form');
        var daterange = $('#reportrange span').text();
        var datestart;
        var dateend;
        if(daterange && daterange !== 'All') {
            if(daterange.indexOf(' - ') > -1) {
                var dates = daterange.split(' - ');
                if(dates.length == 2) {
                    var datestart_moment = moment(dates[0], 'MMM D, YYYY');
                    var dateend_moment = moment(dates[1], 'MMM D, YYYY');
                    datestart = datestart_moment.format('YYYY-MM-DD');
                    dateend = dateend_moment.format('YYYY-MM-DD');
                }
            }
        }

        $('<input>').attr({
            type: 'hidden',
            id: 'case-datestart',
            name: 'datestart',
            value: datestart
        }).appendTo($form);
        $('<input>').attr({
            type: 'hidden',
            id: 'case-dateend',
            name: 'dateend',
            value: dateend
        }).appendTo($form);

        var urlParams = new URLSearchParams(window.location.search);
        var sort = urlParams.get('sort');
        var order = urlParams.get('order');
        if (sort) {
            $('<input>').attr({
                type: 'hidden',
                name: 'sort',
                value: sort
            }).appendTo($form);
        }
        if (order) {
            $('<input>').attr({
                type: 'hidden',
                name: 'order',
                value: order
            }).appendTo($form);
        }
        $form.submit();
    });

    // Case Search Reset Button
    $('#case-search button[type="reset"]').click(function () {
        $('#case-search input').each(function() {
            $(this).val('');
        });
        $('#case-search select').each(function() {
            $(this).val('');
        });
        $('.errors').html('');
        $('#reportrange span').text('');
        return false;
    });

    // Instantiate Daterangepicker Instance
    $(function() {
        function cb(start, end) {
            if (!start.isValid() || !end.isValid()) {
                $('#reportrange span').html('All');

            } else {
                $('#reportrange span').html(start.format('MMM D, YYYY') + ' - ' + end.format('MMM D, YYYY'));
            }
        }

        $('#reportrange').daterangepicker({
            opens: 'right',
            ranges: {
                'All': [moment(null), moment(null)],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'Last 6 months': [moment().subtract(6, 'months'), moment()],
                'Last Year': [moment().subtract(1, 'year'), moment()],
                'Last 2 Years': [moment().subtract(2, 'years'), moment()],
                'Last 5 Years': [moment().subtract(5, 'years'), moment()]
            }
        }, cb);
    });

    // Set Date Range Field if searched for
    var urlParams = new URLSearchParams(location.search);
    var datestartParam = urlParams.get('datestart');
    var dateendParam = urlParams.get('dateend');
    var $daterange = $('#reportrange span');
    if (datestartParam && dateendParam) {
        var datestart_q = moment(datestartParam, 'YYYY-MM-DD').format('MMM D, YYYY');
        var dateend_q = moment(dateendParam, 'YYYY-MM-DD').format('MMM D, YYYY');
        $daterange.text(datestart_q + ' - ' + dateend_q);
    } else {
        $daterange.text('All');
    }

    // Toggle Advanced Search
    $('.advanced-search-expand').click(function () {
        var currentStatus = $('.searchAdvancedContainer').css('display');
        if (currentStatus == 'none') {
            $('.searchAdvancedContainer').css('display', 'flex');
            $('.advancedSearchText').text('Hide Advanced Search');
            $('span.advanced-search-icon').removeClass('plus-icon');
            $('span.advanced-search-icon').addClass('minus-icon');

        } else {
            $('.searchAdvancedContainer').css('display', 'none');
            $('.advancedSearchText').text('Advanced Search');
            $('span.advanced-search-icon').removeClass('minus-icon');
            $('span.advanced-search-icon').addClass('plus-icon');
        }
    });

    // Get the CSRF Token & Set it in the AJAX
    var csrftoken = $("[name=csrfmiddlewaretoken]").val();
    function csrfSafeMethod(method) {
        // these HTTP methods do not require CSRF protection
        return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
    }
    $.ajaxSetup({
        beforeSend: function (xhr, settings) {
            if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
            }
        }
    });

    // State Dropdown Selection + Populate Relevant Counties
    $('.stateDropdownItem').click(function(e) {
        var state_code = $(this).data('state');
        $('.stateDropdownValue').text($(this).text());
        $('.stateDropdownValue').attr('data-state', $(this).data('state'));

        $.ajax({
            url: '/api/counties/' + state_code,
            type: "GET",  
            success: function  (res) {
                $('.countyDropdownList').empty();
                var counties = res.data;
                for (const key in counties) {
                    $('.countyDropdownList').append(`
                        <li class="menuNavLink countyDropdownItem" data-county="${counties[key]['county_name_short']}">
                            ${counties[key]['county_name_proper']}
                        </li>
                    `);
                }
                $('.wrapper-dropdown').removeClass('active');
                $('.countyDropdown').addClass('active');
            }         
        })    
    });

    // County Dropdown Selection
    $('.countyDropdownList').on('click', '.countyDropdownItem', function(e) {
        e.preventDefault();
        e.stopPropagation();
        $('.wrapper-dropdown').removeClass('active');
        $('.countDropdownValue').text($(this).text());
        $('.countDropdownValue').attr('data-county', $(this).data('county'));     
    });

    // New Contact Request on Docket Tab
    $('#noResultContactForm').submit(function(e) {
        e.preventDefault();
        disableSubmitButton($('.contactRequestSubmitBtn'));
        
        if (!IS_AUTHENTICATED) {
            window.location = '/login?post_logged_in_path=' + btoa(window.location.href);
            return;
        }

        e.preventDefault();
        $('.dr-error-text').text('');
        var comments = $('[name=details]').val();
        var query = $('[name=q]').val();
        if (!comments) {
            $('.dr-error-text').text('Please fill out the form above.');
            enableSubmitButton($('.contactRequestSubmitBtn'));
            return;
        }
        var data = {
            details: comments,
            q: query
        };
        amplitude.getInstance().logEvent('No Results Page - Contact Request - Submitted', data);                

        $.ajax({
            url: '/search/ask',
            type: "POST",
            data: data,  
            success: function(res) {
                enableSubmitButton($('.contactRequestSubmitBtn'));
                $('.docket-request-main-content').hide();
                $('.docket-request-confirmation').show();
                $('#docket-search-request-confirmation').text(
                    "Thank you, your request was submitted successfully. Our support team will reach out to you contact you with more information."
                );
                amplitude.getInstance().logEvent('No Results Page - Contact Request - Success', data);                

            },
            error: function(err) {
                enableSubmitButton($('.contactRequestSubmitBtn'));
                $('.docket-request-main-content').show();
                $('.docket-request-confirmation').hide();
                $('.dr-error-text').text('Something went wrong. Please refresh and try again.');
                amplitude.getInstance().logEvent('No Results Page - Contact Request - Error', err);                
            }
        });
    });

    // Docket Refresh Request on No results UX
    $('.submitDocketSearchRequest').click(function() {
        disableSubmitButton($(this));
        $('.docket-request-error-text').text('');
        var state = $('.stateDropdownValue').data('state');
        var county = $('.countDropdownValue').data('county');
        var case_number = $('[name=case_number]').val();

        if (!state || !county || !case_number) {
            $('.docket-request-error-text').text('Please fill out all fields.');
            enableSubmitButton($(this));
            return;
        }

        var data = {
            state: state,
            shortname: county,
            case_number: case_number,
            case_url_path: window.location.href
        };
        amplitude.getInstance().logEvent('No Results Page - Case Refresh Request - Submitted', data);                

        $.ajax({
            url: '/api/case/docket_refresh_request',
            type: "POST",
            data: data,  
            success: function(res) {
                enableSubmitButton($('.submitDocketSearchRequest'));
                $('.docket-request-main-content').hide();
                $('.docket-request-confirmation').show();
                amplitude.getInstance().logEvent('No Results Page - Case Refresh Request - Success', data);                
            },
            error: function(err) {
                enableSubmitButton($('.submitDocketSearchRequest'));
                $('.docket-request-main-content').hide();
                $('.docket-request-confirmation').show();
                
                var comments = `
                    A user has requested to refresh a case in a county that is not yet suported.

                    Info:
                    State - ${state.toUpperCase()}
                    County - ${county}
                    Case Number - ${case_number}
                `;
                var query = $('[name=q]').val();
                if (!comments) {
                    $('.dr-error-text').text('Please fill out the form above.');
                    enableSubmitButton($('.contactRequestSubmitBtn'));
                    return;
                }
                var ask_data = {
                    details: comments,
                    q: query
                };
                $.ajax({
                    url: '/search/ask',
                    type: "POST",
                    data: ask_data
                });     
                amplitude.getInstance().logEvent('No Results Page - Case Refresh Request - Case Not Refreshable', data);                

            }
        });        
    })
});


function disableEnterKey() {
    // Prevent user from pressing enter to trigger a page refresh
    // From https://stackoverflow.com/a/2105072/761726
    var eve = window.event;
    var keycode = eve.keyCode || eve.which || eve.charCode;

    if (keycode == 13) {
        eve.cancelBubble = true;
        eve.returnValue = false;

        if (eve.stopPropagation) {
            eve.stopPropagation();
            eve.preventDefault();
        }

        return false;
    }
}


function filterAggregations(inputId, item_class) {
    // Aggregation filter box function
    // From https://www.w3schools.com/howto/howto_js_filter_lists.asp
    var filter = $("#" + inputId).val().toUpperCase();

    $('.' + item_class).each(function(index, value) {
        var txtValue = value.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            value.style.display = "";
        } else {
            value.style.display = "none";
        }
    });
};

</script>
<div id="sidebar" class="filters-container d-none d-md-block">
<h3 class="sidebarHeader">Filter By:</h3>
<form method="get" id="refine-form" action="/rulings/judge:anderle AND &quot;wrongful termination&quot;">
<div id="rulingFilterContainer">
<div class="filter-module filter-type">
<h4>Type</h4>
<div class="filter-radio-button-holder">
<input type="text" id="type-input" class="filterBoxInput form-control" placeholder="


Filter by Type

                                       " onkeyup="if (!window.__cfRLUnblockHandlers) return false; filterAggregations('type-input',
                                                                      'type-item')" onkeydown="if (!window.__cfRLUnblockHandlers) return false; disableEnterKey()" data-cf-modified-acfcc1acf16c1b3b565e9d8c-="" />
</div>
<div class="filter-radio-button-holder">
<div class="filter-group type-item">
<input id="filter-state-civil" class="filter-input trellisRulingSearchFilter" name="type" type="checkbox" value="civil">
<label class="filter-label" for="filter-state-civil">
Civil
(7)
</label>
</div>
</div>
<div class="applyButtonFooter">
<button class="trellis-apply-button trellis-green2">Apply</button>
</div>
</div>
<div class="filter-module filter-judge">
<h4>Judge</h4>
<div class="filter-radio-button-holder">
<input type="text" id="judge-input" class="filterBoxInput form-control" placeholder="


Filter by Judge Name

                                       " onkeyup="if (!window.__cfRLUnblockHandlers) return false; filterAggregations('judge-input',
                                                                      'judge-item')" onkeydown="if (!window.__cfRLUnblockHandlers) return false; disableEnterKey()" data-cf-modified-acfcc1acf16c1b3b565e9d8c-="" />
</div>
<div class="filter-radio-button-holder">
<div class="filter-group judge-item">
<input id="filter-state-Thomas Anderle" class="filter-input trellisRulingSearchFilter" name="judge" type="checkbox" value="Thomas Anderle">
<label class="filter-label" for="filter-state-Thomas Anderle">
Thomas Anderle
(34)
</label>
</div>
</div>
<div class="applyButtonFooter">
<button class="trellis-apply-button trellis-green2">Apply</button>
</div>
</div>
<div class="filter-module filter-county">
<h4>County</h4>
<div class="filter-radio-button-holder">
<input type="text" id="county-input" class="filterBoxInput form-control" placeholder="


Filter by County

                                       " onkeyup="if (!window.__cfRLUnblockHandlers) return false; filterAggregations('county-input',
                                                                      'county-item')" onkeydown="if (!window.__cfRLUnblockHandlers) return false; disableEnterKey()" data-cf-modified-acfcc1acf16c1b3b565e9d8c-="" />
</div>
<div class="filter-radio-button-holder">
<div class="filter-group county-item">
<input id="filter-state-6083" class="filter-input trellisRulingSearchFilter" name="county" type="checkbox" value="6083">
<label class="filter-label" for="filter-state-6083">
Santa Barbara County, CA
(34)
</label>
</div>
</div>
<div class="applyButtonFooter">
<button class="trellis-apply-button trellis-green2">Apply</button>
</div>
</div>
<a class="all-reset d-block mt-2" href="/rulings/judge:anderle AND &quot;wrongful termination&quot;">Reset All</a>
</div>
</form>
</div>

<div id="results-right" class="search-results-container d-flex flex-column">

<div class="tabs-container d-flex flex-row justify-content-start">
<a href="/rulings/judge:anderle%20AND%20%22wrongful%20termination%22/?" class="search-tabs-btn mr-2 active">Rulings
<span class="tabCount rulingCountTab">
</span>
</a>
<a href="/cases/judge:anderle%20AND%20%22wrongful%20termination%22/?" class="search-tabs-btn mr-2 ">Dockets
<span class="tabCount docketCountTab">
</span>
</a>
<a href="/docs/judge:anderle%20AND%20%22wrongful%20termination%22/?" class="search-tabs-btn mr-2 ">Documents
<span class="tabCount documentCountTab">
</span>
</a>
</div>

<div class="results-sort-bar d-flex flex-row justify-content-center justify-content-md-between align-items-center">
<div class="results-count d-none d-md-flex ml-1">
<p>1-25 of <span class="pageCount"></span> results</p>
</div>
<div class="sort-by-bar d-flex flex-row align-items-center">
<div class="d-flex flex-row align-items-center">
<p class="mr-3">Sort By</p>
<div class="dropdown trellisDropdown sort-button-group">
<a aria-expanded="false" aria-haspopup="true" role="button" data-toggle="dropdown" class="dropdown-toggle sortGroupButton" href="#">
<span id="selected">Most Relevant</span>
<span class="caret"></span>
</a>
<ul class="trellisDropdownMenu dropdown-menu dropdown-menu-right">
<li class="active">
<a href="/rulings/judge:anderle%20AND%20%22wrongful%20termination%22?sort=relevance" data-sort-by="relevance" class="search-sort-button ">Most Relevant</a>
</li>
<li class="">

<a href="/rulings/judge:anderle%20AND%20%22wrongful%20termination%22?sort=date" data-sort-by="date" class="search-sort-button">Newest to Oldest</a>
</li>
</ul>
</div>
</div>
</div>
</div>
<div class="results-wrapper">

<style>
    

/* Containers & Elements */
h2 {
    margin: 0;
    line-height: 0;
}
p {
    margin: 0;
}
a {
    color: #0d4fd5;
    text-decoration: none;
    font-size: 13px;
}
a:hover {
    text-decoration: underline;
}
label {
    margin: 0;
    margin-left: 0.5em;
}

/* TEXT FONTS */
.search-result h2 a {
    font-weight: normal;
    line-height: 17px;
    text-decoration: none;
    color: #0d4fd5;
}
.search-result h2 a:hover:not(.disabled):not(.sealed) {
    text-decoration: underline;
}
.result-judge h2 a {
    font-size: 16px;
}
.judge-result-text {
    margin: 0;
    font-size: 14px;
}
.result-tentative h2 a {
    text-transform: uppercase;
    margin-top: 0;
    font-weight: normal;
    font-size: 16px;
    line-height: 17px;

}
.result-info-module ul {
    padding: 0;
    margin: 0;
    list-style-type: none;
    width: 100%;
}
.result-info-module ul li span {
    min-width: 65px;
    font-weight: 500;
    font-size: 11px;
    line-height: 14px;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: #456D68;
    margin-right: 0.2rem;
}
.result-info-module ul li p {
    font-weight: normal;
    font-size: 13px;
    line-height: 14px;
     color: #000;
}
.search-snippet {
    font-style: normal;
    font-weight: normal;
    font-size: 13px;
    line-height: 17px;
    color: #000;
}

/* Search Results */
    /* Result */
    .search-result {
        display: flex;
        flex-direction: column;
    }
    .search-result.result-tentative {
        padding: 15px 20px;
    }
    .search-result.result-tentative.result-document {
        padding: 29px 20px;
        position: relative;
        z-index: 0;
    }
    @media (min-width: 768px) {
        .search-result.result-tentative {
            padding: 15px 20px;
        }      
    }

    /* Result Info Module */
    .result-info-module {
        width: 100%;
    }
    .result-info-module ul li {
        display: flex;
        flex-direction: row;
        padding-right: 0.3em;
        margin-bottom: 0.3em;
    }
    @media (min-width: 768px) {
        .result-info-module ul li:not(:last-child) {
            margin-bottom: 0.75em;
        }
    }

    /* Ruling Result */
    .search-result.result-tentative {
/*        border-top: 1px solid #EDF0EA;*/
          border: 1px solid #e1e1e182;
          background: #fff;
    }
    .search-result.result-tentative:last-of-type {
        border-bottom: 1px solid #EDF0EA;
    }
    .search-result.result-tentative h2 {
        margin-bottom: 10px;
    }
    .search-snippet:not(:last-child) {
        margin-bottom: 15px;
    }

    /* Judge Result */
    .search-result.result-judge {
        padding: 0 15px 25px;
    }
    .search-result.result-judge h2 {
        margin-bottom: 4px;
    }
    .search-result.result-judge:last-of-type {
        margin-bottom: 2em;
    }



/* Search Bar */
.searchPopulate {
    background: transparent;
    margin-bottom: 1em;
}
.header-center-wrapper {
    margin-bottom: 0;
}

/* Results Count */
.results-count {
    display: none;
}
@media (min-width: 768px) {
    .results-count {
        display: flex;
    }
}

</style>

<div class="track-overlay">
<div class="overlay-content">
<div class="overlay-text">
<p>
Get an alert with new cases related to: judge:anderle AND &quot;wrongful termination&quot;
</p>
</div>
<div class="overlay-button">
<button type="button" class="alert-action-btn ml-xl-2 alert-overlay-btn" data-alert-name='judge:anderle AND &quot;wrongful termination&quot;' data-alert-state="[&quot;ca&quot;]" data-toggle="tooltip" data-placement="top" data-add-all=1 title="Alert me with new rulings related to this topic">
<img src="/static/alerts/bell-icon-2.svg" alt="bell-icon">
Track This Topic
</button>
</div>
<div class="overlay-checkbox">
<label class="trellisCheckboxContainer mt-2">Don't show this again
<input id="alertShowSetting" type="checkbox" name="show_topic_alert" class="dont-show-input">
<span class="checkmark"></span>
</label>
</div>
</div>
</div>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">    
    // Track Popup
    setTimeout(() => {
        $('.track-overlay').slideDown(500);
        amplitude.getInstance().logEvent('Track Case Overlay - Viewed');       
    }, 3000);
    $('.track-overlay .alert-action-btn').click(function(e) {
        amplitude.getInstance().logEvent('Track Case Overlay - Added');
        $('.tooltip').tooltip("hide");
        setTimeout(() => {
            $('.track-overlay').slideUp(500);
        }, 3000);
    })
</script>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/15CV00589/Quiana-Foley-vs-SB-Books/20151027f5e484" class="">
QUIANA FOLEY VS SB BOOKS
</a>
</h2>
<p class="search-snippet">(2) <em>Wrongful</em> <em>Termination</em>
Foley’s second cause of action is for <em>wrongful</em> <em>termination</em> in violation of public policy.
“‘[W]hile an at-will employee may be terminated for no reason, or for an arbitrary or irrational reason, there can be no right to terminate for an unlawful reason or a purpose that contravenes fundamental public policy.’ [Citations.]</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Oct 27, 2015</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/15CV00589/Quiana-Foley-v-S-B-Books-Inc-et-al/20150804d441a9" class="">
QUIANA FOLEY V. S B BOOKS, INC., ET AL.
</a>
</h2>
<p class="search-snippet">Section 47 does not require or forbid making police reports, and at best only alludes to a special status for reports to law enforcement, which is insufficient to create <em>wrongful</em> <em>termination</em> liability. Defendants assert that case law also does not establish public policies sufficient to support a claim for <em>wrongful</em> <em>termination</em> in violation of public policy. The Hagberg case cited by plaintiff is unrelated to <em>wrongful</em> <em>termination</em>. In Gantt v.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Aug 04, 2015</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1486799/Michael-M-Price-MD-v-Richard-D-Scheinberg-MD-Inc/20170926697175" class="">
MICHAEL M. PRICE, MD V. RICHARD D. SCHEINBERG, MD, INC.
</a>
</h2>
<p class="search-snippet">Defendants demur to the cause of action, contending that plaintiff’s <em>wrongful</em> <em>termination</em> claim has no basis in any statutory violation, given that his Section 1102.5 retaliation claim fails as a matter of law and cannot support his <em>wrongful</em> <em>termination</em> claim, citing Love v. Motion Indus., Inc. (N.D. Cal. 2004) 309 F.Supp.2d 1128, 1135.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Sep 26, 2017</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1467329/Garrett-Burkhart-vs-Boris-Zak-et-al/201408051467e5" class="">
GARRETT BURKHART VS BORIS ZAK ET AL
</a>
</h2>
<p class="search-snippet">Defendants seek to strike the allegations of punitive damages contained in paragraphs 59 and 60 in the third cause of action (<em>wrongful</em> <em>termination</em>), in paragraph 85 in the seventh cause of action (misclassification), and in the prayer.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Aug 05, 2014</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1338554/Carlos-Cifuentes-vs-Costco-Wholesale-Corporation-et-al/2010062957ca43" class="">
CARLOS CIFUENTES VS COSTCO WHOLESALE CORPORATION ET AL
</a>
</h2>
<p class="search-snippet"><em>Wrongful</em> <em>termination</em> cause of action. The Court agrees with the argument presented by Costco in its Points and Authorities filed March 10, 2010, at pages 6 through 9. The Court did not find Cifuentes’ argument in his Points and Authorities filed on May 25, 2010, at pages 11 through 17 persuasive.
2nd C/A. Defamation. The Court agrees with the argument made by Costco on this issue in its Points and Authorities at pages 10 and 11.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Jun 29, 2010</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/20CV00675/Damian-Garcia-v-Cottage-Health-et-al/20210720c12e86" class="">
DAMIAN GARCIA V. COTTAGE HEALTH, ET AL.
</a>
</h2>
<p class="search-snippet">BACKGROUND
This is an action for alleged disability discrimination and <em>wrongful</em> <em>termination</em>. Plaintiff Damian Garcia worked as a phlebotomy technician for defendant Cottage Health from June 2016 until his termination on September 10, 2019.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Jul 20, 2021</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/17VB00106/Dawn-Holmes-PhD-v-Regents-of-the-University-of-California/20170516c7ee7b" class="">
DAWN HOLMES, PHD V. REGENTS OF THE UNIVERSITY OF CALIFORNIA
</a>
</h2>
<p class="search-snippet">The plaintiff asserted causes of action for <em>wrongful</em> <em>termination</em>, breach of contract and promissory estoppel. (Ibid.) The trial court sustained the demurrer to each of these causes of action on the grounds that public employment is governed by statute not contract, and that claims based on misrepresentation were subject to the immunity of Government Code section 818.8. (Ibid.)
On appeal, the Piccinini court affirmed the dismissals of the causes of action for <em>wrongful</em> <em>termination</em> and breach of contract.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>May 16, 2017</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1371259/David-Marshall-vs-Esprida-Corporation/20110329a111c4" class="">
DAVID MARSHALL VS ESPRIDA CORPORATION
</a>
</h2>
<p class="search-snippet">Background:
This is an action for breach of contract and <em>wrongful</em> <em>termination</em>.
Plaintiff David Marshall filed his complaint alleging breach of contract on August 20, 2010. The First Amended Complaint (“FAC”) was filed on January 3, 2011. The FAC alleges that Marshall entered into a written employment agreement with defendant Esprida Corporation (“Esprida”). (FAC, ¶ 12.) Esprida is a technology company organized as a Delaware corporation and headquartered in Canada. (FAC, ¶¶ 4, 10.)</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Mar 29, 2011</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1380047/Omar-Rodriguez-vs-Miguel-Cristales/2012030628ea4c" class="">
OMAR RODRIGUEZ VS MIGUEL CRISTALES
</a>
</h2>
<p class="search-snippet">Plaintiff’s causes of action are 1) unpaid overtime wages, 2) violation of Labor Code § 203 – payment of wages due upon termination, 3) violation of Labor Code § 206 – accurate wage statements, 4) misclassification as an independent contractor, 5) expense reimbursement, 6) unfair business practices, and 7) <em>wrongful</em> <em>termination</em> in violation of public policy. CMC is set for April 24, MSC for May 25, and trial for June 12, 2012.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Mar 06, 2012</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1439574/William-Brown-vs-Ontraport-et-al/201406032fc322" class="">
WILLIAM BROWN VS ONTRAPORT ET AL
</a>
</h2>
<p class="search-snippet">On January 14, 2014, plaintiff filed suit against Ontraport and Requist for discrimination in violation of California�s Fair Employment and Housing Act (FEHA), <em>wrongful</em> <em>termination</em>, and intentional infliction of emotional distress. Shortly after the action was filed, the parties met and agreed to settle the matter. Under the terms of the settlement, plaintiff agreed to cooperate and join in a motion by defendants to seal the case file.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Jun 03, 2014</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/20CV00675/Damian-Garcia-v-Cottage-Health-et-al/20200818b58d80" class="">
DAMIAN GARCIA V. COTTAGE HEALTH, ET AL.
</a>
</h2>
<p class="search-snippet">Plaintiff’s causes of action in this action are 1) sex harassment; 2) disability harassment; 3) disability discrimination; 4) failure to enter into the interactive process; 5) retaliation; 6) failure to prevent harassment, discrimination, and retaliation; 7) wage complaint retaliation; and 8) <em>wrongful</em> <em>termination</em> in violation of public policy.
On July 2, 2020, defendants served a deposition subpoena for production of business records on plaintiff’s current employer, Quest Diagnostics.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Aug 18, 2020</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/20CV00675/Damian-Garcia-v-Cottage-Health-et-al/20210413cd8aa7" class="">
DAMIAN GARCIA V. COTTAGE HEALTH, ET AL.
</a>
</h2>
<p class="search-snippet"><em>Wrongful</em> <em>Termination</em> in Violation of Public Policy.
Plaintiff pleads for special and general damages, punitive damages; interest and attorney fees.
Defendant filed an answer via general denial; sets out 17 affirmative defenses; seeks attorney fees.
The case was filed February 5, 2020.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Apr 13, 2021</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1383043/Nancy-Dewi-vs-Te-Connectivity-et-al/2013012298c97b" class="">
NANCY DEWI VS TE CONNECTIVITY ET AL
</a>
</h2>
<p class="search-snippet">Plaintiff’s second amended complaint alleges causes of action against TE and two of its managers for (1) discrimination, (2) harassment, (3) retaliation, (4) failure to prevent harassment, (5) failure to accommodate disability, (6) failure to engage in interactive process, (7) violation of the California Family Rights Act, (8) retaliation in violation of the California Family Rights Act, (9) <em>wrongful</em> <em>termination</em>, and (10) failure to pay wages due.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Jan 22, 2013</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1383043/xxxxxxxxxx-vs-Te-Connectivity-et-al/201212110cf72a" class="">
XXXXXXXXXX VS TE CONNECTIVITY ET AL
</a>
</h2>
<p class="search-snippet">BACKGROUND
This is an action for alleged discrimination, harassment, and <em>wrongful</em> <em>termination</em>. As alleged in the complaint, plaintiff was born in Indonesia and is ethnic Chinese. Plaintiff suffers from multiple disabilities, including a back injury, claustrophobia, and a facial deformity and speech disorder resulting from a cleft palate.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Dec 11, 2012</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>

<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/15CV02299/Rachel-Moon-v-OSF-Medical-Group-of-California-Inc-et-al/20160216241acf" class="">
RACHEL MOON V. OSF MEDICAL GROUP OF CALIFORNIA, INC., ET AL.
</a>
</h2>
<p class="search-snippet">., (5) failure to prevent discrimination in violation of Government Code Section 12940(k), (6) <em>wrongful</em> <em>termination</em> in violation of public policy, (7) intentional infliction of emotional distress, (8) negligent infliction of emotional distress, and (9) unfair business practices in violation of Business and Professions Code Section 17200 et seq. Plaintiff seeks punitive damages in connection with the first seven causes of action.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Feb 16, 2016</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/17CV01847/City-of-Santa-Barbara-et-al-v-CDM-Smith-Inc/20180529277a3c" class="">
CITY OF SANTA BARBARA, ET AL. V. CDM SMITH, INC.
</a>
</h2>
<p class="search-snippet">Schock filed with the City a formal claim for <em>wrongful</em> <em>termination</em> and a demand for payment as to seven items totaling $643,413.56. (Ibid.) The October 7 letter states:
“Schock argues that it constructed the Project as designed and that because the City does not point to any construction defect, Schock should be relieved of its performance obligations under the contract.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>May 29, 2018</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1341233/Stan-A-vs-Wells-Fargo-Company-et-al/201101257d3e80" class="">
STAN A VS WELLS FARGO &amp; COMPANY ET AL
</a>
</h2>
<p class="search-snippet"><em>Wrongful</em> <em>Termination</em> and Breach of Employment Contract
Plaintiff sets forth three causes of action (the seventh, eighth and ninth) alleging breach of the employment contract between plaintiff and Wells Fargo. Plaintiff’s <em>wrongful</em> <em>termination</em> cause of action (the seventh) is based upon plaintiff’s allegation that by the express or implied terms of the contract, Wells Fargo would not fire plaintiff on account of plaintiff’s disclosures. (FAC, ¶ 70.)</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Jan 25, 2011</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/15CV00746/Koosharem-LLC-v-SSST-Holdings-LLC/20151222c6425e" class="">
KOOSHAREM LLC V. SSST HOLDINGS LLC
</a>
</h2>
<p class="search-snippet">The operative complaint in the federal action (federal FAC) asserts 10 causes of action: (1) declaratory relief; (2) injunctive relief; (3) libel per se; (4) breach of contract; (5) injunctive relief; (6) conversion; (7) <em>wrongful</em> <em>termination</em>; (8) promissory fraud and fraud in the inducement; (9) violations of Business and Professions Code section 17200 et seq.; and, (10) fraud.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Dec 22, 2015</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/19CV02547/David-Norton-v-Sage-Network-Inc/20190730fedc59" class="">
DAVID NORTON V. SAGE NETWORK, INC.
</a>
</h2>
<p class="search-snippet">(Sage), for age discrimination under the Fair Employment and Housing Act (FEHA), harassment/hostile work environment (FEHA), failure to investigate or prevent harassment (FEHA), <em>wrongful</em> <em>termination</em> in violation of public policy, and declaratory judgment. Norton alleges: He was Sage’s employee working in Camarillo in Ventura County and Santa Barbara in this Santa Barbara County. His employment was terminated on February 25, 2019, after a complaint of sexual harassment by another employee.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Jul 30, 2019</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1343248/Yusuf-Lewis-vs-Valley-Slurry-Seal-Co-et-al/201010196267e3" class="">
YUSUF LEWIS VS VALLEY SLURRY SEAL CO ET AL
</a>
</h2>
<p class="search-snippet">Nature of Proceedings: Motion Change Venue
This is a motion to change venue
Ruling: Denied
Analysis:
The complaint alleges three causes of action: (1) sexual harassment, discrimination and retaliation [FEHA]; (2) national origin/race harassment, discrimination and retaliation; (3) <em>wrongful</em> <em>termination</em> and retaliation).</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Oct 19, 2010</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/15CV02131/Nick-Cai-v-The-Regents-of-the-University-of-California/20151110af5a77" class="">
NICK CAI V. THE REGENTS OF THE UNIVERSITY OF CALIFORNIA
</a>
</h2>
<p class="search-snippet">Superior Court, 45 Cal.App.4th 1716, 1726 (1996) (holding that trial court should have sustained the college’s demurrer to a complaint for <em>wrongful</em> <em>termination</em>, breach of contract, and breach of implied covenants). This decision would apply equally to student discipline proceedings.
But exhaustion of state judicial or administrative remedies is not a prerequisite to an action under 42 U.S.C. § 1983. Patsy v. Bd. of Regents of State of Fla., 457 U.S. 496, 501 (1982). The Supremacy Clause of the U.S.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Nov 10, 2015</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1343216/Raymond-Granger-vs-Skate-One-Corporation-et-al/2011050366e5be" class="">
RAYMOND GRANGER VS SKATE ONE CORPORATION ET AL
</a>
</h2>
<p class="search-snippet">Argument
First, plaintiff’s claims for disability discrimination, age discrimination, and <em>wrongful</em> <em>termination</em> in violation of public policy lack merit, because defendant had legitimate, non-
discriminatory reasons for plaintiff’s termination.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>May 03, 2011</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/1383043/Nancy-Dewi-vs-Te-Connectivity-et-al/20120731412a92" class="">
NANCY DEWI VS TE CONNECTIVITY ET AL
</a>
</h2>
<p class="search-snippet"><em>termination</em> in violation f public policy (defendants Tyco), 9) failure to pay wages due (defendants Tyco).</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Jul 31, 2012</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/18CV04924/Santa-Barbara-Nissan-LLC-v-Justin-Damarin/201902057f515d" class="">
SANTA BARBARA NISSAN, LLC V. JUSTIN DAMARIN
</a>
</h2>
<p class="search-snippet">The broad language of the agreement covered the <em>wrongful</em> <em>termination</em> claim. Id. There is no comparable “past, present, or future” language in Damarin’s agreement.
Similarly, in Gillian v. Cowabunga, Inc., 2018 WL 2431345 (N.D. Ala. 2018), the agreement provided that it “shall survive termination of Employee’s employment.” Id. at *3. In Masse v. Waffle House, 2014 WL 1901112 (W.D.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Feb 05, 2019</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<div class="search-result result-tentative">
<h2 class="resultHeader2">
<a href="/ruling/19CV00992/Damian-R-Garcia-v-Pacific-Diagnostic-Laboratories-LLC/20210713b9922e" class="">
DAMIAN R. GARCIA V. PACIFIC DIAGNOSTIC LABORATORIES LLC
</a>
</h2>
<p class="search-snippet">Unlike his <em>wrongful</em> <em>termination</em> action, plaintiff has presented viable claims here against PDL based upon the rounding claim and the overlapping wage statements. His claims with respect to these matters are entirely consistent with those of the absent class members.</p>
<div class="result-info-module d-flex flex-column flex-md-row">
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Hearing</span>
<p>Jul 13, 2021</p>
</li>
</ul>
<ul class="d-flex flex-column">
<li class="result-info-module-item">
<span>Judge </span>
<a href="/judge/thomas.p.anderle">Thomas Anderle</a>
</li>
<li class="result-info-module-item">
<span>County</span>
<p>
Santa Barbara County, CA
</p>
</li>
</ul>
</div>
</div>
<span class="mainLoadingIcon"></span>
</div>

<p class="trellis-pagination">
<span class="step-links">
<span class="current">


<a href="/rulings/judge:anderle%20AND%20%22wrongful%20termination%22?" class="deactivate">1</a>
<a href="/rulings/judge:anderle%20AND%20%22wrongful%20termination%22/2?">2</a>

</span>
&nbsp;
<a rel="next" href="/rulings/judge:anderle%20AND%20%22wrongful%20termination%22/2?">next</a>&nbsp;
<a href="/rulings/judge:anderle%20AND%20%22wrongful%20termination%22/2?">last &raquo;</a>&nbsp;
</span>
</p>
</div>
</div>
</div>
</div>
<div class="page-container printable">
<h1 class="print-text">For full print and download access, please subscribe at https://www.trellis.law/.</h1>
</div>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript" src="/static/CACHE/js/output.bc7edacc955d.js"></script>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript" src="/static/user_account/js/unpause_alert.js"></script>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript" src="/static/global/mark-8.4.0.min.js"></script>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript" src="/static/smart_search/js/index.js"></script>
<script type="acfcc1acf16c1b3b565e9d8c-text/javascript">
    $(document).ready(function() {
        // JINJA Reliant JS Needs to live in the template
        
        // Amplitude - Search Results
        amplitude.getInstance().logEvent('Search Results - View', {
            'query': 'judge%3Aanderle%20AND%20%22wrongful%20termination%22',
            'tab': 'rulings',
            'states': $('#stateSelect').val()
        });
        

        
    });
</script>


<input type='hidden' name='csrfmiddlewaretoken' value='8RDFOuw4KNXUxnJv9LHwokHbvsMLZB0dhFjAhvVvMAJ7amzHObh20R40bcZvVYxl' />
<div class="modal alertModal trellis-popup-modal" id="alertAddSuccessModal" tabindex="-1" role="dialog" aria-labelledby="alertAddSuccessModal" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="trellisPopupContent border-gray pt-0 d-flex flex-column align-items-start mt-4">
<div class="modal-title d-flex flex-row justify-content-start align-items-center">
<img class="modal-icon" src="/static/alerts/bell-icon-2.svg" alt="close icon" />
<h5>Alert Confirmation</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<p class="content mt-2">
Your alert tracking was succesfully added. We will email you
when new changes related to "<span class="alert-name-text"></span>" are available.
</p>
<div class="d-flex flex-row align-items-center justify-content-between w-100">
<a class="linkToEnableShareWithOthersPanel" href="#">Add other recipients</a>
<button type="button" class="button-close modal-btn btn-green done" data-dismiss="modal">
<span>Done</span>
</button>
</div>
<div class="shareWithOthersPanel mt-5">
<div class=" d-flex flex-column align-items-start">
<label class="mb-2" for="alert_modal_recipients_list">Share this Alert with other recipients:</label>
<div id="alert_modal_recipients_list" class="trellisEmailList"></div>
<label class="trellisCheckboxContainer mt-2">Exclude myself from this Alert
<input type="checkbox" name="excludeMeFromAlert" id="exclude_creator" />
<span class="checkmark"></span>
</label>
<div class="d-flex flex-row justify-content-between align-items-center w-100 mt-3">
<a target="_blank" class="alertSettingsLink" href="/alerts">Alert Settings</a>
<button type="button" class="startPlanButton modal-btn btn-green done" id="alert_modal_recipients_add" data-dismiss="modal">
<span>Done</span>
</button>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="upgradeTierSuccessModal" class="modal popupModalBox popupRequestConfirmation dark" tabindex="-1" role="dialog" aria-labelledby="upgradeTierSuccessModal" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header pb-0">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="border-gray pt-0 mb-4">
<h5 class="modal-title mb-3" id="exampleModalLabel">Thank You</h5>
<p>Your subscription was successfully upgraded <span class="optionalUpgradeText"></span></p>
</div>
<div class="modal-footer">
<a class="confirmationAnchor btn-primary btn-green" href="/rulings/judge:anderle AND &quot;wrongful termination&quot;" aria-label="Continue">
Continue</a>
</div>
</div>
</div>
</div>
<div id="updateCardSuccessModal" class="modal popupModalBox popupRequestConfirmation dark" tabindex="-1" role="dialog" aria-labelledby="updateCardSuccessModal" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header pb-0">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="border-gray pt-0 mb-4">
<h5 class="modal-title mb-3" id="exampleModalLabel">Thank You</h5>
<p>Your card has been successfully updated.</p>
</div>
<div class="modal-footer">
<div class="updateCardConfirmationAnchor text-decoration-none">
<button type="button" class="d-block button___2r4xk modal-btn btn-green">
<span class="d-flex flex-nowrap justify-content-center align-items-center" aria-label="Continue">
Continue
</span>
</button>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="loaderContainer">
<div class="loadingScreen">
<img class="mainLoadingIcon" src="/static/global/loader-4-css.svg" alt="">
<p>Please wait a moment while we load this page.</p>
</div>
</div>

<footer id="footer" class="page-footer hide-on-print">

<div class="container footer-container">
<div class="row justify-content-center justify-content-md-start text-center text-md-left">
<div class="col-lg-3 ml-lg-auto mb-8 mb-lg-0 text-left">

<img class="brand" src="/static/images/trellis-white-logo.svg" alt="Logo">

<ul class="list-inline mb-0 social-footer">
<li class="list-inline-item">
<a class="btn btn-xs btn-icon btn-soft-secondary rounded" href="https://www.linkedin.com/company/trellis-law" aria-label="Linkedin">
<i class="fab fa-linkedin fa-2x"></i>
</a>
</li>
<li class="list-inline-item">
<a class="btn btn-xs btn-icon btn-soft-secondary rounded" href="https://twitter.com/trellis_law" aria-label="Twitter">
<i class="fab fa-twitter fa-2x"></i>
</a>
</li>
</ul>

</div>
<div class="col-6 col-md-3 col-lg mb-5 mb-lg-0 text-left">
<h5 class="text-white">Features</h5>

<ul class="nav nav-sm nav-x-0 nav-white flex-column">
<li class="nav-item"><a class="nav-link" href="/search"> <span class="media align-items-center">
<span class="media-body">Smart Search</span>
</span></a></li>
<li class="nav-item"><a class="nav-link" href="/judges"> <span class="media align-items-center">
<span class="media-body">Judge Analytics</span>
</span></a></li>
<li class="nav-item"><a class="nav-link" href="/ca/motion-type"> <span class="media align-items-center">
<span class="media-body">Motion & Issues</span>
</span></a></li>
<li class="nav-item"><a class="nav-link" href="/coverage"> <span class="media align-items-center">
<span class="media-body">State Coverage</span>
</span></a></li>
</ul>

</div>
<div class="col-6 col-md-3 col-lg mb-5 mb-lg-0 text-left">
<h5 class="text-white">Company</h5>

<ul class="nav nav-sm nav-x-0 nav-white flex-column">
<li class="nav-item"><a class="nav-link" href="/"> <span class="media align-items-center">
<span class="media-body">Home</span>
</span></a></li>
<li class="nav-item"><a class="nav-link" href="/about"> <span class="media align-items-center">
<span class="media-body">About</span>
</span></a></li>
<li class="nav-item"><a class="nav-link" href="/contact"> <span class="media align-items-center">
<span class="media-body">Contact us</span>
</span></a></li>
<li class="nav-item"><a class="nav-link" href="/plans"> <span class="media align-items-center">
<span class="media-body">Pricing</span>
</span></a></li>
</ul>

</div>
<div class="col-6 col-md-3 col-lg text-left">
<h5 class="text-white">Resources</h5>

<ul class="nav nav-sm nav-x-0 nav-white flex-column">
<li class="nav-item"><a class="nav-link" href="https://blog.trellis.law/">
<span class="media align-items-center">
<span class="media-body">Blog</span>
</span>
</a>
</li>
<li class="nav-item"><a class="nav-link" href="https://support.trellis.law">
<span class="media align-items-center">
<span class="media-body">Support & FAQ</span>
</span>
</a>
</li>
<li class="nav-item"><a class="nav-link" href="/faq/credits">
<span class="media align-items-center">
<span class="media-body">Credit System FAQ</span>
</span>
</a>
</li>
</ul>

</div>
<div class="col-12 mt-3">
<hr class="opacity-xs my-0">
<div class="container space-1">
<div class="row align-items-md-center mb-7">
<div class="col-md-6 mb-4 mb-md-0 pl-0">

<ul class="nav nav-sm nav-white nav-x-sm align-items-center">
<li class="nav-item">
<a class="nav-link" href="/privacy-policy">Privacy &amp; Policy</a>
</li>
<li class="nav-item opacity mx-3">/</li>
<li class="nav-item">
<a class="nav-link" href="/terms-of-service">Term of Service</a>
</li>
<li class="nav-item opacity mx-3">/</li>
<li class="nav-item">
<a class="nav-link" href="/public-records">Public Records</a>
</li>
</ul>

</div>
<div class="col-sm-6 w-md-75 text-lg-right mx-lg-auto">
<p class="text-white opacity-sm  mt-3">© 2021 Trellis. All Rights Reserved.</p>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
<style>
        #close-modal-text, #close-anchor {
    color: rgb(1, 136, 90)!important;
    font-family: Roboto, sans-serif;
    font-size: 17px;
    cursor: pointer;
    font-weight: 400;
    opacity: 1!important;
}
#modal-title{
    font-family: Montserrat, sans-serif;
    font-size: 37px;
    font-weight: 600;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: Montserrat, sans-serif;
    font-weight: 600;
    padding: 0 1rem;
    margin-top: 20px;
    margin-bottom: 30px;
}
#success-modal-body {
    font-family: Roboto, sans-serif;
    font-size: 19px;
    display: flex;
    justify-content: center;
    margin-bottom: 20px;
}
#success-modal-header {
    padding-top: 20px;
    border-bottom: none;
}
.modal-dialogue {
    max-width: 700px;
}
#close-button {
    font-size: 45px;
    padding: 0 10px 0 0;
    font-weight: 300;
    color: rgb(145, 147, 150);
}
#success-modal-footer {
    display: flex;
    justify-content: center;
    border: none;
}

.close-anchor,
#close-anchor {
    color: rgb(1, 136, 90)!important;
    font-family: Roboto, sans-serif;
    font-size: 17px;
    cursor: pointer;
    font-weight: 400;
    opacity: 1!important;
}
.outer-margin {
    margin: 0 35px;
}
.modal.fade .modal-dialog {
    margin-top: 10%;
    -webkit-transform: translate3d(-50%, 0, 0);
    transform: translate3d(-50%, 0, 0);
}
    </style>
<div class="container">
<div class="row">
<div class="modal fade" id="credits-purchased-modal" tabindex="-1" role="dialog" aria-labelledby="subscription-change-started" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div id="success-modal-header" class="modal-header">
<button id="close-button" type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div id="upper-modal-block">
<div class="modal-title-container outer-margin">
<h5 class="modal-title" id="modal-title">Thank you</h5>
</div>
<div id="success-modal-body">
Your credits were successfully purchased.
</div>
</div>
<div id="success-modal-footer" class="modal-footer outer-margin mb-3">
<a class="close-anchor" href="#">Close</a>
</div>
</div>
</div>
</div>
</div>
</div>
<style>
        #close-modal-text, #close-anchor {
    color: rgb(1, 136, 90)!important;
    font-family: Roboto, sans-serif;
    font-size: 17px;
    cursor: pointer;
    font-weight: 400;
    opacity: 1!important;
}
#modal-title{
    font-family: Montserrat, sans-serif;
    font-size: 37px;
    font-weight: 600;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: Montserrat, sans-serif;
    font-weight: 600;
    padding: 0 1rem;
    margin-top: 20px;
    margin-bottom: 30px;
}
#success-modal-body {
    font-family: Roboto, sans-serif;
    font-size: 19px;
    display: flex;
    justify-content: center;
    margin-bottom: 20px;
}
#success-modal-header {
    padding-top: 20px;
    border-bottom: none;
}
.modal-dialogue {
    max-width: 700px;
}
#close-button {
    font-size: 45px;
    padding: 0 10px 0 0;
    font-weight: 300;
    color: rgb(145, 147, 150);
}
#success-modal-footer {
    display: flex;
    justify-content: center;
    border: none;
}

.close-anchor,
#close-anchor {
    color: rgb(1, 136, 90)!important;
    font-family: Roboto, sans-serif;
    font-size: 17px;
    cursor: pointer;
    font-weight: 400;
    opacity: 1!important;
}
.outer-margin {
    margin: 0 35px;
}
.modal.fade .modal-dialog {
    margin-top: 10%;
    -webkit-transform: translate3d(-50%, 0, 0);
    transform: translate3d(-50%, 0, 0);
}
    </style>
<div class="container">
<div class="row">
<div class="modal fade" id="subscription-upgraded-modal" tabindex="-1" role="dialog" aria-labelledby="subscription-change-started" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div id="success-modal-header" class="modal-header">
<button id="close-button" type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div id="upper-modal-block">
<div class="modal-title-container outer-margin">
<h5 class="modal-title" id="modal-title">Thank you</h5>
</div>
<div id="success-modal-body">
Your subscription has successfully been upgraded.
</div>
</div>
<div id="success-modal-footer" class="modal-footer outer-margin mb-3">
<a class="close-anchor" href="#">Close</a>
</div>
</div>
</div>
</div>
</div>
</div>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="acfcc1acf16c1b3b565e9d8c-|49" defer=""></script></body>
</html><?php /**PATH /Users/zestgeek11/work/Laravel_Projects/judicial/resources/views/dashboard.blade.php ENDPATH**/ ?>