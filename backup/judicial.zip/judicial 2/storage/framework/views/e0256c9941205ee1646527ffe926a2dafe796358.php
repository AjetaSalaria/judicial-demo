<html>
    <head>
        <title>Home - Trellis Legal Intelligence</title>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1" />
        <script type="04c1a5878af86805c5ea1c00-text/javascript" src="/environment_keys"></script>
        <meta name="description" content="Experience the most powerful legal research and analytics platform" />
        <meta name="next-head-count" content="5" />
        <link rel="icon" href="/static/favicon.ico" />
        <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="texcss" charSet="UTF-8" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css" />
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css" />
        <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/theme.min.css" />
        <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/index.css" />
        <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/themes.css" />
        <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/form.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" />
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css">
        <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/feather.css" />
        <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/marketing.css" />
        <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/trellis_modal.css" />
        <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/output.d476468f597f.css" type="text/css" />
        <script src="<?php echo e(url('/')); ?>/js/jquery-3.2.1.slim.min.js"></script>
        <script src="<?php echo e(url('/')); ?>/js/popper.min.js"></script>
        <script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script>
        <script src="<?php echo e(url('/')); ?>/js/jquery.min.js"></script>
        <script type="04c1a5878af86805c5ea1c00-text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.js"></script>
        <script type="04c1a5878af86805c5ea1c00-text/javascript" src="https://unpkg.com/aos@next/dist/aos.js"></script>
        <script type="04c1a5878af86805c5ea1c00-text/javascript" src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
        <script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="04c1a5878af86805c5ea1c00-|49" defer=""></script>
        <script type="04c1a5878af86805c5ea1c00-text/javascript">
            AOS.init({
                duration: 1000
            });
            // If Authenticated, Set User Script Var
            var IS_AUTHENTICATED = false;
            var trellisUser = undefined;
            var IS_SUBSCRIBED = false; 
        </script>
    </head>
    <body>
        <div class="container-fluid">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html><?php /**PATH /Library/WebServer/Documents/judicial 2/resources/views/layout.blade.php ENDPATH**/ ?>