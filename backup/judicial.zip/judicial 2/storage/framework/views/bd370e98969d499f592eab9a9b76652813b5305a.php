<?php $__env->startSection('title', 'Home - Trellis Legal Intelligence'); ?>

<?php $__env->startSection('content'); ?>
    <div id="__next" style="position: relative;">
      <div class="container-fluid">
         <div class="row">
            <div class="col">
               <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom">
                  <div class="container">
                     <a class="navbar-brand" href="/">
                     <img src="/static/global/trellis-word-dark-green.svg" class="navbar-brand-img" alt="ContentMiner">
                     </a>
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse" id="navbarCollapse">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fe fe-x"></i>
                        </button>
                        <ul class="navbar-nav ml-auto">
                           <li class="nav-item">
                              <a class="nav-link" id="navbarLandings" role="button" href="/" aria-haspopup="true" aria-expanded="false">
                              Home
                              </a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" id="navbarPages" role="button" href="/plans" aria-haspopup="true" aria-expanded="false">
                              Pricing
                              </a>
                           </li>
                           <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" id="navbarAccount" data-toggle="dropdown" href="/coverage" aria-haspopup="true" aria-expanded="false">
                              Coverage
                              </a>
                              <ul class="dropdown-menu" aria-labelledby="navbarAccount">
                                 <li class="dropdown-item dropright">
                                    <a class="dropdown-link" href="/coverage/california" role="button" aria-haspopup="true" aria-expanded="false">
                                    California
                                    </a>
                                 </li>
                                 <li class="dropdown-item dropright">
                                    <a class="dropdown-link" role="button" aria-haspopup="true" aria-expanded="false" href="/coverage/delaware">
                                    Delaware
                                    </a>
                                 </li>
                                 <li class="dropdown-item dropright">
                                    <a class="dropdown-link" href="/coverage/florida" role="button" aria-haspopup="true" aria-expanded="false">
                                    Florida
                                    </a>
                                 </li>
                                 <li class="dropdown-item dropright">
                                    <a class="dropdown-link" role="button" aria-haspopup="true" aria-expanded="false" href="/coverage/illinois">
                                    Illinois
                                    </a>
                                 </li>
                                 <li class="dropdown-item dropright">
                                    <a class="dropdown-link" href="/coverage/massachusetts" role="button" aria-haspopup="true" aria-expanded="false">
                                    Massachusetts <span class="h6 text-uppercase text-primary align-self-center ml-1 mb-0">(new)</span>
                                    </a>
                                 </li>
                                 <li class="dropdown-item dropright">
                                    <a class="dropdown-link" role="button" aria-haspopup="true" aria-expanded="false" href="/coverage/nevada">
                                    Nevada
                                    </a>
                                 </li>
                                 <li class="dropdown-item dropright">
                                    <a class="dropdown-link" href="/coverage/new-york" role="button" aria-haspopup="true" aria-expanded="false">
                                    New York
                                    </a>
                                 </li>
                                 <li class="dropdown-item dropright">
                                    <a class="dropdown-link" href="/coverage/pennsylvania" role="button" aria-haspopup="true" aria-expanded="false">
                                    Pennsylvania <span class="h6 text-uppercase text-primary align-self-center ml-1 mb-0">(new)</span>
                                    </a>
                                 </li>
                                 <li class="dropdown-item dropright">
                                    <a class="dropdown-link" href="/coverage/texas" role="button" aria-haspopup="true" aria-expanded="false">
                                    Texas
                                    </a>
                                 </li>
                                 <li class="dropdown-item dropright">
                                    <a class="dropdown-link" href="/coverage/washington" role="button" aria-haspopup="true" aria-expanded="false">
                                    Washington <span class="h6 text-uppercase text-primary align-self-center ml-1 mb-0">(new)</span>
                                    </a>
                                 </li>
                              </ul>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" role="button" href="/about" aria-haspopup="true" aria-expanded="false">
                              About us
                              </a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" role="button" href="/contact" aria-haspopup="true" aria-expanded="false">
                              Contact us
                              </a>
                           </li>
                        </ul>
                        <div class="ml-auto">
                           <a class="navbar-btn btn btn-sm btn-primary-soft lift" href="<?php echo e(route('login')); ?>" role="button">
                           Login</a>
                        </div>
                     </div>
                  </div>
               </nav>
               <section class="position-relative py-8 py-md-11 mb-9 section-1">
                  <div class="shape shape-fluid-x shape-blur-1 svg-shim text-green-200">
                     <svg id="sw-js-blob-svg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" version="1.1">
                        <defs>
                           <linearGradient id="sw-gradient" x1="0" x2="1" y1="1" y2="0">
                              <stop id="stop1" stop-color="rgba(110.396, 45.991, 134.508, 1)" offset="0%"></stop>
                              <stop id="stop2" stop-color="rgba(81, 4, 66, 1)" offset="100%"></stop>
                           </linearGradient>
                        </defs>
                        <path fill="url(#sw-gradient)" d="M23.9,-33.2C31,-27.8,36.9,-20.8,39.5,-12.8C42.1,-4.8,41.5,4.2,38.8,12.6C36.1,21,31.3,28.7,24.5,34.2C17.6,39.6,8.8,42.8,0.5,42C-7.7,41.3,-15.5,36.6,-23.3,31.5C-31.2,26.4,-39.1,20.8,-42.3,13.2C-45.5,5.6,-44,-4.1,-40.6,-12.7C-37.2,-21.4,-31.8,-28.9,-24.8,-34.4C-17.7,-39.8,-8.8,-43,-0.2,-42.7C8.4,-42.4,16.8,-38.6,23.9,-33.2Z" width="100%" height="100%" transform="translate(50 50)" stroke-width="0" style="transition: all 0.3s;"></path>
                     </svg>
                  </div>
                  <div class="container">
                     <div class="row align-items-center">
                        <div class="col-12 col-md-6 order-md-2" style="z-index:-1;">
                           <div class="img-skewed img-skewed-left mb-8 mb-md-0">
                              <img src="images/cover-1.jpg" alt="search result" class="screenshot img-fluid mw-xl-130 aos-init" data-aos="img-skewed-item-left" data-aos-delay="100" style="box-shadow: 5px 6px 7px #8a8a8a54, -1em -15px 2em #90909057;">
                           </div>
                        </div>
                        <div class="col-12 col-md-6 order-md-1 aos-init" data-aos="fade-up">
                           <h1 class="display-3">
                              Welcome to the future<br>
                              <span class="text-primary">of legal intelligence</span>.
                           </h1>
                           <p class="lead text-muted mb-6 mb-md-8">
                              State trial court data - accessible for the first time! Trellis is a comprehensive AI-powered state court research and analytics platform built by litigators for litigators.
                           </p>
                           <p class="lead text-muted mb-6 mb-md-8">What will you discover when you access the largest searchable database of state trial court records?</p>
                           <a href="/search" class="btn btn-primary mr-1 lift">
                           Start Searching For Free <i class="fe fe-arrow-right ml-3"></i>
                           </a>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="py-8 py-md-11 border-bottom section-2">
                  <div class="container">
                     <div class="row justify-content-center">
                        <div class="col-12 col-md-10 col-lg-9 text-center">
                           <h6 class="text-uppercase text-primary aos-init" data-aos="fade-up"></h6>
                           <h1 class="display-1 aos-init" data-aos="fade-up" data-aos-delay="150">
                              Smart Search Technology&trade;
                           </h1>
                           <p class="lead text-muted mb-6 aos-init" data-aos="fade-up" data-aos-delay="100">
                              Imagine being able to “google search” state trial court records (dockets, rulings, and filed documents) across counties and states through a single interface, to learn exactly how your judge, party, or opposing counsel has handled similar cases? Now you can. Welcome to Smart Search.
                           </p>
                           <p class="mb-7 mb-md-9 aos-init" data-aos="fade-up" data-aos-delay="150">
                              <a class="btn btn-primary shadow lift" href="/plans">
                              Free 14 Day Trial <i class="fe fe-arrow-right ml-3"></i>
                              </a>
                           </p>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-12 aos-init" data-aos="fade-up" data-aos-delay="200">
                           <div>
                              <div class="carousel js-flickity" data-flickity-options='{ "lazyLoad": true,"wrapAround": true, "autoPlay": 2500  }' tabindex="0" style="height: 600px; touch-action: pan-y;">
                                 <div class="carousel-cell">
                                    <img src="images/document-p2.jpg" alt="Document page" />
                                 </div>
                                 <div class="carousel-cell">
                                    <img src="images/document-search.jpg" alt="document search page" />
                                 </div>
                                 <div class="carousel-cell">
                                    <img src="images/ruling-p2.jpg" alt="ruling page" />
                                 </div>
                                 <div class="carousel-cell">
                                    <img src="images/docket-p2.jpg" alt="docket page" />
                                 </div>
                                 <div class="carousel-cell">
                                    <img src="images/judge-bio-p2.jpg" alt="judeg bio page" />
                                 </div>
                                 <div class="carousel-cell">
                                    <img src="images/motion-p2.jpg" alt="motion and issues page" />
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="pt-8 pb-10 pb-md-14 pb-lg-9 section-1 coverage-section">
                  <div class="container">
                     <div class="row align-items-center justify-content-between">
                        <div class="col-12 col-md-7">
                           <div class="device device-macbook" data-aos="fade-right" data-aos-offset="300" data-aos-easing="ease-in-sine">
                              <img src="images/coverage-1.jpg" class="device-screen" alt="device-macbook">
                              <img src="images/macbook.svg" class="img-fluid" alt="macbook">
                           </div>
                        </div>
                        <div class="col-12 col-md-5 col-lg-5">
                           <h2>
                              <span class="text-primary">View State Court Coverage
                              </span>
                           </h2>
                           <p class="font-size-lg text-gray-700 mb-6">
                              Search through millions of Court Dockets and Documents.
                              Learn more about the Trellis State Court Coverage. For a complete list of jurisdictions, see the coverage list below.
                           </p>
                           <p class="mb-7 mb-md-9 aos-init " data-aos="fade-up" data-aos-delay="150">
                              <a class="btn btn-primary shadow lift" href="/coverage">
                              See Our Coverage <i class="fe fe-arrow-right ml-3"></i>
                              </a>
                           </p>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="position-relative pt-12 pt-md-14 mt-n11">
                  <div class="shape shape-fluid-x shape-blur-2 svg-shim text-light">
                     <svg viewBox="0 0 1313 768" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M442.794 768c163.088 0 305.568-88.227 382.317-219.556l.183.556s.249-.749.762-2.181a440.362 440.362 0 0033.192-71.389C901.996 397.81 989.306 277.09 1144.29 206l-.92-.693C1230.34 171.296 1295.63 94.049 1312.83 0H1.294v295.514c-.663 9.909-1 19.908-1 29.986 0 244.386 198.114 442.5 442.5 442.5z" fill="currentColor" />
                     </svg>
                  </div>
                  <div class="container">
                     <div class="row align-items-center text-center text-md-left">
                        <div class="col-12 col-md-7">
                           <img src="images/At-a-Glance-Judge-Dashboard.png" alt="judge dashboard" class="img-fluid  float-right mb-6 mb-md-0 JDA" data-aos="fade-right">
                        </div>
                        <div class="col-12 col-md-5 pl-5">
                           <h2 class="display-3">
                              See how your<br>
                              <span class="text-primary">judge rules</span>
                           </h2>
                           <p class="font-size-lg text-muted mb-0" data-aos="fade-left" data-aos-delay="200">
                              Building the best case for your client means relying on more than anecdotes and emails. Our Judge Analytics Dashboard is the first of its kind to let you analyze millions of state trial court cases to surface the most powerful analysis for your case. From motion grant rates, to important case milestones, you’ll have the insights you need to make the right decision - every time.
                           </p>
                           <p class="font-size-lg text-muted mb-0" data-aos="fade-left" data-aos-delay="200">
                              With your expertise, and our analytics, you’ll be able to practice data-driven law that will set you apart from the crowd.
                           </p>
                           <br>
                           <p class="mb-7 mb-md-9 aos-init" data-aos="fade-up" data-aos-delay="150">
                              <a class="btn btn-primary shadow lift" href="/judge-analytics">
                              Judge Analytics Dashboard Features <i class="fe fe-arrow-right ml-3"></i>
                              </a>
                           </p>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="position-relative py-8 py-md-11 mb-9">
                  <div class="shape shape-fluid-x shape-blur-1 svg-shim text-green-200">
                     <svg viewBox="0 0 723 569" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M703.969 241.602l-.006-.003C716.081 262.97 723 287.677 723 314c0 68.917-47.425 126.757-111.42 142.665L246.7 556.937C226.465 564.729 204.481 569 181.5 569 81.26 569 0 487.74 0 387.5c0-34.256 9.49-66.296 25.985-93.633l-.016.008L141.512 77.548C162.753 33.305 207.123 2.273 258.951.12l.008-.12h251.04l.003.01c41.848.557 78.081 24.378 96.356 59.12l.001-.005 97.61 182.477z" fill="currentColor"></path>
                     </svg>
                  </div>
                  <div class="container">
                     <div class="row align-items-center">
                        <div class="col-12 col-md-6 order-md-2">
                           <div class="img-skewed img-skewed-left mb-8 mb-md-0">
                              <img src="images/document-search.jpg" alt="document search" class="screenshot img-fluid mw-xl-130 aos-init" data-aos="img-skewed-item-left" data-aos-delay="100" style="box-shadow: 5px 6px 7px #8a8a8a54, -1em -15px 2em #90909057;">
                           </div>
                        </div>
                        <div class="col-12 col-md-6 order-md-1 aos-init" data-aos="fade-up">
                           <h2 class="display-3">
                              Finding
                              <span class="text-primary">dockets</span> <br>& <span class="text-primary">documents</span>.
                           </h2>
                           <p class="lead text-muted mb-6 mb-md-8">
                              For the first time, search the body and text of filed trial court documents to find exactly what you need to draft a case winning narrative..
                           </p>
                           <p class="lead text-muted mb-6 mb-md-8">Search across dockets to uncover intelligence about parties’ litigation history and your opposing counsel’s past strategy.
                           </p>
                           <a href="/plans" class="btn btn-primary mr-1 lift">
                           Free 14 Day Trial <i class="fe fe-arrow-right ml-3"></i>
                           </a>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="py-10 bg-dark" style="background-image: url(static/images/pattern-1.svg);">
                  <div class="container">
                     <div class="row justify-content-center">
                        <div class="col-12 col-md-10 col-lg-8 text-center">
                           <h3 class="display-4 text-white">
                              We know everything there is to know about your judge.<br> And your opposing counsel, too.
                           </h3>
                           <a href="/search" class="btn btn-primary lift">
                           Start Search For Free <i class="fe fe-arrow-right ml-2"></i>
                           </a>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="pt-8 pb-10 pb-md-14 pb-lg-9 section-1">
                  <div class="container">
                     <div class="row align-items-center justify-content-between">
                        <div class="col-12 col-md-8">
                           <div class="device device-macbook" data-aos="fade-right" data-aos-offset="300" data-aos-easing="ease-in-sine">
                              <img src="images/alert.jpg" class="device-screen" alt="alert page">
                              <img src="images/macbook.svg" class="img-fluid" alt="macbook frame">
                           </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-4">
                           <h2>
                              <span class="text-primary">Alerts,
                              </span> get notified as judges are ruling!<br>
                           </h2>
                           <p class="font-size-lg text-gray-700 mb-6">
                              For the first time you can track legal issues as they are being decided - in real time. You’re the expert! Trellis helps you stay that way.
                           </p>
                           <p class="mb-7 mb-md-9 aos-init " data-aos="fade-up" data-aos-delay="150">
                              <a class="btn btn-primary shadow lift" href="/plans">
                              Free 14 Day Trial <i class="fe fe-arrow-right ml-3"></i>
                              </a>
                           </p>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="pt-8 pt-md-11 pb-lg-10 section-2" id="payItDown">
                  <div class="container">
                     <div class="row justify-content-center">
                        <div class="col-12 col-md-10 col-lg-8 text-center" data-aos="fade-down" data-aos-offset="300" data-aos-easing="ease-in-sine">
                           <span class="badge badge-pill badge-primary-soft mb-3">
                           <span class="h6 text-uppercase">Try Trellis today </span>
                           </span>
                           <h1>
                              Present your case with <span class="text-primary">confidence.</span>
                           </h1>
                           <p class="lead text-gray-700 mb-7 mb-md-9">
                              Research your judge, find out how the judge think about specific legal issues and motions. 
                           </p>
                        </div>
                     </div>
                     <div class="container">
                        <div class="row align-items-center">
                           <div class="col-lg-8 col-md-6 col-sm-12">
                              <div class="tab-content" id="v-pills-tabContent">
                                 <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    <img src="images/ruling-p2.jpg" alt="ruling" class="screenshot img-fluid mw-md-110 float-right mr-md-6 mb-6 mb-md-0">
                                 </div>
                                 <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                                    <img src="images/docket-p2.jpg" alt="docket" class="screenshot img-fluid mw-md-110 float-right mr-md-6 mb-6 mb-md-0">
                                 </div>
                                 <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                                    <img src="images/document-p2.jpg" alt="documents" class="screenshot img-fluid mw-md-110 float-right mr-md-6 mb-6 mb-md-0">
                                 </div>
                                 <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                                    <img src="images/judge-bio-p2.jpg" alt="judge bio" class="screenshot img-fluid mw-md-110 float-right mr-md-6 mb-6 mb-md-0">
                                 </div>
                                 <div class="tab-pane fade" id="v-pills-motion" role="tabpanel" aria-labelledby="v-pills-motion-tab">
                                    <img src="images/motion-p2.jpg" alt="motion and issues" class="screenshot img-fluid mw-md-110 float-right mr-md-6 mb-6 mb-md-0">
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-4 col-md-6 col-sm-12">
                              <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                 <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">
                                    <div class="d-flex">
                                       <div class="badge badge-lg badge-rounded-circle badge-primary-soft mt-1">
                                          <span>1</span>
                                       </div>
                                       <div class="ml-5">
                                          <h3>
                                             Ruling
                                          </h3>
                                          <p class="text-gray-700 mb-2">
                                             Search your judge’s rulings to learn how they think about particular issues;
                                          </p>
                                       </div>
                                    </div>
                                 </a>
                                 <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">
                                    <div class="d-flex">
                                       <div class="badge badge-lg badge-rounded-circle badge-primary-soft mt-1">
                                          <span>2</span>
                                       </div>
                                       <div class="ml-5">
                                          <h3>
                                             Docket
                                          </h3>
                                          <p class="text-gray-700 mb-2">
                                             Search your opposing counsel’s dockets to see how often they take cases to trial.
                                          </p>
                                       </div>
                                    </div>
                                 </a>
                                 <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">
                                    <div class="d-flex">
                                       <div class="badge badge-lg badge-rounded-circle badge-primary-soft mt-1">
                                          <span>3</span>
                                       </div>
                                       <div class="ml-5">
                                          <h3>
                                             Document
                                          </h3>
                                          <p class="text-gray-700 mb-2">
                                             Improve motion practice by using filed court docs as outlines for your next successful motion
                                          </p>
                                       </div>
                                    </div>
                                 </a>
                                 <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">
                                    <div class="d-flex">
                                       <div class="badge badge-lg badge-rounded-circle badge-primary-soft mt-1">
                                          <span>4</span>
                                       </div>
                                       <div class="ml-5">
                                          <h3>
                                             Judge Bio
                                          </h3>
                                          <p class="text-gray-700 mb-2">
                                             Practical info about your judge, background, evidentiary rules, clerk’s number, all at your finger tips.
                                          </p>
                                       </div>
                                    </div>
                                 </a>
                                 <a class="nav-link" id="v-pills-motion-tab" data-toggle="pill" href="#v-pills-motion" role="tab" aria-controls="v-pills-motion" aria-selected="false">
                                    <div class="d-flex">
                                       <div class="badge badge-lg badge-rounded-circle badge-primary-soft mt-1">
                                          <span>5</span>
                                       </div>
                                       <div class="ml-5">
                                          <h3>
                                             Motion & Issues
                                          </h3>
                                          <p class="text-gray-700 mb-2">
                                             Playbooks for understanding how important issues and motions are handled at trial court level.
                                          </p>
                                       </div>
                                    </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="py-10 bg-dark" style="background-image: url(static/images/pattern-1.svg);">
                  <div class="container">
                     <div class="row justify-content-center">
                        <div class="col-12 col-md-10 col-lg-8 text-center">
                           <h3 class="display-4 text-white">
                              See how your judge rules 
                           </h3>
                           <a href="/search" class="btn btn-primary lift">
                           View Analytics <i class="fe fe-arrow-right ml-2"></i>
                           </a>
                        </div>
                     </div>
                  </div>
               </section>
               <section class="py-6 py-md-8 bg-primary-desat flickityLogosContainer">
                  <div class="container">
                     <div class="flickity-viewport-visible" data-flickity='{"imagesLoaded": true, "initialIndex": 6, "pageDots": false, "prevNextButtons": false, "contain": true, "autoPlay": 1500 }'>
                        <div class="col-4 col-md-3 col-lg-2">
                           <div class="img-fluid svg-shim text-white">
                              <img height="87" width="100" src="images/brand/logo-1.png" alt="ogletree deakins">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-4">
                           <div class="img-fluid svg-shim text-white">
                              <img width="300" src="images/brand/logo-2.svg" alt="quinn emanuel">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-2">
                           <div class="img-fluid svg-shim text-white">
                              <img width="150" src="images/brand/logo-8.svg" alt="seyfarth">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-3">
                           <div class="img-fluid svg-shim text-white">
                              <img src="images/brand/logo-4.png" alt="gibson dunn">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-3">
                           <div class="img-fluid svg-shim text-white">
                              <img src="images/brand/logo-5.png" alt="dentons">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-2">
                           <div class="img-fluid svg-shim text-white">
                              <img src="images/brand/logo-3.png" alt="keker van nest & peters">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-1">
                           <div class="img-fluid svg-shim text-white">
                              <img src="images/brand/logo-7.svg" alt="fisher philips">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-2">
                           <div class="img-fluid svg-shim text-white">
                              <img src="images/brand/logo-9.svg" alt="Perkins-coie">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-2">
                           <div class="img-fluid svg-shim text-white">
                              <img src="images/brand/logo10.svg" alt="Kirkland-ellis">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-2">
                           <div class="img-fluid svg-shim text-white">
                              <img src="images/brand/logo11.png" alt="JuntonAK logo">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-2">
                           <div class="img-fluid svg-shim text-white">
                              <img src="images/brand/logo12.png" alt="Gordon Rees logo">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-2">
                           <div class="img-fluid svg-shim text-white">
                              <img src="images/brand/logo13.jpeg" alt="manatt">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-2">
                           <div class="img-fluid svg-shim text-white">
                              <img src="images/brand/logo15.svg" alt="Bryan cave logo  ">
                           </div>
                        </div>
                        <div class="col-4 col-md-3 col-lg-4">
                           <div class="img-fluid svg-shim text-white">
                              <img src="images/brand/logo14.png" alt="bowmanandbrooke">
                           </div>
                        </div>
                     </div>
               </section>
               <div class="footerHolder___2JfG_  footer_marketing">
               		<footer id="footer" class="page-footer hide-on-print">
					   <div class="container footer-container">
					      <div class="row justify-content-center justify-content-md-start text-center text-md-left">
					         <div class="col-lg-3 ml-lg-auto mb-8 mb-lg-0 text-left">
					            <img class="brand" src="<?php echo e(url('/')); ?>/images/trellis-white-logo.svg" alt="Logo">
					            <ul class="list-inline mb-0 social-footer">
					               <li class="list-inline-item">
					                  <a class="btn btn-xs btn-icon btn-soft-secondary rounded" href="https://www.linkedin.com/company/trellis-law" aria-label="Linkedin">
					                  <i class="fab fa-linkedin fa-2x"></i>
					                  </a>
					               </li>
					               <li class="list-inline-item">
					                  <a class="btn btn-xs btn-icon btn-soft-secondary rounded" href="https://twitter.com/trellis_law" aria-label="Twitter">
					                  <i class="fab fa-twitter fa-2x"></i>
					                  </a>
					               </li>
					            </ul>
					         </div>
					         <div class="col-6 col-md-3 col-lg mb-5 mb-lg-0 text-left">
					            <h5 class="text-white">Features</h5>
					            <ul class="nav nav-sm nav-x-0 nav-white flex-column">
					               <li class="nav-item">
					                  <a class="nav-link" href="/search">
					                  <span class="media align-items-center">
					                  <span class="media-body">Smart Search</span>
					                  </span>
					                  </a>
					               </li>
					               <li class="nav-item">
					                  <a class="nav-link" href="/judges">
					                  <span class="media align-items-center">
					                  <span class="media-body">Judge Analytics</span>
					                  </span>
					                  </a>
					               </li>
					               <li class="nav-item">
					                  <a class="nav-link" href="/ca/motion-type">
					                  <span class="media align-items-center">
					                  <span class="media-body">Motion & Issues</span>
					                  </span>
					                  </a>
					               </li>
					               <li class="nav-item">
					                  <a class="nav-link" href="/coverage">
					                  <span class="media align-items-center">
					                  <span class="media-body">State Coverage</span>
					                  </span>
					                  </a>
					               </li>
					            </ul>
					         </div>
					         <div class="col-6 col-md-3 col-lg mb-5 mb-lg-0 text-left">
					            <h5 class="text-white">Company</h5>
					            <ul class="nav nav-sm nav-x-0 nav-white flex-column">
					               <li class="nav-item"><a class="nav-link" href="/"> <span class="media align-items-center">
					                  <span class="media-body">Home</span>
					                  </span></a>
					               </li>
					               <li class="nav-item"><a class="nav-link" href="/about"> <span class="media align-items-center">
					                  <span class="media-body">About</span>
					                  </span></a>
					               </li>
					               <li class="nav-item"><a class="nav-link" href="/contact"> <span class="media align-items-center">
					                  <span class="media-body">Contact us</span>
					                  </span></a>
					               </li>
					               <li class="nav-item"><a class="nav-link" href="/plans"> <span class="media align-items-center">
					                  <span class="media-body">Pricing</span>
					                  </span></a>
					               </li>
					            </ul>
					         </div>
					         <div class="col-6 col-md-3 col-lg text-left">
					            <h5 class="text-white">Resources</h5>
					            <ul class="nav nav-sm nav-x-0 nav-white flex-column">
					               <li class="nav-item"><a class="nav-link" href="https://blog.trellis.law/">
					                  <span class="media align-items-center">
					                  <span class="media-body">Blog</span>
					                  </span>
					                  </a>
					               </li>
					               <li class="nav-item"><a class="nav-link" href="https://support.trellis.law">
					                  <span class="media align-items-center">
					                  <span class="media-body">Support & FAQ</span>
					                  </span>
					                  </a>
					               </li>
					               <li class="nav-item"><a class="nav-link" href="/faq/credits">
					                  <span class="media align-items-center">
					                  <span class="media-body">Credit System FAQ</span>
					                  </span>
					                  </a>
					               </li>
					            </ul>
					         </div>
					         <div class="col-12 mt-3">
					            <hr class="opacity-xs my-0">
					            <div class="container space-1">
					               <div class="row align-items-md-center mb-7">
					                  <div class="col-md-6 mb-4 mb-md-0 pl-0">
					                     <ul class="nav nav-sm nav-white nav-x-sm align-items-center">
					                        <li class="nav-item">
					                           <a class="nav-link" href="/privacy-policy">Privacy &amp; Policy</a>
					                        </li>
					                        <li class="nav-item opacity mx-3">/</li>
					                        <li class="nav-item">
					                           <a class="nav-link" href="/terms-of-service">Term of Service</a>
					                        </li>
					                        <li class="nav-item opacity mx-3">/</li>
					                        <li class="nav-item">
					                           <a class="nav-link" href="/public-records">Public Records</a>
					                        </li>
					                     </ul>
					                  </div>
					                  <div class="col-sm-6 w-md-75 text-lg-right mx-lg-auto">
					                     <p class="text-white opacity-sm small mt-3">© 2021 Trellis. All Rights Reserved.</p>
					                  </div>
					               </div>
					            </div>
					         </div>
					      </div>
					   </div>
					</footer>
               </div>
               </div>
            </div>
         </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Library/WebServer/Documents/judicial 2/resources/views/front/index.blade.php ENDPATH**/ ?>