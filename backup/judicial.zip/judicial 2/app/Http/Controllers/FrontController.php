<?php

namespace App\Http\Controllers;

use App\Models\Results;
use App\Models\Details;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

class FrontController extends Controller
{

    public function index(){
        return view('front.index');
    }

     public function search()
     {
        $search = $_GET['search']; 

        // $allItmes = Item::leftjoin('categories', 'categories.id', '=', 'items.category_id')
        //             ->select('items.name as items_name','items.details as items_details','items.price as items_price','items.discount_type as discount_type','items.discount as discount','categories.name as category_name')
        //             ->where('items.name', 'LIKE','%'.$search.'%')
        //             ->where('items.restaurant_id', $restaurant_id)
        //             ->get();

        $allItmes = Results::leftjoin('details', 'details.result_id', '=', 'results.id')
                    ->select('details.case_number as detail_case_number', 'details.case_name as detail_case_name','details.nature_of_proceeding as nature_of_proceeding','details.ruling as ruling','details.judge as details_judge','details.hearing_date as details_hearing_date','details.county as details_county','details.department as details_department','details.filed as details_filed','details.category as details_category ','results.case_number as results_case_number ','results.heading as results_heading','results.text as results_text','results.hearing as results_hearing ','results.type as results_type','results.subtype as results_subtype')
                    ->where('heading', 'LIKE','%'.$search.'%')
                    ->get(); 
                   
            if(count($allItmes) > 0){
                 echo "<pre>"; print_r($allItmes); die(); 
             echo '<div class="category-item-wrapper catg-list category-search-result">
                        <div class="category-search">
                            <h3 class="header-text">Search Results</h3>
                        </div>';
        }else{
            echo 'hii';
        }
    }

}
